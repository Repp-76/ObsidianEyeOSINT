import ipaddress
import re
from urllib.parse import urlparse

USERNAME_RE = re.compile(r"^[A-Za-z0-9_.\-]{1,40}$")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
DOMAIN_RE = re.compile(r"^(?=.{1,253}$)(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$")


def is_valid_username(value: str) -> bool:
    return bool(USERNAME_RE.match(value.strip()))


def is_valid_email(value: str) -> bool:
    return bool(EMAIL_RE.match(value.strip()))


def is_valid_domain(value: str) -> bool:
    value = value.strip().rstrip(".")
    if value.startswith(("http://", "https://")):
        value = urlparse(value).netloc or value
    return bool(DOMAIN_RE.match(value))


def is_valid_ip(value: str) -> bool:
    try:
        ipaddress.ip_address(value.strip())
        return True
    except ValueError:
        return False


def is_valid_url(value: str) -> bool:
    try:
        parsed = urlparse(value.strip())
        return parsed.scheme in ("http", "https") and bool(parsed.netloc)
    except ValueError:
        return False


def normalize_domain(value: str) -> str:
    value = value.strip().rstrip(".")
    if value.startswith(("http://", "https://")):
        value = urlparse(value).netloc
    return value.lower()
