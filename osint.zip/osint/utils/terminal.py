import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional

from rich.console import Console
from rich.table import Table
from rich import box
from rich.panel import Panel

console = Console()

BANNER = r"""
   ___  _         _     _ _             ______           
  / _ \| |__  ___(_) __| (_) __ _ _ __  |  ____|   _  ___ 
 | | | | '_ \/ __| |/ _` | |/ _` | '_ \ | |__| | | |/ _ \
 | |_| | |_) \__ \ | (_| | | (_| | | | ||  __| |_| |  __/
  \___/|_.__/|___/_|\__,_|_|\__,_|_| |_||_|   \__, |\___|
                                               |___/       OSINT
"""


def clear_screen() -> None:
    os.system("cls" if os.name == "nt" else "clear")


def print_banner() -> None:
    console.print(BANNER.rstrip("\n"), style="bold cyan")
    console.print("Public Intelligence & Digital Footprint Explorer", style="bold white")
    console.print()
    console.print(
        "OSINT (Open-Source Intelligence) is the process of collecting and\n"
        "analyzing information that is publicly available from legitimate sources.",
        style="grey70",
    )
    console.print()
    console.print("Developer: Repp76", style="grey58")


def print_status(modules: int, telegram_configured: bool) -> None:
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_row("Engine", "[green]Ready[/green]")
    table.add_row("Modules", str(modules))
    table.add_row("Mode", "Public Data")
    table.add_row("Reports", "JSON")
    table.add_row("Telegram", "[green]Configured[/green]" if telegram_configured else "[yellow]Not Configured[/yellow]")
    console.print(table)
    console.print()


def success(msg: str) -> None:
    console.print(f"[green][+] {msg}[/green]")


def warn(msg: str) -> None:
    console.print(f"[yellow][!] {msg}[/yellow]")


def error(msg: str) -> None:
    console.print(f"[red][!] {msg}[/red]")


def info(msg: str) -> None:
    console.print(f"[cyan][*] {msg}[/cyan]")


def heading(msg: str) -> None:
    console.print(f"\n[bold blue]{msg}[/bold blue]")


def prompt(msg: str) -> str:
    try:
        return console.input(f"[white]{msg}[/white]").strip()
    except (EOFError, KeyboardInterrupt):
        raise



# Every raw Finding.status the modules produce, mapped to the color it
# gets in the terminal and the plain-language label shown to the user.
# The raw status is what stays in the JSON report - this table only
# controls presentation, it never changes what was actually observed.
STATUS_META = {
    "CONFIRMED_PUBLIC":           ("green",   "FOUND"),
    "VERIFIED_PUBLIC_PROFILE":    ("green",   "FOUND"),
    "AVAILABLE":                  ("green",   "AVAILABLE"),
    "PRESENT":                    ("green",   "PRESENT"),
    "NOT_FOUND":                  ("grey58",  "NOT FOUND"),
    "POSSIBLE_MATCH":             ("yellow",  "POSSIBLE MATCH"),
    "MISSING":                    ("yellow",  "MISSING"),
    "REGISTERED":                 ("yellow",  "REGISTERED"),
    "REQUIRES_VERIFICATION":      ("yellow",  "REQUIRES VERIFICATION"),
    "UNKNOWN":                    ("red",     "UNVERIFIED"),
    "UNCONFIRMED":                ("red",     "UNVERIFIED"),
    "BLOCKED":                    ("red",     "UNVERIFIED"),
    "SOURCE_UNAVAILABLE":         ("red",     "UNVERIFIED"),
    "LOOKUP_FAILED":              ("red",     "UNVERIFIED"),
    "MISCONFIGURED":              ("red",     "MISCONFIGURED"),
    "NOT_TESTED":                 ("grey42",  "NOT TESTED"),
    "REQUIRES_API_CONFIGURATION": ("grey42",  "NOT TESTED"),
    # TLS handshake outcomes from core/tls_client.py - passed straight through
    # as the Finding status by modules/url.py, not part of the shared
    # evidence.py vocabulary, so they need their own entries here too.
    "TARGET_CERTIFICATE_PROBLEM": ("red",     "CERTIFICATE PROBLEM"),
    "UNKNOWN_TLS_ERROR":          ("red",     "TLS ERROR"),
    "TLS_CONNECTION_FAILED":      ("red",     "CONNECTION FAILED"),
    "HOST_UNREACHABLE":           ("red",     "HOST UNREACHABLE"),
}

# Buckets used only for the SUMMARY counts at the end of a report. Several
# raw statuses can share a bucket (e.g. BLOCKED and UNKNOWN are both
# "couldn't verify"), but nothing here reclassifies what was found.
SUMMARY_BUCKETS = [
    ("Confirmed / Positive Results", {"CONFIRMED_PUBLIC", "VERIFIED_PUBLIC_PROFILE", "AVAILABLE", "PRESENT"}),
    ("Possible Matches",             {"POSSIBLE_MATCH", "MISSING", "REGISTERED", "REQUIRES_VERIFICATION"}),
    ("Reliable Not Found",           {"NOT_FOUND"}),
    ("Unverified Results",           {"UNKNOWN", "UNCONFIRMED", "BLOCKED", "SOURCE_UNAVAILABLE",
                                       "LOOKUP_FAILED", "MISCONFIGURED"}),
    ("Sources Not Tested",           {"NOT_TESTED", "REQUIRES_API_CONFIGURATION"}),
]


def status_style(status: str) -> tuple:
    """(color, display_label) for a raw Finding status. Unknown statuses
    fall back to plain white so a future status never crashes rendering."""
    return STATUS_META.get(status, ("white", status.replace("_", " ")))


def status_line(label: str, status: str) -> str:
    color, display = status_style(status)
    padded = f"{label:<22}"
    return f"[white]{padded}[/white][{color}]{display}[/{color}]"


def _fmt_duration(seconds: float) -> str:
    if seconds < 60:
        return f"{seconds:.1f} seconds"
    minutes, secs = divmod(seconds, 60)
    return f"{int(minutes)}m {secs:.1f}s"


def render_module_report(module: str, target_label: Optional[str], target_value: Optional[str],
                          findings: list, started: datetime, completed: datetime,
                          sources_count: int, report_path: Optional[Path],
                          telegram_status: str, disclaimer: Optional[str] = None) -> None:
    """
    The full post-scan report: investigation summary, one entry per
    finding, a status summary, and where the JSON went. Same layout for
    every module - only the target/finding content changes.
    """
    duration = (completed - started).total_seconds()

    console.print()
    console.print(Panel(
        f"[bold white]OBSIDIANEYE OSINT[/bold white]\n[bold cyan]{module.upper()}[/bold cyan]",
        box=box.DOUBLE, expand=False, border_style="blue",
    ))

    console.print("[bold blue]Investigation Summary[/bold blue]")
    if target_label and target_value:
        console.print(f"  {target_label:<14}: {target_value}")
    console.print(f"  {'Module':<14}: {module}")
    console.print(f"  {'Started':<14}: {started.strftime('%Y-%m-%d %H:%M:%S')}")
    console.print(f"  {'Completed':<14}: {completed.strftime('%Y-%m-%d %H:%M:%S')}")
    console.print(f"  {'Duration':<14}: {_fmt_duration(duration)}")
    console.print(f"  {'Checks Run':<14}: {len(findings)}")
    console.print(f"  {'Sources':<14}: {sources_count}")
    console.print(f"  {'Report Status':<14}: COMPLETED")

    console.rule(style="grey42")
    console.print("[bold blue]RESULTS[/bold blue]\n")
    for i, f in enumerate(findings, start=1):
        color, display = status_style(f.status)
        console.print(f"[white][{i:02d}][/white] [bold white]{f.label}[/bold white]")
        console.print(f"     Result      : [{color}]{display}[/{color}]")
        if f.url:
            console.print(f"     Source      : [grey58]{f.url}[/grey58]")
        console.print(f"     Detail      : [grey70]{f.evidence}[/grey70]")
        console.print(f"     Confidence  : {f.confidence}")
        console.print()

    console.rule(style="grey42")
    console.print("[bold blue]SUMMARY[/bold blue]\n")
    for bucket_label, statuses in SUMMARY_BUCKETS:
        count = sum(1 for f in findings if f.status in statuses)
        console.print(f"  {bucket_label:<28}: {count}")

    if disclaimer:
        console.rule(style="grey42")
        console.print("[bold blue]IMPORTANT INFORMATION[/bold blue]\n")
        console.print(f"[grey58]{disclaimer}[/grey58]")

    console.rule(style="grey42")
    console.print("[bold blue]REPORT SAVED[/bold blue]\n")
    if report_path:
        console.print(f"  JSON File : {report_path}")
    console.print(f"  Telegram  : {telegram_status}")
    console.print()
