from datetime import datetime, timezone


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def filename_stamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")
