import logging
from pathlib import Path

LOG_PATH = Path(__file__).resolve().parent.parent / "reports" / "obsidianeye.log"


def get_logger() -> logging.Logger:
    logger = logging.getLogger("obsidianeye")
    if logger.handlers:
        return logger

    logger.setLevel(logging.INFO)
    LOG_PATH.parent.mkdir(exist_ok=True)
    handler = logging.FileHandler(LOG_PATH, encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
    logger.addHandler(handler)
    return logger
