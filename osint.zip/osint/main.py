# -*- coding: utf-8 -*-
# CodeShield Encrypted Python — Powered by Repp76
import base64, sys, os

_cs_dir = os.path.dirname(os.path.abspath(__file__)) if "__file__" in dir() else os.getcwd()
for _cs_p in (_cs_dir, os.getcwd()):
    if _cs_p not in sys.path:
        sys.path.insert(0, _cs_p)

_cs_parts = [
    "aW1wb3J0IHN5cwoKZnJvbSBjb3JlLmVuZ2luZSBpbXBvcnQgcnVuCmZyb20gdXRpbHMgaW1wb3J0",
    "IHRlcm1pbmFsCgoKZGVmIG1haW4oKSAtPiBpbnQ6CiAgICB0cnk6CiAgICAgICAgcnVuKCkKICAg",
    "IGV4Y2VwdCBLZXlib2FyZEludGVycnVwdDoKICAgICAgICB0ZXJtaW5hbC5jb25zb2xlLnByaW50",
    "KCkKICAgICAgICB0ZXJtaW5hbC53YXJuKCJTY2FuIGludGVycnVwdGVkIGJ5IHVzZXIuIikKICAg",
    "ICAgICB0ZXJtaW5hbC5pbmZvKCJFeGl0aW5nIE9ic2lkaWFuRXllIE9TSU5ULiIpCiAgICAgICAg",
    "cmV0dXJuIDAKICAgIHJldHVybiAwCgoKaWYgX19uYW1lX18gPT0gIl9fbWFpbl9fIjoKICAgIHN5",
    "cy5leGl0KG1haW4oKSkK"
]
_cs_code = base64.b64decode("".join(_cs_parts)).decode("utf-8")
_cs_file = __file__ if "__file__" in dir() else "<codeshield>"
_cs_compiled = compile(_cs_code, _cs_file, "exec")

# Bersihkan helper vars supaya globals() yang exec() terima
# hampir sama dengan modul tulen — __name__/__package__/__spec__
# dikekalkan sebab ia sudah wujud betul dalam globals() ini,
# disediakan oleh Python sendiri sebelum baris ini jalan.
for _cs_name in ("base64", "_cs_dir", "_cs_p", "_cs_name"):
    globals().pop(_cs_name, None)

exec(_cs_compiled, globals())
