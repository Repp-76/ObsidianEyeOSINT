import sys

from core.engine import run
from utils import terminal


def main() -> int:
    try:
        run()
    except KeyboardInterrupt:
        terminal.console.print()
        terminal.warn("Scan interrupted by user.")
        terminal.info("Exiting ObsidianEye OSINT.")
        return 0
    return 0


if __name__ == "__main__":
    sys.exit(main())
