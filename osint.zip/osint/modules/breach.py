"""
Module 14 - Public Breach Exposure Check. Uses the Have I Been Pwned API,
which requires a paid key. Without one, this is reported honestly instead
of faking a result. No underground sources, no credential retrieval.
"""

import requests

from config.settings import HIBP_API_KEY, USER_AGENT
from core.evidence import Finding, CONFIRMED_PUBLIC, NOT_FOUND, SOURCE_UNAVAILABLE, requires_api

HIBP_URL = "https://haveibeenpwned.com/api/v3/breachedaccount/{account}"


def run(email: str) -> list[Finding]:
    if not HIBP_API_KEY:
        return [requires_api("Breach Exposure", "Have I Been Pwned", "HIBP_API_KEY")]

    headers = {"hibp-api-key": HIBP_API_KEY, "User-Agent": USER_AGENT}
    try:
        resp = requests.get(HIBP_URL.format(account=email), headers=headers, timeout=10)
    except requests.exceptions.RequestException as exc:
        return [Finding("Breach Exposure", SOURCE_UNAVAILABLE, "haveibeenpwned.com", f"Request failed: {exc}",
                         "NONE", "GET request to HIBP API")]

    if resp.status_code == 404:
        return [Finding("Breach Exposure", NOT_FOUND, "haveibeenpwned.com",
                         "No breaches found for this address", "HIGH", "HIBP breachedaccount endpoint")]
    if resp.status_code == 200:
        breaches = resp.json()
        names = ", ".join(b.get("Name", "unknown") for b in breaches)
        return [Finding("Breach Exposure", CONFIRMED_PUBLIC, "haveibeenpwned.com",
                         f"Found in {len(breaches)} breach(es): {names}. Only breach names and dates are disclosed - "
                         f"no credentials are retrieved.", "HIGH", "HIBP breachedaccount endpoint")]
    if resp.status_code == 401:
        return [Finding("Breach Exposure", SOURCE_UNAVAILABLE, "haveibeenpwned.com",
                         "API key rejected (unauthorized)", "NONE", "HIBP breachedaccount endpoint")]
    if resp.status_code == 429:
        return [Finding("Breach Exposure", SOURCE_UNAVAILABLE, "haveibeenpwned.com",
                         "Rate limited by HIBP, try again later", "NONE", "HIBP breachedaccount endpoint")]

    return [Finding("Breach Exposure", SOURCE_UNAVAILABLE, "haveibeenpwned.com",
                     f"Unexpected HTTP {resp.status_code}", "NONE", "HIBP breachedaccount endpoint")]
