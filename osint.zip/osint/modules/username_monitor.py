"""
Module 13 - Username Availability Monitor. Same checks as Module 01, read
through an "is it free to register" lens instead of an identity lens.
"""

from modules.username import run as run_username_checks
from core.evidence import CONFIRMED_PUBLIC, POSSIBLE_MATCH, NOT_FOUND, UNKNOWN, BLOCKED

_STATUS_MAP = {
    CONFIRMED_PUBLIC: "REGISTERED",
    POSSIBLE_MATCH: "REGISTERED",
    NOT_FOUND: "AVAILABLE",
    UNKNOWN: "UNKNOWN",
    BLOCKED: "BLOCKED",
}


def run(username: str) -> list:
    findings = run_username_checks(username)
    for f in findings:
        f.status = _STATUS_MAP.get(f.status, "UNKNOWN")
    return findings
