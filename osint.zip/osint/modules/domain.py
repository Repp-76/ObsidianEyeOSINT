"""
Module 02 - Domain Intelligence. Resolves the domain, follows redirects,
and pulls the DNS records that describe how the domain is set up.
"""

import socket

from core import http_client, dns_client
from core.evidence import Finding, CONFIRMED_PUBLIC, NOT_FOUND, LOOKUP_FAILED, UNKNOWN

DNS_LOOKUPS = ["NS", "MX", "TXT", "CAA", "SOA"]


def _resolve_ips(domain: str) -> Finding:
    try:
        infos = socket.getaddrinfo(domain, None)
        ips = sorted({info[4][0] for info in infos})
        return Finding("Resolved IP Addresses", CONFIRMED_PUBLIC, "socket.getaddrinfo",
                        f"{len(ips)} address(es): {', '.join(ips)}", "HIGH", "Local DNS resolution via OS resolver")
    except socket.gaierror as exc:
        return Finding("Resolved IP Addresses", LOOKUP_FAILED, "socket.getaddrinfo",
                        f"Resolution failed: {exc}", "NONE", "Local DNS resolution via OS resolver")


def _http_probe(domain: str) -> list[Finding]:
    findings = []
    result = http_client.get(f"https://{domain}", timeout=8)
    if not result.ok:
        findings.append(Finding("HTTPS Reachability", LOOKUP_FAILED, domain, f"Request failed: {result.error}",
                                 "NONE", "GET request over HTTPS"))
        return findings

    findings.append(Finding("HTTPS Reachability", CONFIRMED_PUBLIC, domain, f"HTTP {result.status_code}",
                             "HIGH", "GET request over HTTPS", url=result.final_url))

    if result.history:
        findings.append(Finding("Redirect Chain", CONFIRMED_PUBLIC, domain,
                                 f"{len(result.history)} redirect(s) to {result.final_url}", "HIGH",
                                 "Followed HTTP redirects"))
    return findings


def _dns_records(domain: str) -> list[Finding]:
    findings = []
    for rtype in DNS_LOOKUPS:
        res = dns_client.query(domain, rtype)
        if res.ok:
            findings.append(Finding(f"{rtype} Record", CONFIRMED_PUBLIC, "DNS resolver",
                                     "; ".join(res.records), "HIGH", f"DNS {rtype} query"))
        elif res.error == "NXDOMAIN":
            findings.append(Finding(f"{rtype} Record", NOT_FOUND, "DNS resolver",
                                     "Domain does not exist", "HIGH", f"DNS {rtype} query"))
        elif res.error == "NO_ANSWER":
            findings.append(Finding(f"{rtype} Record", NOT_FOUND, "DNS resolver",
                                     f"No {rtype} record published", "HIGH", f"DNS {rtype} query"))
        else:
            findings.append(Finding(f"{rtype} Record", LOOKUP_FAILED, "DNS resolver",
                                     f"Lookup error: {res.error}", "NONE", f"DNS {rtype} query"))

    dnssec = dns_client.has_dnssec(domain)
    if dnssec.ok:
        findings.append(Finding("DNSSEC", CONFIRMED_PUBLIC, "DNS resolver",
                                 "DNSKEY record present at zone apex", "HIGH", "DNS DNSKEY query"))
    elif dnssec.error in ("NO_ANSWER", "NXDOMAIN"):
        findings.append(Finding("DNSSEC", NOT_FOUND, "DNS resolver",
                                 "No DNSKEY record - DNSSEC not enabled", "HIGH", "DNS DNSKEY query"))
    else:
        findings.append(Finding("DNSSEC", LOOKUP_FAILED, "DNS resolver",
                                 f"Lookup error: {dnssec.error}", "NONE", "DNS DNSKEY query"))
    return findings


def run(domain: str) -> list[Finding]:
    findings = [_resolve_ips(domain)]
    findings.extend(_http_probe(domain))
    findings.extend(_dns_records(domain))
    return findings
