"""
Module 10 - Social Profile Discovery. Accepts either a bare username or a
full profile URL and checks it against the same platform list used by
Module 01, but reported with discovery-specific status labels.
"""

from urllib.parse import urlparse

from modules.username import PLATFORMS, _check_status, _check_reddit, _check_text_marker, _blocked
from core.evidence import CONFIRMED_PUBLIC, POSSIBLE_MATCH, NOT_FOUND, UNKNOWN, BLOCKED, Finding

_STATUS_MAP = {
    CONFIRMED_PUBLIC: "VERIFIED_PUBLIC_PROFILE",
    POSSIBLE_MATCH: "POSSIBLE_MATCH",
    NOT_FOUND: "NOT_FOUND",
    UNKNOWN: "UNCONFIRMED",
    BLOCKED: "UNCONFIRMED",
}


def _extract_username(value: str) -> str:
    value = value.strip()
    if value.startswith(("http://", "https://")):
        path = urlparse(value).path.strip("/")
        return path.split("/")[0].lstrip("@") if path else value
    return value.lstrip("@")


def run(value: str) -> list[Finding]:
    username = _extract_username(value)
    findings = []
    for platform in PLATFORMS:
        method = platform["method"]
        if method == "status":
            url = platform["url"].format(u=username)
            f = _check_status(platform["name"], url)
        elif method == "reddit_json":
            f = _check_reddit(username)
        elif method == "text_marker":
            f = _check_text_marker(platform, username)
        else:
            f = _blocked(platform, username)

        f.status = _STATUS_MAP.get(f.status, "UNCONFIRMED")
        findings.append(f)
    return findings
