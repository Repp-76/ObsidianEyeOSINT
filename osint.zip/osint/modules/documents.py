"""
Module 12 - Public Document Metadata. Reads whatever metadata the file
format actually exposes; missing fields are reported as missing, not
guessed at.
"""

import os

from core.evidence import Finding, CONFIRMED_PUBLIC, NOT_FOUND, SOURCE_UNAVAILABLE


def _pdf(path: str) -> list[Finding]:
    try:
        from pypdf import PdfReader
    except ImportError:
        return [Finding("PDF Metadata", SOURCE_UNAVAILABLE, "pypdf", "pypdf package not installed", "NONE", "n/a")]

    try:
        reader = PdfReader(path)
        meta = reader.metadata or {}
    except Exception as exc:
        return [Finding("PDF Metadata", SOURCE_UNAVAILABLE, "pypdf", f"Could not parse file: {exc}", "NONE",
                         "pypdf PdfReader")]

    findings = [Finding("Page Count", CONFIRMED_PUBLIC, path, str(len(reader.pages)), "HIGH", "pypdf PdfReader")]
    field_map = {"Author": "/Author", "Creator": "/Creator", "Producer": "/Producer",
                 "Title": "/Title", "Subject": "/Subject", "CreationDate": "/CreationDate",
                 "ModDate": "/ModDate"}
    for label, key in field_map.items():
        value = meta.get(key)
        if value:
            findings.append(Finding(label, CONFIRMED_PUBLIC, path, str(value), "HIGH", "pypdf metadata dict"))
        else:
            findings.append(Finding(label, NOT_FOUND, path, "Field not present in document metadata", "HIGH",
                                     "pypdf metadata dict"))
    return findings


def _docx(path: str) -> list[Finding]:
    try:
        import docx
    except ImportError:
        return [Finding("DOCX Metadata", SOURCE_UNAVAILABLE, "python-docx", "python-docx package not installed",
                         "NONE", "n/a")]

    try:
        doc = docx.Document(path)
        props = doc.core_properties
    except Exception as exc:
        return [Finding("DOCX Metadata", SOURCE_UNAVAILABLE, "python-docx", f"Could not parse file: {exc}",
                         "NONE", "python-docx Document")]

    fields = {"Author": props.author, "Last Modified By": props.last_modified_by, "Title": props.title,
              "Subject": props.subject, "Created": props.created, "Modified": props.modified}
    findings = []
    for label, value in fields.items():
        if value:
            findings.append(Finding(label, CONFIRMED_PUBLIC, path, str(value), "HIGH", "python-docx core_properties"))
        else:
            findings.append(Finding(label, NOT_FOUND, path, "Field not present in document metadata", "HIGH",
                                     "python-docx core_properties"))
    return findings


def _xlsx(path: str) -> list[Finding]:
    try:
        import openpyxl
    except ImportError:
        return [Finding("XLSX Metadata", SOURCE_UNAVAILABLE, "openpyxl", "openpyxl package not installed",
                         "NONE", "n/a")]

    try:
        wb = openpyxl.load_workbook(path, read_only=True)
        props = wb.properties
    except Exception as exc:
        return [Finding("XLSX Metadata", SOURCE_UNAVAILABLE, "openpyxl", f"Could not parse file: {exc}",
                         "NONE", "openpyxl load_workbook")]

    fields = {"Creator": props.creator, "Last Modified By": props.lastModifiedBy, "Title": props.title,
              "Created": props.created, "Modified": props.modified}
    findings = [Finding("Sheet Names", CONFIRMED_PUBLIC, path, ", ".join(wb.sheetnames), "HIGH",
                         "openpyxl load_workbook")]
    for label, value in fields.items():
        if value:
            findings.append(Finding(label, CONFIRMED_PUBLIC, path, str(value), "HIGH", "openpyxl properties"))
        else:
            findings.append(Finding(label, NOT_FOUND, path, "Field not present in document metadata", "HIGH",
                                     "openpyxl properties"))
    return findings


def _pptx(path: str) -> list[Finding]:
    try:
        from pptx import Presentation
    except ImportError:
        return [Finding("PPTX Metadata", SOURCE_UNAVAILABLE, "python-pptx", "python-pptx package not installed",
                         "NONE", "n/a")]

    try:
        pres = Presentation(path)
        props = pres.core_properties
    except Exception as exc:
        return [Finding("PPTX Metadata", SOURCE_UNAVAILABLE, "python-pptx", f"Could not parse file: {exc}",
                         "NONE", "python-pptx Presentation")]

    fields = {"Author": props.author, "Last Modified By": props.last_modified_by, "Title": props.title,
              "Created": props.created, "Modified": props.modified}
    findings = [Finding("Slide Count", CONFIRMED_PUBLIC, path, str(len(pres.slides)), "HIGH",
                         "python-pptx Presentation")]
    for label, value in fields.items():
        if value:
            findings.append(Finding(label, CONFIRMED_PUBLIC, path, str(value), "HIGH", "python-pptx core_properties"))
        else:
            findings.append(Finding(label, NOT_FOUND, path, "Field not present in document metadata", "HIGH",
                                     "python-pptx core_properties"))
    return findings


HANDLERS = {".pdf": _pdf, ".docx": _docx, ".xlsx": _xlsx, ".pptx": _pptx}


def run(path: str) -> list[Finding]:
    path = os.path.expanduser(path.strip())
    if not os.path.isfile(path):
        return [Finding("File Access", NOT_FOUND, path, "File does not exist at the given path", "HIGH",
                         "Local filesystem check")]

    ext = os.path.splitext(path)[1].lower()
    handler = HANDLERS.get(ext)
    if not handler:
        return [Finding("Format Support", NOT_FOUND, path,
                         f"'{ext}' is not a supported format (supported: {', '.join(HANDLERS)})", "HIGH",
                         "Extension check")]
    return handler(path)
