"""
Module 15 - OSINT Report Generator. Every other module already writes its
own JSON report right after it runs (see core/reporter.py); this module
is the browser for what has accumulated in reports/ so far.
"""

import json

from config.settings import REPORTS_DIR
from core.evidence import Finding, CONFIRMED_PUBLIC, NOT_FOUND


def run() -> list[Finding]:
    REPORTS_DIR.mkdir(exist_ok=True)
    files = sorted(REPORTS_DIR.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)

    if not files:
        return [Finding("Saved Reports", NOT_FOUND, str(REPORTS_DIR),
                         "No reports have been generated yet this session or before it", "HIGH",
                         "Directory listing")]

    findings = [Finding("Saved Reports", CONFIRMED_PUBLIC, str(REPORTS_DIR),
                         f"{len(files)} report(s) on disk", "HIGH", "Directory listing")]

    for path in files[:10]:
        try:
            with open(path, encoding="utf-8") as fh:
                data = json.load(fh)
            module = data.get("scan", {}).get("module", "unknown")
            timestamp = data.get("scan", {}).get("timestamp", "unknown")
            finding_count = len(data.get("findings", []))
            findings.append(Finding(path.name, CONFIRMED_PUBLIC, str(path),
                                     f"Module: {module}, Timestamp: {timestamp}, Findings: {finding_count}",
                                     "HIGH", "Read and parsed saved JSON report"))
        except (json.JSONDecodeError, OSError) as exc:
            findings.append(Finding(path.name, "SOURCE_UNAVAILABLE", str(path), f"Could not read file: {exc}",
                                     "NONE", "Read saved JSON report"))

    return findings
