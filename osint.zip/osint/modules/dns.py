"""
Module 05 - DNS Intelligence. Full record dump across the common types.
"""

from core import dns_client
from core.evidence import Finding, CONFIRMED_PUBLIC, NOT_FOUND, LOOKUP_FAILED


def run(domain: str) -> list[Finding]:
    findings = []
    for rtype in dns_client.RECORD_TYPES:
        res = dns_client.query(domain, rtype)
        if res.ok:
            findings.append(Finding(f"{rtype} Record", CONFIRMED_PUBLIC, "DNS resolver",
                                     "; ".join(res.records), "HIGH", f"DNS {rtype} query"))
        elif res.error == "NXDOMAIN":
            findings.append(Finding(f"{rtype} Record", NOT_FOUND, "DNS resolver",
                                     "Domain does not exist", "HIGH", f"DNS {rtype} query"))
        elif res.error == "NO_ANSWER":
            findings.append(Finding(f"{rtype} Record", NOT_FOUND, "DNS resolver",
                                     f"No {rtype} record published", "HIGH", f"DNS {rtype} query"))
        else:
            findings.append(Finding(f"{rtype} Record", LOOKUP_FAILED, "DNS resolver",
                                     f"Lookup error: {res.error}", "NONE", f"DNS {rtype} query"))

    dnssec = dns_client.has_dnssec(domain)
    if dnssec.ok:
        findings.append(Finding("DNSSEC", CONFIRMED_PUBLIC, "DNS resolver", "DNSKEY present", "HIGH",
                                 "DNS DNSKEY query"))
    elif dnssec.error in ("NXDOMAIN", "NO_ANSWER"):
        findings.append(Finding("DNSSEC", NOT_FOUND, "DNS resolver", "No DNSKEY record found", "HIGH",
                                 "DNS DNSKEY query"))
    else:
        findings.append(Finding("DNSSEC", LOOKUP_FAILED, "DNS resolver", f"Lookup error: {dnssec.error}",
                                 "NONE", "DNS DNSKEY query"))
    return findings
