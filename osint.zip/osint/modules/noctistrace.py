"""
Module 16 - NoctisTrace, Global Phone Reputation Intelligence.

Parses and validates an international phone number locally, then asks
whichever public/authorized sources are configured what they say about it.
Everything a source says is kept attributed to that source; nothing here
decides that a number belongs to anyone or that anyone is a criminal.
"""

import logging
import os
import re
from datetime import datetime

from rich import box
from rich.markup import escape
from rich.panel import Panel

from config import settings
from config.settings import APP_NAME, APP_VERSION, DEVELOPER
from core import reporter
from modules.noctistrace_sources import (
    TraceFinding, SourceResult, LOCAL_RULES, SOURCE_UNAVAILABLE, ACCESS_RESTRICTED,
    check_ipqs, check_twilio_caller_name, semak_mule_pointer,
)
from utils import terminal
from utils.logging import get_logger
from utils.timestamps import now_iso

try:
    import phonenumbers
    from phonenumbers import carrier, geocoder, timezone
except ImportError:
    phonenumbers = None

log = get_logger()

TITLE = "NoctisTrace \u2014 Global Phone Reputation Intelligence"
TARGET_TYPE = "phone_number"
LOCAL_SOURCE = "libphonenumber (offline)"
LOCAL_SOURCE_URL = "https://pypi.org/project/phonenumbers/"

_ALLOWED_INPUT = re.compile(r"^\+[0-9\s().\-]+$")


# ------------------------------------------------------------------ logging hygiene

class _SecretFilter(logging.Filter):
    """The shared reporter logs raw requests exceptions, and those can carry
    the Telegram bot URL. Redact secrets from every record before it is written."""

    _BOT_URL = re.compile(r"bot\d{6,}:[A-Za-z0-9_\-]{20,}")

    def filter(self, record: logging.LogRecord) -> bool:
        text = self._BOT_URL.sub("bot<redacted>", record.getMessage())
        for name in ("TELEGRAM_BOT_TOKEN", "IPQS_API_KEY", "TWILIO_AUTH_TOKEN"):
            secret = getattr(settings, name, None) or os.getenv(name, "")
            if len(secret) >= 8:
                text = text.replace(secret, "<redacted>")
        record.msg, record.args = text, ()
        return True


if not any(isinstance(f, _SecretFilter) for f in log.filters):
    log.addFilter(_SecretFilter())


# ------------------------------------------------------------------ parsing / validation

class ParsedNumber:
    def __init__(self, ok, code="", message="", hint="", number=None, e164=""):
        self.ok, self.code, self.message, self.hint = ok, code, message, hint
        self.number, self.e164 = number, e164

    @property
    def region(self):
        return phonenumbers.region_code_for_number(self.number) if self.ok else None


def _reject(code: str, message: str, hint: str = "") -> ParsedNumber:
    return ParsedNumber(False, code=code, message=message, hint=hint)


def parse_number(raw: str) -> ParsedNumber:
    if phonenumbers is None:
        return _reject("DEPENDENCY_MISSING", "The 'phonenumbers' package is not installed.",
                       "Run: pip install -r requirements.txt")

    text = (raw or "").strip()
    if not text:
        return _reject("EMPTY", "No phone number was entered.")
    if len(text) > 32:
        return _reject("TOO_LONG", "That input is too long to be a phone number.")
    if text.startswith("00"):
        text = "+" + text[2:]
    if not text.startswith("+"):
        return _reject("MISSING_COUNTRY_CODE",
                       "Phone numbers must be entered in international format.",
                       "Start with + and the country code, for example +60112345678.")
    if not _ALLOWED_INPUT.match(text):
        return _reject("MALFORMED", "Only digits, spaces, dashes, dots and brackets may follow the leading +.")

    try:
        number = phonenumbers.parse(text, None)
    except phonenumbers.NumberParseException as exc:
        exc_type = phonenumbers.NumberParseException
        reasons = {
            exc_type.INVALID_COUNTRY_CODE: ("INVALID_COUNTRY_CODE", "The country calling code is not recognised."),
            exc_type.NOT_A_NUMBER: ("NOT_A_NUMBER", "That does not look like a phone number."),
            exc_type.TOO_SHORT_AFTER_IDD: ("TOO_SHORT", "The number is too short after the country code."),
            exc_type.TOO_SHORT_NSN: ("TOO_SHORT", "The number is too short to be a phone number."),
            exc_type.TOO_LONG: ("TOO_LONG", "The number is too long to be a phone number."),
        }
        code, message = reasons.get(exc.error_type, ("UNPARSEABLE", "The number could not be parsed."))
        return _reject(code, message)

    if not phonenumbers.is_valid_number(number):
        if phonenumbers.is_possible_number(number):
            message = ("The length is plausible but the number is not in a range assigned in that country's "
                       "numbering plan. (The bundled numbering data may also be out of date.)")
        else:
            message = "The length is not possible for a number with that country code."
        return _reject("INVALID_NUMBER", message)

    return ParsedNumber(True, number=number,
                        e164=phonenumbers.format_number(number, phonenumbers.PhoneNumberFormat.E164))


def mask_number(number) -> str:
    national = str(number.national_number)
    if len(national) >= 8:
        return f"+{number.country_code} {national[:2]}{'*' * (len(national) - 5)}{national[-3:]}"
    return f"+{number.country_code} {'*' * (len(national) - 2)}{national[-2:]}"


def _type_name(number) -> str:
    code = phonenumbers.number_type(number)
    for name, value in vars(phonenumbers.PhoneNumberType).items():
        if name.isupper() and value == code:
            return name
    return "UNKNOWN"


def build_validation(parsed: ParsedNumber) -> dict:
    number = parsed.number
    region = parsed.region
    country = geocoder.country_name_for_number(number, "en") or (region or "Non-geographic")
    location = geocoder.description_for_number(number, "en")
    zones = [z for z in timezone.time_zones_for_number(number) if z != "Etc/Unknown"]
    carrier_hint = carrier.name_for_number(number, "en") or None
    number_type = _type_name(number)

    evidence = TraceFinding(
        section="validation", source=LOCAL_SOURCE, source_url=LOCAL_SOURCE_URL,
        finding_type="number_validation", original_label=mask_number(number),
        normalized_label="valid_numbering_plan_format", verification_status=LOCAL_RULES,
        confidence_reason="Checked against libphonenumber's bundled numbering-plan rules. No network source was used.",
        evidence_summary=(f"Country code +{number.country_code} ({country}); type {number_type}. "
                          "The number fits an assigned numbering range."),
        result="INFO")

    return {
        "status": "VALID_FORMAT",
        "syntax_valid": True,
        "possible_length": True,
        "country_calling_code": f"+{number.country_code}",
        "region_code": region,
        "country_name": country,
        "location": location or None,
        "number_type": number_type,
        "time_zones": zones,
        "carrier_hint": carrier_hint,
        "carrier_hint_note": ("Original carrier for this number range; it may have moved to another carrier "
                              "through porting." if carrier_hint else None),
        "reachability": {"status": "UNKNOWN", "source": None,
                         "note": "Syntactic validity does not show the number is assigned, active or reachable."},
        "evidence": evidence.to_dict(),
        "vendor_findings": [],
    }


# ------------------------------------------------------------------ collection / aggregation

def collect_sources(parsed: ParsedNumber) -> list:
    results = [check_ipqs(parsed.e164), check_twilio_caller_name(parsed.e164, parsed.region)]
    if parsed.region == "MY":
        results.append(semak_mule_pointer())
    return results


def _items(sources: list, section: str) -> list:
    return [f for s in sources for f in s.findings if f.section == section]


def _section_status(items: list, positive: str, negative: str, positive_status: str) -> str:
    # a manual-check pointer means an official source was not consulted: it
    # limits a NOT_FOUND to partial coverage but never becomes the status itself
    manual = any(f.finding_type == "manual_check_pointer" for f in items)
    items = [f for f in items if f.finding_type != "manual_check_pointer"]
    if any(f.result == positive for f in items):
        return positive_status
    failed = manual or any(f.verification_status in (SOURCE_UNAVAILABLE, ACCESS_RESTRICTED) for f in items)
    if any(f.result == negative for f in items):
        return "NOT_FOUND_PARTIAL_COVERAGE" if failed else "NOT_FOUND"
    if any(f.verification_status == SOURCE_UNAVAILABLE for f in items):
        return "SOURCE_UNAVAILABLE"
    if any(f.verification_status == ACCESS_RESTRICTED for f in items):
        return "ACCESS_RESTRICTED"
    return "UNKNOWN"


def build_tags(sources: list) -> list:
    flagged_sources = {f.source for s in sources for f in s.findings if f.result == "FLAGGED"}
    merged = {}

    def add(tag, source, basis):
        bases = merged.setdefault((tag, source), [])
        if basis not in bases:
            bases.append(basis)

    for src in sources:
        for f in src.findings:
            for tag, basis in f.tags:
                if tag == "#not_found" and f.source in flagged_sources:
                    continue
                add(tag, f.source, basis)
        if src.name in flagged_sources:
            add("#unverified", src.name, "flagged result is third-party and NOT_VERIFIED")
        if src.status == SOURCE_UNAVAILABLE:
            add("#source_unavailable", src.name, src.note)
        elif src.status == ACCESS_RESTRICTED:
            add("#access_restricted", src.name, src.note)

    return [{"tag": tag, "source": source, "basis": "; ".join(bases)}
            for (tag, source), bases in sorted(merged.items())]


def _limitations(parsed: ParsedNumber, sources: list) -> list:
    out = [
        "A valid format does not show that a number is assigned, active or reachable.",
        "Reputation labels are third-party assessments. No report found is not evidence that a number is safe.",
        "Caller IDs can be spoofed, so reports about a number may describe someone who was only displaying it.",
        "Coverage differs by country and by source; identical coverage is not available everywhere.",
        "Carrier hints reflect the original number allocation and may be out of date after porting.",
    ]
    if not any(s.status == "QUERIED" for s in sources):
        out.append("No online source returned data in this scan, so nothing is known about this number's reputation.")
    for s in sources:
        if s.status in ("NOT_CONFIGURED", "NOT_APPLICABLE", SOURCE_UNAVAILABLE, ACCESS_RESTRICTED):
            out.append(f"{s.name}: {s.note}")
    return out


def _verification_notes(sources: list) -> list:
    notes = ["OWNER NOT VERIFIED - no source used here confirms who owns or uses this number."]
    if any(f.result == "FLAGGED" for s in sources for f in s.findings):
        notes.append("Flagged results are vendor or community assessments. None is an officially confirmed finding.")
    if any(f.result == "PUBLIC_LABEL_FOUND" for s in sources for f in s.findings):
        notes.append("A caller-ID label is a public display label, not a legal subscriber record.")
    return notes


def _summary(payload: dict, sources: list) -> str:
    v = payload["validation"]
    parts = [f"The number is validly formatted for {v['country_name']} ({v['number_type'].replace('_', ' ').lower()}). "
             "That shows numbering-plan validity only, not that the line is assigned, active or reachable."]

    online = [s for s in sources if s.automated]
    answered = [s for s in online if s.status == "QUERIED"]
    flagged = sorted({f.source for s in sources for f in s.findings if f.result == "FLAGGED"})
    if flagged:
        parts.append(f"Reputation signals were reported by: {', '.join(flagged)}. They come from third parties and "
                     "none has been officially confirmed.")
    elif answered:
        parts.append(f"{len(answered)} of {len(online)} online sources returned data and none flagged this number. "
                     "That is not evidence that it is safe.")
    else:
        parts.append("No online source returned data, so the reputation of this number is unknown.")

    if payload["public_identity"]["status"] == "PUBLIC_LABEL_FOUND":
        parts.append("A public caller-ID label was returned; the owner is not verified.")
    return " ".join(parts)


def build_payload(parsed: ParsedNumber, sources: list) -> dict:
    validation = build_validation(parsed)
    for f in _items(sources, "validation"):
        validation["vendor_findings"].append(f.to_dict())
        if f.finding_type == "reachability" and f.normalized_label != "reachability_unknown":
            validation["reachability"] = {
                "status": "ACTIVE" if f.normalized_label == "reachability_active" else "INACTIVE",
                "source": f.source, "note": f.confidence_reason}

    identity, scam, spam = (_items(sources, s) for s in ("identity", "scam", "spam"))
    all_sources = [SourceResult(LOCAL_SOURCE, LOCAL_SOURCE_URL, "QUERIED",
                                "Offline numbering-plan metadata bundled with the phonenumbers package.")] + sources
    if any(s.automated and s.status in (SOURCE_UNAVAILABLE, ACCESS_RESTRICTED) for s in sources):
        status = "completed_with_gaps"
    elif any(s.status == "QUERIED" for s in sources):
        status = "completed"
    else:
        status = "completed_no_online_sources"

    payload = {
        "tool": {"name": APP_NAME, "version": APP_VERSION, "developer": DEVELOPER},
        "module": TITLE,
        "target_type": TARGET_TYPE,
        "masked_number": mask_number(parsed.number),
        "normalized_number": parsed.e164,
        "validation": validation,
        "public_identity": {
            "status": _section_status(identity, "PUBLIC_LABEL_FOUND", "NOT_FOUND", "PUBLIC_LABEL_FOUND"),
            "owner_verification": "OWNER NOT VERIFIED",
            "findings": [f.to_dict() for f in identity],
        },
        "scam_reports": {
            "status": _section_status(scam, "FLAGGED", "NO_REPORT_FOUND", "REPORTED_UNVERIFIED"),
            "official_confirmation": "NONE_OBTAINED",
            "findings": [f.to_dict() for f in scam],
        },
        "spam_reports": {
            "status": _section_status(spam, "FLAGGED", "NO_REPORT_FOUND", "REPORTED_UNVERIFIED"),
            "findings": [f.to_dict() for f in spam],
        },
        "tags": build_tags(sources),
        "sources": [s.to_dict() for s in all_sources],
        "limitations": _limitations(parsed, sources),
        "verification_notes": _verification_notes(sources),
        "timestamp": now_iso(),
        "status": status,
    }
    payload["summary"] = _summary(payload, sources)
    return payload


# ------------------------------------------------------------------ terminal report

_RESULT_COLOR = {
    "FLAGGED": "yellow", "PUBLIC_LABEL_FOUND": "green", "NO_REPORT_FOUND": "grey58", "NOT_FOUND": "grey58",
    "UNKNOWN": "yellow", "NOT_QUERIED": "grey42", "INFO": "white",
}
_VERIFY_COLOR = {
    "NOT_VERIFIED": "yellow", "NOT_FOUND": "grey58", "UNKNOWN": "yellow", "SOURCE_UNAVAILABLE": "red",
    "ACCESS_RESTRICTED": "red", "NOT_CONFIGURED": "grey42", "NOT_APPLICABLE": "grey42",
    "VERIFIED_LOCAL_RULES": "green",
}
_SECTION_COLOR = {
    "REPORTED_UNVERIFIED": "yellow", "PUBLIC_LABEL_FOUND": "green", "NOT_FOUND": "grey58",
    "NOT_FOUND_PARTIAL_COVERAGE": "grey58", "UNKNOWN": "yellow", "SOURCE_UNAVAILABLE": "red",
    "ACCESS_RESTRICTED": "red",
}


def _label(text: str) -> str:
    return escape(str(text).replace("_", " "))


def _print_findings(findings: list) -> None:
    if not findings:
        terminal.console.print("  [grey42]No entries.[/grey42]\n")
        return

    detailed = [f for f in findings if f["finding_type"] != "source_status"]
    unqueried = [f for f in findings if f["finding_type"] == "source_status"]

    for i, f in enumerate(detailed, start=1):
        rc = _RESULT_COLOR.get(f["result"], "white")
        vc = _VERIFY_COLOR.get(f["verification_status"], "white")
        terminal.console.print(f"[white][{i:02d}][/white] [bold white]{escape(f['source'])}[/bold white] "
                               f"[grey58]- {_label(f['finding_type'])}[/grey58]")
        terminal.console.print(f"     Result       : [{rc}]{_label(f['result'])}[/{rc}]")
        terminal.console.print(f"     Verification : [{vc}]{_label(f['verification_status'])}[/{vc}]")
        terminal.console.print(f"     Label        : {escape(f['original_label'])} [grey58]->[/grey58] {escape(f['normalized_label'])}")
        terminal.console.print(f"     Detail       : [grey70]{escape(f['evidence_summary'])}[/grey70]")
        terminal.console.print(f"     Basis        : [grey58]{escape(f['confidence_reason'])}[/grey58]")
        if f["source_url"]:
            terminal.console.print(f"     Source       : [grey58]{escape(f['source_url'])}[/grey58]")
        terminal.console.print()

    # sources that returned nothing get one short entry instead of a full block
    for f in unqueried:
        vc = _VERIFY_COLOR.get(f["verification_status"], "white")
        terminal.console.print(f"  [grey58]-[/grey58] [white]{escape(f['source'])}[/white]  [{vc}]{_label(f['verification_status'])}[/{vc}]")
        terminal.console.print(f"    [grey58]{escape(f['evidence_summary'])}[/grey58]")
    if unqueried:
        terminal.console.print()


def _section_head(title: str, status: str) -> None:
    color = _SECTION_COLOR.get(status, "white")
    terminal.console.rule(style="grey42")
    terminal.console.print(f"[bold blue]{title}[/bold blue]  [{color}]{_label(status)}[/{color}]\n")


def render_body(payload: dict, raw_input: str, started: datetime, completed: datetime) -> None:
    c = terminal.console
    v = payload["validation"]
    online = [s for s in payload["sources"] if s["automated"] and s["name"] != LOCAL_SOURCE]
    queried = sum(1 for s in online if s["status"] == "QUERIED")

    c.print()
    c.print(Panel(f"[bold white]OBSIDIANEYE OSINT[/bold white]\n[bold cyan]{escape(TITLE.upper())}[/bold cyan]",
                  box=box.DOUBLE, expand=False, border_style="blue"))

    c.print("[bold blue]Investigation Summary[/bold blue]")
    c.print(f"  {'Input':<14}: {escape(raw_input.strip())}")
    c.print(f"  {'Normalized':<14}: {escape(payload['masked_number'])} [grey58](masked)[/grey58]")
    c.print(f"  {'Module':<14}: {escape(TITLE)}")
    c.print(f"  {'Started':<14}: {started.strftime('%Y-%m-%d %H:%M:%S')}")
    c.print(f"  {'Completed':<14}: {completed.strftime('%Y-%m-%d %H:%M:%S')}")
    c.print(f"  {'Duration':<14}: {terminal._fmt_duration((completed - started).total_seconds())}")
    c.print(f"  {'Sources':<14}: {queried} of {len(online)} online sources answered (+ offline numbering rules)")
    c.print(f"  {'Report Status':<14}: {payload['status'].upper()}")

    terminal.console.rule(style="grey42")
    c.print("[bold blue]VALIDATION[/bold blue]  [green]VALID FORMAT[/green]\n")
    c.print(f"  {'Country/Region':<18}: {escape(v['country_name'])} ({escape(str(v['region_code'] or 'n/a'))}), {v['country_calling_code']}")
    if v["location"] and v["location"] != v["country_name"]:
        c.print(f"  {'Location':<18}: {escape(v['location'])}")
    c.print(f"  {'Number Type':<18}: {_label(v['number_type'])}")
    if v["time_zones"]:
        c.print(f"  {'Time Zones':<18}: {escape(', '.join(v['time_zones']))}")
    if v["carrier_hint"]:
        c.print(f"  {'Carrier Hint':<18}: {escape(v['carrier_hint'])} [grey58](original allocation, may be ported)[/grey58]")
    r = v["reachability"]
    rcolor = "yellow" if r["status"] == "UNKNOWN" else "green" if r["status"] == "ACTIVE" else "red"
    c.print(f"  {'Active/Reachable':<18}: [{rcolor}]{r['status']}[/{rcolor}] [grey58]{escape(r['note'])}[/grey58]")
    if v["vendor_findings"]:
        c.print()
        _print_findings(v["vendor_findings"])
    else:
        c.print()

    ident = payload["public_identity"]
    _section_head("PUBLIC IDENTITY / BUSINESS INFORMATION", ident["status"])
    c.print(f"  [grey58]{ident['owner_verification']}[/grey58]\n")
    _print_findings(ident["findings"])

    scam = payload["scam_reports"]
    _section_head("SCAM REPORT SUMMARY", scam["status"])
    c.print("  [grey58]No official confirmation was obtained from any source. Vendor flags and allegations are shown as such.[/grey58]\n")
    _print_findings(scam["findings"])

    spam = payload["spam_reports"]
    _section_head("SPAM REPORT SUMMARY", spam["status"])
    _print_findings(spam["findings"])

    terminal.console.rule(style="grey42")
    c.print("[bold blue]EVIDENCE-BASED TAGS[/bold blue]\n")
    if payload["tags"]:
        for t in payload["tags"]:
            c.print(f"  [cyan]{escape(t['tag'])}[/cyan]  [grey58]{escape(t['source'])}: {escape(t['basis'])}[/grey58]")
    else:
        c.print("  [grey42]No tags - no source produced evidence to tag.[/grey42]")
    c.print()

    terminal.console.rule(style="grey42")
    c.print("[bold blue]SOURCES & TIMESTAMPS[/bold blue]\n")
    for s in payload["sources"]:
        color = _VERIFY_COLOR.get(s["status"], "green" if s["status"] == "QUERIED" else "white")
        c.print(f"  [white]{escape(s['name'])}[/white]  [{color}]{_label(s['status'])}[/{color}]  [grey58]{escape(s['timestamp'])}[/grey58]")
        c.print(f"    [grey58]{escape(s['url'])}[/grey58]")
    c.print()

    terminal.console.rule(style="grey42")
    c.print("[bold blue]LIMITATIONS[/bold blue]\n")
    for item in payload["limitations"]:
        c.print(f"  [grey70]- {escape(item)}[/grey70]")
    c.print()

    terminal.console.rule(style="grey42")
    c.print("[bold blue]SUMMARY[/bold blue]\n")
    for note in payload["verification_notes"]:
        c.print(f"  [grey58]{escape(note)}[/grey58]")
    c.print(f"\n  {escape(payload['summary'])}\n")


def render_footer(report_path, telegram_status: str, save_error: str = "") -> None:
    terminal.console.rule(style="grey42")
    terminal.console.print("[bold blue]REPORT SAVED[/bold blue]\n")
    if report_path:
        terminal.console.print(f"  JSON File : {escape(str(report_path))}")
    else:
        terminal.console.print(f"  [red]JSON File : NOT WRITTEN ({escape(save_error)})[/red]")
    terminal.console.print(f"  Telegram  : {escape(telegram_status)}")
    terminal.console.print()


# ------------------------------------------------------------------ entry point

def _save(payload: dict):
    try:
        return reporter.save_report(payload, "noctistrace"), ""
    except (OSError, TypeError, ValueError) as exc:
        log.error(f"NoctisTrace could not write its report: {type(exc).__name__}")
        return None, type(exc).__name__


def _deliver(path) -> str:
    if path is None:
        return "SKIPPED (no report file)"
    if not settings.telegram_configured():
        return "NOT CONFIGURED"
    try:
        sent, reason = reporter.send_to_telegram(path)
    except OSError as exc:
        log.error(f"NoctisTrace Telegram delivery failed reading the report: {type(exc).__name__}")
        return f"FAILED ({type(exc).__name__})"
    return "Delivered" if sent else f"FAILED ({reason})"


def scan_and_report(raw: str) -> None:
    started = datetime.now()
    parsed = parse_number(raw)
    if not parsed.ok:
        terminal.error(parsed.message)
        if parsed.hint:
            terminal.info(parsed.hint)
        return

    sources = collect_sources(parsed)
    completed = datetime.now()
    payload = build_payload(parsed, sources)

    path, save_error = _save(payload)
    render_body(payload, raw, started, completed)
    telegram_status = _deliver(path)
    render_footer(path, telegram_status, save_error)
