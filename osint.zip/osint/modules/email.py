"""
Module 03 - Email Intelligence. Only inspects publicly derivable
properties of the address; never attempts login or password recovery.
"""

from core import dns_client
from core.evidence import Finding, CONFIRMED_PUBLIC, NOT_FOUND, LOOKUP_FAILED, requires_api
from utils.validation import is_valid_email

# small, well-known set of disposable mail providers - not fabricated,
# these are widely published domains used by disposable inbox services
DISPOSABLE_DOMAINS = {
    "mailinator.com", "10minutemail.com", "guerrillamail.com", "tempmail.com",
    "yopmail.com", "trashmail.com", "getnada.com", "sharklasers.com",
}

KNOWN_PROVIDERS = {
    "gmail.com": "Google", "googlemail.com": "Google",
    "outlook.com": "Microsoft", "hotmail.com": "Microsoft", "live.com": "Microsoft",
    "yahoo.com": "Yahoo", "icloud.com": "Apple", "protonmail.com": "Proton", "proton.me": "Proton",
}


def run(email: str) -> list[Finding]:
    findings = []
    email = email.strip()

    if not is_valid_email(email):
        findings.append(Finding("Syntax Validation", NOT_FOUND, "RFC 5322 pattern",
                                 "Address does not match a valid email syntax", "HIGH", "Regex validation"))
        return findings

    findings.append(Finding("Syntax Validation", CONFIRMED_PUBLIC, "RFC 5322 pattern",
                             "Address matches valid email syntax", "HIGH", "Regex validation"))

    domain = email.split("@", 1)[1].lower()
    findings.append(Finding("Domain", CONFIRMED_PUBLIC, "n/a", domain, "HIGH", "Parsed from address"))

    mx = dns_client.query(domain, "MX")
    if mx.ok:
        findings.append(Finding("MX Record", CONFIRMED_PUBLIC, "DNS resolver", "; ".join(mx.records),
                                 "HIGH", "DNS MX query"))
    elif mx.error in ("NXDOMAIN", "NO_ANSWER"):
        findings.append(Finding("MX Record", NOT_FOUND, "DNS resolver",
                                 "Domain does not accept mail (no MX record)", "HIGH", "DNS MX query"))
    else:
        findings.append(Finding("MX Record", LOOKUP_FAILED, "DNS resolver", f"Lookup error: {mx.error}",
                                 "NONE", "DNS MX query"))

    provider = KNOWN_PROVIDERS.get(domain)
    if provider:
        findings.append(Finding("Mail Provider", CONFIRMED_PUBLIC, "Known provider list", provider,
                                 "MEDIUM", "Matched against a list of well-known consumer mail domains"))
    else:
        findings.append(Finding("Mail Provider", NOT_FOUND, "Known provider list",
                                 "Domain not in the known consumer provider list (may still be a private/business mail host)",
                                 "LOW", "Matched against a list of well-known consumer mail domains"))

    if domain in DISPOSABLE_DOMAINS:
        findings.append(Finding("Disposable Email Check", CONFIRMED_PUBLIC, "Known disposable domain list",
                                 "Domain matches a known disposable/temporary mail service", "HIGH",
                                 "Matched against a static list of known disposable domains"))
    else:
        findings.append(Finding("Disposable Email Check", NOT_FOUND, "Known disposable domain list",
                                 "Domain not found in known disposable mail service list", "MEDIUM",
                                 "Matched against a static list of known disposable domains"))

    findings.append(requires_api("Public Breach Correlation", "Have I Been Pwned", "HIBP_API_KEY"))
    return findings
