"""
Module 11 - Digital Footprint Analyzer. Summarizes findings already
collected earlier in the same session - it does not invent new lookups,
it only counts what other modules already found.
"""

from core.evidence import Finding, CONFIRMED_PUBLIC, POSSIBLE_MATCH, NOT_FOUND


def run(session_results: dict) -> list[Finding]:
    if not session_results:
        return [Finding("Digital Footprint Summary", NOT_FOUND, "session history",
                         "No other modules have been run yet this session - nothing to summarize.",
                         "NONE", "In-memory session aggregation")]

    public_profiles = 0
    domains_seen = 0
    documents_seen = 0
    metadata_observations = 0

    for module_name, findings in session_results.items():
        for f in findings:
            if module_name in ("Username Intelligence", "Social Profile Discovery") and \
                    f.status in (CONFIRMED_PUBLIC, POSSIBLE_MATCH, "VERIFIED_PUBLIC_PROFILE", "POSSIBLE_MATCH"):
                public_profiles += 1
            if module_name == "Domain Intelligence" and f.status == CONFIRMED_PUBLIC:
                domains_seen += 1
            if module_name == "Public Document Metadata":
                documents_seen += 1
            if module_name == "Image Metadata Intelligence" and f.status == CONFIRMED_PUBLIC:
                metadata_observations += 1

    summary = (
        f"Public Profiles Found: {public_profiles}\n"
        f"Domain Findings: {domains_seen}\n"
        f"Documents Reviewed: {documents_seen}\n"
        f"Metadata Observations: {metadata_observations}"
    )

    findings = [
        Finding("Digital Footprint Summary", CONFIRMED_PUBLIC, "session history", summary, "MEDIUM",
                "Aggregated counts from modules run earlier in this session"),
        Finding("Identity Disclaimer", CONFIRMED_PUBLIC, "n/a",
                "Matching usernames or profile references do not confirm a specific real-world individual.",
                "NONE", "Static disclaimer"),
    ]
    return findings
