"""
Module 01 - Username Intelligence.

Checks a username against real public profile URLs. Platforms that render
their profile pages through JavaScript or actively fingerprint/anti-bot a
plain HTTP client (Instagram, TikTok, X, Threads, Facebook, LinkedIn) are
reported as BLOCKED with an explanation instead of guessed at - a 200/404
status from those sites through a bare GET request is not reliable enough
to call a finding.
"""

from core import http_client
from core.evidence import Finding, CONFIRMED_PUBLIC, POSSIBLE_MATCH, NOT_FOUND, UNKNOWN, BLOCKED

DISCLAIMER = "A matching username does not prove that the profile belongs to the same individual."

# method: "status"      -> 200 means found, 404 means not found
#         "reddit_json" -> Reddit's about.json endpoint
#         "text_marker" -> look for a marker string in the HTML/JSON body
#         "blocked"     -> platform can't be checked reliably without JS/login, say so honestly
PLATFORMS = [
    {"name": "GitHub", "url": "https://github.com/{u}", "method": "status"},
    {"name": "GitLab", "url": "https://gitlab.com/{u}", "method": "status"},
    {"name": "Reddit", "url": "https://www.reddit.com/user/{u}/about.json", "method": "reddit_json"},
    {"name": "Medium", "url": "https://medium.com/@{u}", "method": "status"},
    {"name": "Dev.to", "url": "https://dev.to/{u}", "method": "status"},
    {"name": "CodePen", "url": "https://codepen.io/{u}", "method": "status"},
    {"name": "Pinterest", "url": "https://www.pinterest.com/{u}/", "method": "status"},
    {"name": "Mastodon (mastodon.social)", "url": "https://mastodon.social/@{u}", "method": "status"},
    {"name": "Twitch", "url": "https://www.twitch.tv/{u}", "method": "text_marker",
     "not_found_marker": "Sorry. Unless you"},
    {"name": "YouTube", "url": "https://www.youtube.com/@{u}", "method": "text_marker",
     "not_found_marker": "This page isn't available"},
    {"name": "Telegram", "url": "https://t.me/{u}", "method": "text_marker",
     "found_marker": "tgme_page_title"},
    {"name": "Instagram", "url": "https://www.instagram.com/{u}/", "method": "blocked",
     "reason": "Instagram requires a logged-in session and JavaScript rendering; a plain request cannot reliably tell FOUND from NOT FOUND."},
    {"name": "TikTok", "url": "https://www.tiktok.com/@{u}", "method": "blocked",
     "reason": "TikTok actively fingerprints and blocks automated HTTP clients."},
    {"name": "X / Twitter", "url": "https://x.com/{u}", "method": "blocked",
     "reason": "X now requires a logged-in session to view most profiles."},
    {"name": "Threads", "url": "https://www.threads.net/@{u}", "method": "blocked",
     "reason": "Threads renders profiles client-side and gates content behind login."},
    {"name": "Facebook", "url": "https://www.facebook.com/{u}", "method": "blocked",
     "reason": "Facebook requires a logged-in session for profile pages."},
    {"name": "LinkedIn", "url": "https://www.linkedin.com/in/{u}", "method": "blocked",
     "reason": "LinkedIn gates public profiles behind a login/authwall for automated clients."},
]


def _check_status(name: str, url: str) -> Finding:
    result = http_client.get(url)
    if not result.ok:
        return Finding(name, UNKNOWN, url, f"Request failed: {result.error}", "NONE",
                        "GET request, connection or timeout error", url=url)
    if result.status_code == 200:
        return Finding(name, CONFIRMED_PUBLIC, url, f"HTTP {result.status_code} on profile URL", "MEDIUM",
                        "GET request, 200 status treated as an existing page", url=result.final_url)
    if result.status_code == 404:
        return Finding(name, NOT_FOUND, url, f"HTTP {result.status_code} on profile URL", "MEDIUM",
                        "GET request, 404 status treated as no such page", url=url)
    return Finding(name, UNKNOWN, url, f"Unexpected HTTP {result.status_code}", "LOW",
                    "GET request, ambiguous status code", url=url)


def _check_reddit(username: str) -> Finding:
    url = f"https://www.reddit.com/user/{username}/about.json"
    result = http_client.get(url)
    if not result.ok:
        return Finding("Reddit", UNKNOWN, url, f"Request failed: {result.error}", "NONE", "GET .json endpoint")
    if result.status_code == 404:
        return Finding("Reddit", NOT_FOUND, url, "about.json returned 404", "MEDIUM", "GET .json endpoint", url=url)
    if result.status_code == 200:
        return Finding("Reddit", CONFIRMED_PUBLIC, url, "about.json returned account data", "HIGH",
                        "GET .json endpoint, valid JSON payload", url=url)
    return Finding("Reddit", UNKNOWN, url, f"Unexpected HTTP {result.status_code}", "LOW", "GET .json endpoint")


def _check_text_marker(platform: dict, username: str) -> Finding:
    name = platform["name"]
    url = platform["url"].format(u=username)
    result = http_client.get(url)
    if not result.ok:
        return Finding(name, UNKNOWN, url, f"Request failed: {result.error}", "NONE", "GET request + marker text")

    body = result.text or ""
    if "not_found_marker" in platform:
        if platform["not_found_marker"] in body:
            return Finding(name, NOT_FOUND, url, "Not-found marker text present in response", "LOW",
                            "GET request, checked for a known 'not found' phrase", url=url)
        return Finding(name, POSSIBLE_MATCH, url, "Page loaded without the known 'not found' phrase", "LOW",
                        "GET request, absence of not-found phrase is a weak positive signal", url=url)

    if "found_marker" in platform:
        if platform["found_marker"] in body:
            return Finding(name, POSSIBLE_MATCH, url, "Found marker text present in response", "LOW",
                            "GET request, checked for a known 'profile exists' phrase", url=url)
        return Finding(name, NOT_FOUND, url, "Found marker text absent from response", "LOW",
                        "GET request, expected profile markup was missing", url=url)

    return Finding(name, UNKNOWN, url, "No marker rule configured", "NONE", "n/a")


def _blocked(platform: dict, username: str) -> Finding:
    url = platform["url"].format(u=username)
    return Finding(platform["name"], BLOCKED, url, platform["reason"], "NONE",
                    "Not attempted - platform requires login/JS or actively blocks bots", url=url)


def run(username: str) -> list[Finding]:
    findings = []
    for platform in PLATFORMS:
        method = platform["method"]
        if method == "status":
            url = platform["url"].format(u=username)
            findings.append(_check_status(platform["name"], url))
        elif method == "reddit_json":
            findings.append(_check_reddit(username))
        elif method == "text_marker":
            findings.append(_check_text_marker(platform, username))
        elif method == "blocked":
            findings.append(_blocked(platform, username))
    return findings
