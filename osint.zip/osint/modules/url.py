"""
Module 09 - URL Intelligence. Structural analysis plus a real TLS probe;
this module observes, it does not attempt to exploit the target.
"""

from urllib.parse import urlparse, parse_qs

from core import http_client, tls_client
from core.evidence import Finding, CONFIRMED_PUBLIC, NOT_FOUND, LOOKUP_FAILED
from utils.validation import is_valid_ip


def run(url: str) -> list[Finding]:
    findings = []
    parsed = urlparse(url)

    findings.append(Finding("Scheme", CONFIRMED_PUBLIC, "n/a", parsed.scheme or "none", "HIGH", "urlparse"))
    findings.append(Finding("Hostname", CONFIRMED_PUBLIC, "n/a", parsed.hostname or "none", "HIGH", "urlparse"))
    findings.append(Finding("Port", CONFIRMED_PUBLIC, "n/a",
                             str(parsed.port) if parsed.port else "default for scheme", "HIGH", "urlparse"))

    query_params = parse_qs(parsed.query)
    if query_params:
        findings.append(Finding("Query Parameters", CONFIRMED_PUBLIC, "n/a",
                                 ", ".join(query_params.keys()), "HIGH", "urlparse"))
    if parsed.fragment:
        findings.append(Finding("Fragment", CONFIRMED_PUBLIC, "n/a", parsed.fragment, "HIGH", "urlparse"))

    if "@" in url.split("://", 1)[-1]:
        findings.append(Finding("Suspicious Pattern", "POSSIBLE_MATCH", "n/a",
                                 "URL contains an @ symbol before the host, which can mask the real destination",
                                 "MEDIUM", "Pattern check"))
    if parsed.hostname and is_valid_ip(parsed.hostname):
        findings.append(Finding("Suspicious Pattern", "POSSIBLE_MATCH", "n/a",
                                 "Host is a raw IP address rather than a domain name", "MEDIUM", "Pattern check"))
    if parsed.hostname and "xn--" in parsed.hostname:
        findings.append(Finding("Suspicious Pattern", "POSSIBLE_MATCH", "n/a",
                                 "Punycode-encoded hostname, often used to mimic legitimate domains", "MEDIUM",
                                 "Pattern check"))

    if parsed.scheme == "https":
        result = http_client.get(url)
        if result.ok:
            findings.append(Finding("HTTP Response", CONFIRMED_PUBLIC, url, f"HTTP {result.status_code}",
                                     "HIGH", "GET request", url=result.final_url))
            if result.history:
                findings.append(Finding("Redirects", CONFIRMED_PUBLIC, url,
                                         f"{len(result.history)} redirect(s) to {result.final_url}", "HIGH",
                                         "GET request with redirect history"))
        else:
            findings.append(Finding("HTTP Response", LOOKUP_FAILED, url, f"Request failed: {result.error}",
                                     "NONE", "GET request"))

        tls_result = tls_client.inspect(parsed.hostname, parsed.port or 443)
        if tls_result.ok:
            findings.append(Finding("TLS Certificate", CONFIRMED_PUBLIC, parsed.hostname,
                                     f"Issued by {tls_result.issuer.get('organizationName', 'unknown')}, "
                                     f"expires {tls_result.not_after} ({tls_result.days_remaining} days remaining)",
                                     "HIGH", "TLS handshake + certificate inspection"))
        else:
            findings.append(Finding("TLS Certificate", tls_result.error, parsed.hostname,
                                     "TLS handshake did not complete successfully", "NONE", "TLS handshake"))
    else:
        findings.append(Finding("HTTP Response", NOT_FOUND, url, "URL is not HTTPS, skipping live probe", "NONE",
                                 "Scheme check"))

    return findings
