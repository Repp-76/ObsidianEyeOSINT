"""
Source adapters for Module 16 (NoctisTrace).

Every adapter makes at most one request, never retries and never follows
redirects. Keys are read from the environment at call time and are never
placed in a finding, a log line or an error message - requests puts the
full URL into some exception messages, so exceptions are reduced to a
category here and the original text is dropped.
"""

import os
import socket
from dataclasses import dataclass, field, asdict
from typing import Optional

import requests

from config.settings import REQUEST_TIMEOUT, USER_AGENT
from utils.logging import get_logger
from utils.timestamps import now_iso

log = get_logger()

# verification_status values
NOT_VERIFIED = "NOT_VERIFIED"            # a source says so, nobody confirmed it
NOT_FOUND = "NOT_FOUND"                  # source answered and had nothing
UNKNOWN = "UNKNOWN"                      # source answered but the field was empty/unusable
SOURCE_UNAVAILABLE = "SOURCE_UNAVAILABLE"
ACCESS_RESTRICTED = "ACCESS_RESTRICTED"
NOT_CONFIGURED = "NOT_CONFIGURED"
NOT_APPLICABLE = "NOT_APPLICABLE"
LOCAL_RULES = "VERIFIED_LOCAL_RULES"

IPQS_URL = "https://www.ipqualityscore.com/api/json/phone/{key}/{number}"
IPQS_DOCS = "https://www.ipqualityscore.com/documentation/phone-number-validation-api/overview"
TWILIO_URL = "https://lookups.twilio.com/v2/PhoneNumbers/{number}"
TWILIO_DOCS = "https://www.twilio.com/docs/lookup/v2-api/caller-name"
SEMAK_MULE_URL = "https://semakmule.rmp.gov.my"

FRAUD_SCORE_SUSPICIOUS = 75  # IPQS documents 75+ as suspicious


@dataclass
class TraceFinding:
    section: str                      # validation | identity | scam | spam
    source: str
    source_url: Optional[str]
    finding_type: str
    original_label: str
    normalized_label: str
    verification_status: str
    confidence_reason: str
    evidence_summary: str
    result: str = "INFO"              # FLAGGED | NO_REPORT_FOUND | PUBLIC_LABEL_FOUND | NOT_FOUND | UNKNOWN | NOT_QUERIED | INFO
    tags: list = field(default_factory=list)   # [(tag, basis)]
    timestamp: str = field(default_factory=now_iso)

    def to_dict(self) -> dict:
        data = asdict(self)
        data.pop("section")
        data["tags"] = [{"tag": t, "basis": b} for t, b in self.tags]
        return data


@dataclass
class SourceResult:
    name: str
    url: str
    status: str                       # QUERIED | NOT_CONFIGURED | NOT_APPLICABLE | SOURCE_UNAVAILABLE | ACCESS_RESTRICTED
    note: str = ""
    findings: list = field(default_factory=list)
    timestamp: str = field(default_factory=now_iso)
    automated: bool = True            # False for pointers the tool never queries itself

    def to_dict(self) -> dict:
        return {"name": self.name, "url": self.url, "status": self.status,
                "note": self.note, "automated": self.automated, "timestamp": self.timestamp}


@dataclass
class _Reply:
    data: Optional[dict] = None
    error: Optional[str] = None       # category, see _ERROR_TEXT
    http_status: Optional[int] = None
    retry_after: Optional[str] = None


_ERROR_TEXT = {
    "DNS_FAILURE": "DNS lookup for the source failed",
    "CONNECTION_FAILED": "could not connect to the source",
    "TLS_ERROR": "TLS/certificate error while connecting to the source",
    "TIMEOUT": "the source did not answer before the timeout",
    "REDIRECTED": "the source answered with an unexpected redirect",
    "MALFORMED_RESPONSE": "the source returned a response that could not be parsed",
    "NETWORK_POLICY": "the request was blocked by a local network policy or proxy",
    "RATE_LIMITED": "the source rate-limited this request",
    "REJECTED": "the source rejected the credentials or the plan has no access",
    "HTTP_ERROR": "the source returned an unexpected HTTP error",
    "REQUEST_ERROR": "the request failed for an unclassified reason",
}


def _is_dns_failure(exc: BaseException) -> bool:
    """requests wraps resolver errors several layers deep in ConnectionError."""
    seen, stack = set(), [exc]
    while stack:
        current = stack.pop()
        if id(current) in seen:
            continue
        seen.add(id(current))
        if isinstance(current, socket.gaierror) or type(current).__name__ == "NameResolutionError":
            return True
        linked = [getattr(current, "__cause__", None), getattr(current, "__context__", None),
                  getattr(current, "reason", None), *getattr(current, "args", ())]
        stack.extend(x for x in linked if isinstance(x, BaseException))
    return False


def _fetch_json(url: str, auth=None, headers=None, params=None) -> _Reply:
    req_headers = {"User-Agent": USER_AGENT, "Accept": "application/json"}
    if headers:
        req_headers.update(headers)
    try:
        resp = requests.get(url, auth=auth, headers=req_headers, params=params,
                            timeout=REQUEST_TIMEOUT, allow_redirects=False)
    except requests.exceptions.SSLError:
        return _Reply(error="TLS_ERROR")
    except requests.exceptions.Timeout:
        return _Reply(error="TIMEOUT")
    except requests.exceptions.ConnectionError as exc:
        return _Reply(error="DNS_FAILURE" if _is_dns_failure(exc) else "CONNECTION_FAILED")
    except requests.exceptions.RequestException as exc:
        # class name only - the message can contain the request URL (and so the key)
        log.info(f"NoctisTrace request failed: {type(exc).__name__}")
        return _Reply(error="REQUEST_ERROR")

    status = resp.status_code
    if resp.headers.get("x-deny-reason"):
        return _Reply(error="NETWORK_POLICY", http_status=status)
    if 300 <= status < 400:
        return _Reply(error="REDIRECTED", http_status=status)
    if status == 429:
        return _Reply(error="RATE_LIMITED", http_status=status, retry_after=resp.headers.get("Retry-After"))
    if status in (401, 403):
        return _Reply(error="REJECTED", http_status=status)
    if status != 200:
        return _Reply(error="HTTP_ERROR", http_status=status)

    if len(resp.content) > 1_000_000:
        return _Reply(error="MALFORMED_RESPONSE", http_status=status)
    try:
        data = resp.json()
    except ValueError:
        return _Reply(error="MALFORMED_RESPONSE", http_status=status)
    if not isinstance(data, dict):
        return _Reply(error="MALFORMED_RESPONSE", http_status=status)
    return _Reply(data=data, http_status=status)


def _failure(name: str, url: str, covers: tuple, reply: _Reply) -> SourceResult:
    status = ACCESS_RESTRICTED if reply.error == "REJECTED" else SOURCE_UNAVAILABLE
    detail = _ERROR_TEXT.get(reply.error, "the source could not be queried")
    if reply.http_status:
        detail += f" (HTTP {reply.http_status})"
    if reply.retry_after:
        detail += f", retry after {reply.retry_after}"
    log.info(f"NoctisTrace source {name}: {reply.error} http={reply.http_status}")
    return _not_queried(name, url, covers, status, detail[0].upper() + detail[1:] + ".")


def _not_queried(name: str, url: str, covers: tuple, status: str, reason: str) -> SourceResult:
    """A source that produced no data still gets a visible entry in every
    section it would have spoken to, so an empty section is never read as
    'nothing found'."""
    src = SourceResult(name=name, url=url, status=status, note=reason)
    for section in covers:
        src.findings.append(TraceFinding(
            section=section, source=name, source_url=url, finding_type="source_status",
            original_label="not queried", normalized_label=status.lower(),
            verification_status=status,
            confidence_reason="No data was retrieved, so no conclusion can be drawn from this source.",
            evidence_summary=reason, result="NOT_QUERIED",
        ))
    return src


def _flag(data: dict, key: str) -> Optional[bool]:
    value = data.get(key)
    return value if isinstance(value, bool) else None


def _clean(text, limit: int = 160) -> str:
    return " ".join(str(text).split())[:limit]


# ---------------------------------------------------------------- IPQualityScore

def check_ipqs(e164: str) -> SourceResult:
    name = "IPQualityScore Phone Validation"
    covers = ("spam", "scam", "validation")
    key = os.getenv("IPQS_API_KEY", "").strip()
    if not key:
        return _not_queried(name, IPQS_DOCS, covers, NOT_CONFIGURED,
                            "IPQS_API_KEY is not set in .env, so this source was not queried.")

    reply = _fetch_json(IPQS_URL.format(key=key, number=e164.lstrip("+")))
    if reply.error:
        return _failure(name, IPQS_DOCS, covers, reply)

    data = reply.data
    if data.get("success") is not True:
        # the vendor message never contains the key, but keep it short anyway
        message = _clean(data.get("message") or "no message supplied")
        return _not_queried(name, IPQS_DOCS, covers, SOURCE_UNAVAILABLE,
                            f"The source reported an unsuccessful lookup: {message}")

    src = SourceResult(name=name, url=IPQS_DOCS, status="QUERIED",
                       note="Fields used: spammer, recent_abuse, risky, fraud_score, active, line_type, carrier, VOIP, prepaid. "
                            "Owner-name and identity fields are deliberately ignored.")
    src.findings += _ipqs_spam(data, name)
    src.findings += _ipqs_scam(data, name)
    src.findings += _ipqs_line(data, name)
    return src


def _ipqs_spam(data: dict, name: str) -> list:
    spammer = _flag(data, "spammer")
    common = dict(section="spam", source=name, source_url=IPQS_DOCS, finding_type="spam_report_signal")
    reason = "Vendor-aggregated signal; the underlying reports are not disclosed and were not independently verified."
    if spammer is True:
        return [TraceFinding(**common, original_label="spammer=true", normalized_label="spam_reported",
                             verification_status=NOT_VERIFIED, confidence_reason=reason, result="FLAGGED",
                             evidence_summary="IPQualityScore indicates this number was recently reported for spam or harassing calls/texts.",
                             tags=[("#spam_reported", "IPQS field spammer=true")])]
    if spammer is False:
        return [TraceFinding(**common, original_label="spammer=false", normalized_label="no_recent_spam_report",
                             verification_status=NOT_FOUND, result="NO_REPORT_FOUND",
                             confidence_reason="Absence in one vendor dataset at query time; it says nothing about other sources or the future.",
                             evidence_summary="No recent spam report in IPQualityScore data. This does not mean the number is safe.",
                             tags=[("#not_found", "IPQS field spammer=false")])]
    return [TraceFinding(**common, original_label="spammer=null", normalized_label="spam_status_unknown",
                         verification_status=UNKNOWN, result="UNKNOWN",
                         confidence_reason="The field was missing or not a boolean in the response.",
                         evidence_summary="IPQualityScore did not return a usable spam flag for this number.")]


def _ipqs_scam(data: dict, name: str) -> list:
    common = dict(section="scam", source=name, source_url=IPQS_DOCS)
    out = []

    recent_abuse, risky = _flag(data, "recent_abuse"), _flag(data, "risky")
    label = f"recent_abuse={_show(recent_abuse)}; risky={_show(risky)}"
    if recent_abuse or risky:
        basis = [f"IPQS field {k}=true" for k, v in (("recent_abuse", recent_abuse), ("risky", risky)) if v]
        out.append(TraceFinding(
            **common, finding_type="fraud_risk_flag", original_label=label,
            normalized_label="fraud_risk_flagged", verification_status=NOT_VERIFIED, result="FLAGGED",
            confidence_reason="Vendor risk assessment. It is not a police report or an official finding.",
            evidence_summary=("IPQualityScore flags: recent_abuse means recent or ongoing fraud association; risky is a broad "
                              "flag covering fraud, scams, robocalls, fake accounts or other unfriendly behaviour. "
                              "Neither is confirmed by an authority."),
            tags=[("#fraud_risk_signal", "; ".join(basis))]))
    elif recent_abuse is False and risky is False:
        out.append(TraceFinding(
            **common, finding_type="fraud_risk_flag", original_label=label,
            normalized_label="no_fraud_risk_flag", verification_status=NOT_FOUND, result="NO_REPORT_FOUND",
            confidence_reason="Absence in one vendor dataset at query time.",
            evidence_summary="IPQualityScore did not flag this number. This does not mean the number is safe.",
            tags=[("#not_found", "IPQS fields recent_abuse=false, risky=false")]))
    else:
        out.append(TraceFinding(
            **common, finding_type="fraud_risk_flag", original_label=label,
            normalized_label="fraud_risk_unknown", verification_status=UNKNOWN, result="UNKNOWN",
            confidence_reason="One or both flags were null or missing in the response.",
            evidence_summary="IPQualityScore did not return a complete fraud-risk flag pair for this number."))

    score = data.get("fraud_score")
    if isinstance(score, int) and not isinstance(score, bool) and 0 <= score <= 100:
        high = score >= FRAUD_SCORE_SUSPICIOUS
        out.append(TraceFinding(
            **common, finding_type="fraud_score", original_label=f"fraud_score={score}",
            normalized_label="fraud_score_suspicious" if high else "fraud_score_below_threshold",
            verification_status=NOT_VERIFIED, result="FLAGGED" if high else "INFO",
            confidence_reason="Proprietary vendor score (0-100); the model and its inputs are not public.",
            evidence_summary=(f"IPQualityScore fraud score {score}/100; the vendor documents 75 and above as suspicious."
                              if high else
                              f"IPQualityScore fraud score {score}/100, under the vendor's suspicious threshold of 75. "
                              "A low score is not proof of safety."),
            tags=[("#fraud_risk_signal", f"IPQS fraud_score={score} (>=75)")] if high else []))
    else:
        out.append(TraceFinding(
            **common, finding_type="fraud_score", original_label="fraud_score=missing",
            normalized_label="fraud_score_unknown", verification_status=UNKNOWN, result="UNKNOWN",
            confidence_reason="The score was missing or not an integer between 0 and 100.",
            evidence_summary="IPQualityScore did not return a usable fraud score for this number."))
    return out


def _ipqs_line(data: dict, name: str) -> list:
    common = dict(section="validation", source=name, source_url=IPQS_DOCS)
    out = []

    parts = []
    for key, label in (("line_type", "line type"), ("carrier", "carrier")):
        value = data.get(key)
        if isinstance(value, str) and value.strip() and value.strip().upper() != "N/A":
            parts.append(f"{label}: {_clean(value, 60)}")
    for key in ("VOIP", "prepaid"):
        value = _flag(data, key)
        if value is not None:
            parts.append(f"{key}: {str(value).lower()}")
    if data.get("valid") is False:
        parts.append("vendor considers the number invalid")
    if parts:
        out.append(TraceFinding(
            **common, finding_type="line_metadata", original_label="; ".join(parts),
            normalized_label="line_metadata", verification_status=NOT_VERIFIED, result="INFO",
            confidence_reason="Vendor carrier data; the carrier may reflect number portability or ranges, not the current subscriber.",
            evidence_summary="Line details reported by IPQualityScore: " + "; ".join(parts) + "."))

    active = _flag(data, "active")
    if active is None:
        out.append(TraceFinding(
            **common, finding_type="reachability", original_label="active=null",
            normalized_label="reachability_unknown", verification_status=UNKNOWN, result="UNKNOWN",
            confidence_reason="IPQS only returns this after an HLR add-on is enabled on the account.",
            evidence_summary="Whether the line is active or reachable could not be determined."))
    else:
        out.append(TraceFinding(
            **common, finding_type="reachability", original_label=f"active={str(active).lower()}",
            normalized_label="reachability_active" if active else "reachability_inactive",
            verification_status=NOT_VERIFIED, result="INFO",
            confidence_reason="Carrier-signal based vendor status at query time; it can change.",
            evidence_summary="IPQualityScore reports the line as " + ("active." if active else "not active.")))
    return out


def _show(value: Optional[bool]) -> str:
    return "null" if value is None else str(value).lower()


# ---------------------------------------------------------------- Twilio caller name

def check_twilio_caller_name(e164: str, region: Optional[str]) -> SourceResult:
    name = "Twilio Lookup - Caller Name (CNAM)"
    covers = ("identity",)
    sid = os.getenv("TWILIO_ACCOUNT_SID", "").strip()
    token = os.getenv("TWILIO_AUTH_TOKEN", "").strip()
    if not (sid and token):
        return _not_queried(name, TWILIO_DOCS, covers, NOT_CONFIGURED,
                            "TWILIO_ACCOUNT_SID / TWILIO_AUTH_TOKEN are not set in .env, so this source was not queried.")
    if region != "US":
        return _not_queried(name, TWILIO_DOCS, covers, NOT_APPLICABLE,
                            "Twilio documents Caller Name coverage for US carrier numbers only; this number was not sent.")

    reply = _fetch_json(TWILIO_URL.format(number=e164), auth=(sid, token), params={"Fields": "caller_name"})
    if reply.error:
        return _failure(name, TWILIO_DOCS, covers, reply)

    src = SourceResult(name=name, url=TWILIO_DOCS, status="QUERIED",
                       note="Caller-ID (CNAM) label as served by carriers. Consumer-type names are withheld.")
    common = dict(section="identity", source=name, source_url=TWILIO_DOCS, finding_type="caller_id_label")
    owner_note = "OWNER NOT VERIFIED - a caller-ID label is not proof of who owns or uses the line."

    caller = reply.data.get("caller_name")
    if not isinstance(caller, dict):
        src.findings.append(TraceFinding(
            **common, original_label="caller_name=null", normalized_label="UNKNOWN",
            verification_status=UNKNOWN, result="UNKNOWN",
            confidence_reason="The caller_name package was absent from the response.",
            evidence_summary="Twilio returned no caller-name object for this number. " + owner_note))
        return src

    if caller.get("error_code") is not None:
        code = _clean(caller.get("error_code"), 12)
        return _not_queried(name, TWILIO_DOCS, covers, SOURCE_UNAVAILABLE,
                            f"Twilio reported error code {code} for the caller-name package.")

    label, ctype = caller.get("caller_name"), caller.get("caller_type")
    ctype = ctype.upper() if isinstance(ctype, str) else None
    if not (isinstance(label, str) and label.strip()):
        src.findings.append(TraceFinding(
            **common, original_label="caller_name=null", normalized_label="NOT_FOUND",
            verification_status=NOT_FOUND, result="NOT_FOUND",
            confidence_reason="The carrier CNAM database returned no label at query time.",
            evidence_summary="No caller-ID label returned. Many valid numbers have none. " + owner_note))
    elif ctype == "BUSINESS":
        shown = _clean(label, 80)
        src.findings.append(TraceFinding(
            **common, original_label=shown, normalized_label="Public Business Name",
            verification_status=NOT_VERIFIED, result="PUBLIC_LABEL_FOUND",
            confidence_reason="Carrier-supplied CNAM text typed BUSINESS; CNAM records are not independently audited.",
            evidence_summary=f"Public caller-ID label '{shown}' (type BUSINESS). " + owner_note,
            tags=[("#business", "Twilio caller_type=BUSINESS"), ("#caller_id_label", "Twilio CNAM label present")]))
    else:
        src.findings.append(TraceFinding(
            **common, original_label="[withheld: non-business label]", normalized_label="Public Label (text withheld)",
            verification_status=NOT_VERIFIED, result="PUBLIC_LABEL_FOUND",
            confidence_reason="A CNAM label exists, but it is not typed BUSINESS and may be a private individual's name.",
            evidence_summary="A caller-ID label exists but its text is not recorded, to avoid storing a private person's name. " + owner_note,
            tags=[("#caller_id_label", "Twilio CNAM label present")]))
    return src


# ---------------------------------------------------------------- Semak Mule

def semak_mule_pointer() -> SourceResult:
    """Official Malaysian scam-number check. Public usage guides describe a
    CAPTCHA on the form, so it is never queried automatically - this only
    points the user at it."""
    name = "Semak Mule (PDRM CCID)"
    reason = ("Official PDRM CCID portal for checking phone numbers linked to reported commercial-crime cases. "
              "It is CAPTCHA-protected per public usage guides, so NoctisTrace does not query it. Check the number by hand.")
    src = SourceResult(name=name, url=SEMAK_MULE_URL, status=ACCESS_RESTRICTED, note=reason, automated=False)
    src.findings.append(TraceFinding(
        section="scam", source=name, source_url=SEMAK_MULE_URL, finding_type="manual_check_pointer",
        original_label="interactive CAPTCHA portal", normalized_label="manual_check_recommended",
        verification_status=ACCESS_RESTRICTED,
        confidence_reason="Not queried; no data was retrieved from this source.",
        evidence_summary=reason, result="NOT_QUERIED"))
    return src
