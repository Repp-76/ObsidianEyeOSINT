"""
Module 04 - IP Intelligence. Reverse DNS plus RDAP/WHOIS-derived network
ownership data. Geolocation here is network-level (country/region tied to
the registered allocation), never a claim about a physical address.
"""

import socket

from core.evidence import Finding, CONFIRMED_PUBLIC, NOT_FOUND, LOOKUP_FAILED, SOURCE_UNAVAILABLE


def _reverse_dns(ip: str) -> Finding:
    try:
        hostname, _, _ = socket.gethostbyaddr(ip)
        return Finding("Reverse DNS", CONFIRMED_PUBLIC, "socket.gethostbyaddr", hostname, "HIGH",
                        "PTR lookup via OS resolver")
    except socket.herror:
        return Finding("Reverse DNS", NOT_FOUND, "socket.gethostbyaddr", "No PTR record", "HIGH",
                        "PTR lookup via OS resolver")
    except socket.gaierror as exc:
        return Finding("Reverse DNS", LOOKUP_FAILED, "socket.gethostbyaddr", str(exc), "NONE",
                        "PTR lookup via OS resolver")


def _rdap(ip: str) -> list[Finding]:
    try:
        from ipwhois import IPWhois
        from ipwhois.exceptions import IPDefinedError, ASNRegistryError, HTTPLookupError
    except ImportError:
        return [Finding("Network Ownership (RDAP)", SOURCE_UNAVAILABLE, "ipwhois",
                         "ipwhois package is not installed", "NONE", "n/a")]

    try:
        obj = IPWhois(ip)
        result = obj.lookup_rdap(depth=1)
    except IPDefinedError:
        return [Finding("Network Ownership (RDAP)", NOT_FOUND, "RDAP", "Address is private/reserved, no public allocation",
                         "HIGH", "RDAP lookup via ipwhois")]
    except (ASNRegistryError, HTTPLookupError) as exc:
        return [Finding("Network Ownership (RDAP)", SOURCE_UNAVAILABLE, "RDAP", f"Lookup failed: {exc}",
                         "NONE", "RDAP lookup via ipwhois")]
    except Exception as exc:
        return [Finding("Network Ownership (RDAP)", SOURCE_UNAVAILABLE, "RDAP", f"Unexpected error: {exc}",
                         "NONE", "RDAP lookup via ipwhois")]

    findings = []
    asn = result.get("asn")
    asn_desc = result.get("asn_description")
    if asn:
        findings.append(Finding("ASN", CONFIRMED_PUBLIC, "RDAP", f"AS{asn} - {asn_desc}", "HIGH",
                                 "RDAP lookup via ipwhois"))

    network = result.get("network") or {}
    org_name = network.get("name")
    country = network.get("country")
    cidr = network.get("cidr")

    if org_name:
        findings.append(Finding("Network Name", CONFIRMED_PUBLIC, "RDAP", org_name, "HIGH", "RDAP lookup via ipwhois"))
    if cidr:
        findings.append(Finding("Allocated Network", CONFIRMED_PUBLIC, "RDAP", cidr, "HIGH", "RDAP lookup via ipwhois"))
    if country:
        findings.append(Finding("Registered Country", CONFIRMED_PUBLIC, "RDAP", country, "MEDIUM",
                                 "RDAP lookup via ipwhois - this is the allocation's registered country, not a precise location"))

    if not findings:
        findings.append(Finding("Network Ownership (RDAP)", NOT_FOUND, "RDAP", "RDAP returned no usable network data",
                                 "NONE", "RDAP lookup via ipwhois"))
    return findings


def run(ip: str) -> list[Finding]:
    findings = [_reverse_dns(ip)]
    findings.extend(_rdap(ip))
    findings.append(Finding(
        "Location Disclaimer", CONFIRMED_PUBLIC, "n/a",
        "RDAP data reflects where the IP block is registered, not the device's physical address.",
        "NONE", "Static disclaimer"))
    return findings
