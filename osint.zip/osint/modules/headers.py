"""
Module 07 - HTTP Security Header Analysis. A missing header is reported
as MISSING with a plain-English explanation, not automatically escalated
into a "critical vulnerability".
"""

from core import http_client
from core.evidence import Finding, LOOKUP_FAILED

SECURITY_HEADERS = {
    "Strict-Transport-Security": "Tells browsers to only ever connect over HTTPS, preventing downgrade attacks.",
    "Content-Security-Policy": "Restricts what scripts/styles/resources a page may load, reducing XSS impact.",
    "X-Content-Type-Options": "Stops browsers from guessing a file's type, reducing MIME-sniffing risks.",
    "X-Frame-Options": "Controls whether the page can be embedded in a frame, mitigating clickjacking.",
    "Referrer-Policy": "Controls how much of the URL is sent as the Referer header to other sites.",
    "Permissions-Policy": "Restricts which browser features (camera, mic, geolocation) the page may use.",
    "Cross-Origin-Opener-Policy": "Isolates the page's browsing context from cross-origin windows.",
    "Cross-Origin-Resource-Policy": "Controls whether other origins may load this site's resources.",
    "Cross-Origin-Embedder-Policy": "Requires embedded resources to explicitly opt in, enabling stronger isolation.",
}


def run(url: str) -> list[Finding]:
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    result = http_client.get(url)
    if not result.ok:
        return [Finding("HTTP Header Fetch", LOOKUP_FAILED, url, f"Request failed: {result.error}", "NONE",
                         "GET request - all header checks NOT_TESTED as a result")]

    findings = []
    lower_headers = {k.lower(): v for k, v in result.headers.items()}
    for header, explanation in SECURITY_HEADERS.items():
        value = lower_headers.get(header.lower())
        if value:
            findings.append(Finding(header, "PRESENT", "HTTP response header", f"Value: {value} - {explanation}",
                                     "HIGH", "Observed response header"))
        else:
            findings.append(Finding(header, "MISSING", "HTTP response header",
                                     f"Header not sent by the server. {explanation}", "HIGH",
                                     "Observed response header"))
    return findings
