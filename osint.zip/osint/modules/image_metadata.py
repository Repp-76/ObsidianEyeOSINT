"""
Module 08 - Image Metadata Intelligence. Everything runs locally on the
file the user points to; nothing is uploaded anywhere.
"""

import os

from PIL import Image, ExifTags

from core.evidence import Finding, CONFIRMED_PUBLIC, NOT_FOUND, SOURCE_UNAVAILABLE

GPS_TAG_ID = next((tag_id for tag_id, name in ExifTags.TAGS.items() if name == "GPSInfo"), None)


def _dms_to_decimal(dms, ref) -> float:
    degrees, minutes, seconds = dms
    value = float(degrees) + float(minutes) / 60 + float(seconds) / 3600
    if ref in ("S", "W"):
        value = -value
    return value


def run(path: str) -> list[Finding]:
    if not os.path.isfile(path):
        return [Finding("File Access", NOT_FOUND, path, "File does not exist at the given path", "HIGH",
                         "Local filesystem check")]

    findings = [
        Finding("Filename", CONFIRMED_PUBLIC, path, os.path.basename(path), "HIGH", "Local filesystem"),
        Finding("File Size", CONFIRMED_PUBLIC, path, f"{os.path.getsize(path)} bytes", "HIGH", "Local filesystem"),
    ]

    try:
        img = Image.open(path)
    except Exception as exc:
        findings.append(Finding("Image Parse", SOURCE_UNAVAILABLE, path, f"Could not open as image: {exc}",
                                 "NONE", "Pillow Image.open"))
        return findings

    findings.append(Finding("Format / Dimensions", CONFIRMED_PUBLIC, path,
                             f"{img.format}, {img.width}x{img.height}px, mode {img.mode}", "HIGH",
                             "Pillow Image.open"))

    exif = img.getexif()
    if not exif:
        findings.append(Finding("EXIF Metadata", NOT_FOUND, path, "No EXIF metadata present", "HIGH",
                                 "Pillow getexif()"))
        return findings

    readable = {}
    for tag_id, value in exif.items():
        tag_name = ExifTags.TAGS.get(tag_id, str(tag_id))
        readable[tag_name] = value

    for field, tag in (("Camera Make", "Make"), ("Camera Model", "Model"),
                        ("Software", "Software"), ("Date Taken", "DateTime"),
                        ("Orientation", "Orientation")):
        if tag in readable:
            findings.append(Finding(field, CONFIRMED_PUBLIC, path, str(readable[tag]), "HIGH",
                                     "Pillow EXIF tag read"))

    gps_ifd = exif.get_ifd(GPS_TAG_ID) if GPS_TAG_ID else None
    if gps_ifd:
        try:
            lat = _dms_to_decimal(gps_ifd[2], gps_ifd[1])
            lon = _dms_to_decimal(gps_ifd[4], gps_ifd[3])
            findings.append(Finding("GPS Coordinates", CONFIRMED_PUBLIC, path, f"{lat:.6f}, {lon:.6f}", "HIGH",
                                     "Pillow EXIF GPS IFD parsed to decimal degrees"))
            findings.append(Finding("GPS Warning", CONFIRMED_PUBLIC, "n/a",
                                     "GPS metadata may reveal where this photograph was taken.", "NONE",
                                     "Static warning"))
        except (KeyError, IndexError, ZeroDivisionError):
            findings.append(Finding("GPS Coordinates", SOURCE_UNAVAILABLE, path,
                                     "GPS IFD present but could not be parsed", "LOW", "Pillow EXIF GPS IFD"))
    else:
        findings.append(Finding("GPS Coordinates", NOT_FOUND, path, "No GPS metadata present", "HIGH",
                                 "Pillow EXIF GPS IFD"))

    return findings
