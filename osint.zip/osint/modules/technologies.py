"""
Module 06 - Website Technology Intelligence. Every detected technology is
tied to a concrete piece of evidence (a header value or an HTML pattern) -
nothing is guessed because it's "common".
"""

import re

from core import http_client
from core.evidence import Finding, CONFIRMED_PUBLIC, NOT_FOUND, LOOKUP_FAILED

HEADER_SIGNATURES = {
    "Server": "Web Server",
    "X-Powered-By": "Backend Framework",
}

HTML_SIGNATURES = [
    (r"wp-content|wp-includes", "WordPress (CMS)"),
    (r"Shopify\.theme|cdn\.shopify\.com", "Shopify"),
    (r"/sites/default/files|Drupal\.settings", "Drupal (CMS)"),
    (r"data-react-helmet|__NEXT_DATA__", "React / Next.js"),
    (r"ng-version=", "Angular"),
    (r"vue-app|__VUE__|data-v-", "Vue.js"),
    (r"jquery[.-]([\d.]+)?\.js", "jQuery"),
    (r"cdn\.jsdelivr\.net|cdnjs\.cloudflare\.com", "Third-party CDN (jsDelivr/cdnjs)"),
]

COOKIE_SIGNATURES = {
    "PHPSESSID": "PHP",
    "wordpress_logged_in": "WordPress",
    "laravel_session": "Laravel",
    "ci_session": "CodeIgniter",
}


def run(url: str) -> list[Finding]:
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    result = http_client.get(url)
    if not result.ok:
        return [Finding("Website Fetch", LOOKUP_FAILED, url, f"Request failed: {result.error}", "NONE",
                         "GET request")]

    findings = [Finding("Website Fetch", CONFIRMED_PUBLIC, url, f"HTTP {result.status_code}", "HIGH",
                         "GET request", url=result.final_url)]

    for header, label in HEADER_SIGNATURES.items():
        value = result.headers.get(header)
        if value:
            findings.append(Finding(label, CONFIRMED_PUBLIC, "HTTP response header", f"{header}: {value}",
                                     "HIGH", f"Observed {header} header"))

    if "cf-ray" in {k.lower() for k in result.headers}:
        findings.append(Finding("CDN", CONFIRMED_PUBLIC, "HTTP response header", "cf-ray header present (Cloudflare)",
                                 "HIGH", "Observed cf-ray header"))

    body = result.text or ""
    detected_any_html = False
    for pattern, label in HTML_SIGNATURES:
        if re.search(pattern, body, re.IGNORECASE):
            findings.append(Finding(label, CONFIRMED_PUBLIC, "HTML body", f"Matched pattern: {pattern}",
                                     "MEDIUM", "Regex match against page source"))
            detected_any_html = True

    set_cookie = result.headers.get("Set-Cookie", "")
    for cookie_name, label in COOKIE_SIGNATURES.items():
        if cookie_name in set_cookie:
            findings.append(Finding(label, CONFIRMED_PUBLIC, "Set-Cookie header", f"Cookie name: {cookie_name}",
                                     "MEDIUM", "Observed cookie name in response"))

    if not detected_any_html and len(findings) == 1:
        findings.append(Finding("Technology Fingerprint", NOT_FOUND, "HTML body + headers",
                                 "No known technology signatures matched", "NONE", "Regex + header matching"))

    return findings
