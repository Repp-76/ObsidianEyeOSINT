from datetime import datetime

from config.settings import MODULE_COUNT, telegram_configured
from core import reporter
from utils import terminal
from utils.logging import get_logger
from utils.validation import (
    is_valid_username, is_valid_domain, is_valid_email, is_valid_ip, is_valid_url,
)
from modules import (
    username, domain, email as email_mod, ip, dns as dns_mod, technologies, headers,
    image_metadata, url as url_mod, social, footprint, documents, username_monitor,
    breach, report as report_mod, noctistrace,
)

log = get_logger()

# each entry: title, prompt label, validator (or None), runner, needs_target
MODULE_TABLE = {
    "01": ("Username Intelligence", "Username", is_valid_username, username.run, True),
    "02": ("Domain Intelligence", "Domain", is_valid_domain, domain.run, True),
    "03": ("Email Intelligence", "Email address", is_valid_email, email_mod.run, True),
    "04": ("IP Intelligence", "IP address", is_valid_ip, ip.run, True),
    "05": ("DNS Intelligence", "Domain", is_valid_domain, dns_mod.run, True),
    "06": ("Website Technology Intelligence", "Website URL or domain", None, technologies.run, True),
    "07": ("HTTP Security Header Analysis", "Website URL or domain", None, headers.run, True),
    "08": ("Image Metadata Intelligence", "Path to local image file", None, image_metadata.run, True),
    "09": ("URL Intelligence", "Full URL (include http:// or https://)", is_valid_url, url_mod.run, True),
    "10": ("Social Profile Discovery", "Username or profile URL", None, social.run, True),
    "11": ("Digital Footprint Analyzer", None, None, None, False),
    "12": ("Public Document Metadata", "Path to local document (.pdf/.docx/.xlsx/.pptx)", None, documents.run, True),
    "13": ("Username Availability Monitor", "Username", is_valid_username, username_monitor.run, True),
    "14": ("Public Breach Exposure Check", "Email address", is_valid_email, breach.run, True),
    "15": ("OSINT Report Generator", None, None, None, False),
    "16": (noctistrace.TITLE, "Phone number (international format, e.g. +60112345678)", None,
           noctistrace.scan_and_report, True),
}

MENU_ORDER = [f"{i:02d}" for i in range(1, 17)]


def print_menu() -> None:
    terminal.heading("MAIN MENU")
    for key in MENU_ORDER:
        title, *_ = MODULE_TABLE[key]
        terminal.console.print(f"  [{key}] {title}")
    terminal.console.print("  [X] Exit")
    terminal.console.print()


IDENTITY_DISCLAIMER = (
    "A matching username does not prove that a profile belongs to the same individual. "
    "Results represent publicly observable information at the time of the scan."
)


def _handle_module(key: str, session_results: dict) -> None:
    title, prompt_label, validator, runner, needs_target = MODULE_TABLE[key]
    terminal.heading(title)

    target_value = None
    if needs_target:
        target_value = terminal.prompt(f"{prompt_label}: ")
        if not target_value:
            terminal.error("No input provided, returning to menu.")
            return
        if validator and not validator(target_value):
            terminal.error(f"'{target_value}' does not look like a valid {prompt_label.lower()}.")
            return

    if key == "16":
        # builds, saves and delivers its own report (different JSON shape)
        try:
            runner(target_value)
        except Exception as exc:
            log.exception(f"Unhandled error in module {title}")
            terminal.error(f"Module crashed unexpectedly: {type(exc).__name__}")
            terminal.warn("This has been logged. No fake results were produced.")
        return

    started = datetime.now()
    try:
        if key == "11":
            findings = footprint.run(session_results)
        elif key == "15":
            findings = report_mod.run()
        else:
            findings = runner(target_value)
    except Exception as exc:
        log.exception(f"Unhandled error in module {title}")
        terminal.error(f"Module crashed unexpectedly: {exc}")
        terminal.warn("This has been logged. No fake results were produced.")
        return
    completed = datetime.now()

    session_results[title] = findings

    target_dict = {"value": target_value} if target_value else {}
    target_type = (prompt_label or "none").split(" (")[0].lower().replace(" ", "_")
    report = reporter.build_report(title, target_dict, findings, started=started, completed=completed,
                                   target_type=target_type)
    try:
        path = reporter.save_report(report, title)
    except reporter.ReportError as exc:
        path = None
        terminal.error(f"JSON report not written: {exc}")

    # rendered first; the delivery runs at the Telegram line, so the report
    # is fully on screen before anything is sent and the line shows the real result
    terminal.render_module_report(
        module=title,
        target_label=prompt_label,
        target_value=target_value,
        findings=findings,
        started=started,
        completed=completed,
        sources_count=len(report["sources"]),
        report_path=path,
        telegram_status=lambda: reporter.deliver_and_describe(path),
        disclaimer=IDENTITY_DISCLAIMER if key in ("01", "10", "13") else None,
    )


def run() -> None:
    session_results: dict = {}

    while True:
        terminal.clear_screen()
        terminal.print_banner()
        terminal.console.print()
        terminal.print_status(MODULE_COUNT, telegram_configured())
        print_menu()

        choice = terminal.prompt("Select a module: ").strip().upper()

        if choice == "X":
            terminal.info("Exiting ObsidianEye OSINT.")
            return

        if choice not in MODULE_TABLE:
            terminal.error("Invalid selection.")
            terminal.prompt("Press ENTER to continue...")
            continue

        _handle_module(choice, session_results)

        terminal.console.print()
        again = terminal.prompt("Continue? [Y] Run from beginning   [X] Exit: ").strip().upper()
        if again == "X":
            terminal.info("Exiting ObsidianEye OSINT.")
            return
