"""
Real DNS queries via dnspython. A missing record and a failed lookup are
never the same thing here - callers get told exactly which happened.
"""

from dataclasses import dataclass
from typing import Optional

import dns.resolver
import dns.exception

RECORD_TYPES = ["A", "AAAA", "CNAME", "MX", "NS", "TXT", "SOA", "CAA", "SRV"]

# Used only when the system has no usable resolver configuration to read
# (e.g. /etc/resolv.conf missing or unreadable - common on Termux and some
# minimal containers). These are real public resolvers, not a fake result -
# queries still go out and get real answers, just not via the OS default.
_FALLBACK_NAMESERVERS = ["1.1.1.1", "1.0.0.1", "8.8.8.8", "8.8.4.4"]


@dataclass
class DnsResult:
    record_type: str
    ok: bool
    records: list
    error: Optional[str] = None  # "NXDOMAIN" | "NO_ANSWER" | "TIMEOUT" | "DNS_LOOKUP_ERROR" | "NO_RESOLVER_CONFIG"


def _build_resolver(timeout: float) -> dns.resolver.Resolver:
    """
    dns.resolver.Resolver() reads /etc/resolv.conf (or the platform
    equivalent) the moment it's constructed, and raises straight away if
    that file doesn't exist or can't be opened - this used to happen
    outside any try/except here, so a missing resolv.conf crashed every
    DNS-based module instead of being reported as a lookup failure.
    """
    try:
        resolver = dns.resolver.Resolver()
    except Exception:
        resolver = dns.resolver.Resolver(configure=False)
        resolver.nameservers = _FALLBACK_NAMESERVERS
    resolver.timeout = timeout
    resolver.lifetime = timeout
    return resolver


def query(domain: str, record_type: str, timeout: float = 5.0) -> DnsResult:
    try:
        resolver = _build_resolver(timeout)
    except Exception as exc:
        return DnsResult(record_type=record_type, ok=False, records=[],
                          error=f"NO_RESOLVER_CONFIG: {exc}")

    try:
        answer = resolver.resolve(domain, record_type)
        values = [rdata.to_text() for rdata in answer]
        return DnsResult(record_type=record_type, ok=True, records=values)
    except dns.resolver.NXDOMAIN:
        return DnsResult(record_type=record_type, ok=False, records=[], error="NXDOMAIN")
    except dns.resolver.NoAnswer:
        return DnsResult(record_type=record_type, ok=False, records=[], error="NO_ANSWER")
    except dns.exception.Timeout:
        return DnsResult(record_type=record_type, ok=False, records=[], error="TIMEOUT")
    except Exception:
        # covers NoNameservers and anything the resolver library throws that
        # isn't one of the above - reported honestly instead of swallowed
        return DnsResult(record_type=record_type, ok=False, records=[], error="DNS_LOOKUP_ERROR")


def has_dnssec(domain: str, timeout: float = 5.0) -> DnsResult:
    """
    DNSSEC presence is checked by looking for a DNSKEY record at the zone
    apex, not by inspecting SPF/DMARC TXT records (those are unrelated).
    """
    return query(domain, "DNSKEY", timeout=timeout)
