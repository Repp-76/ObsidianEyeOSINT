"""
Real DNS queries via dnspython. A missing record and a failed lookup are
never the same thing here - callers get told exactly which happened.
"""

from dataclasses import dataclass
from typing import Optional

import dns.resolver
import dns.exception

RECORD_TYPES = ["A", "AAAA", "CNAME", "MX", "NS", "TXT", "SOA", "CAA", "SRV"]


@dataclass
class DnsResult:
    record_type: str
    ok: bool
    records: list
    error: Optional[str] = None  # "NXDOMAIN" | "NO_ANSWER" | "TIMEOUT" | "DNS_LOOKUP_ERROR"


def query(domain: str, record_type: str, timeout: float = 5.0) -> DnsResult:
    resolver = dns.resolver.Resolver()
    resolver.timeout = timeout
    resolver.lifetime = timeout
    try:
        answer = resolver.resolve(domain, record_type)
        values = [rdata.to_text() for rdata in answer]
        return DnsResult(record_type=record_type, ok=True, records=values)
    except dns.resolver.NXDOMAIN:
        return DnsResult(record_type=record_type, ok=False, records=[], error="NXDOMAIN")
    except dns.resolver.NoAnswer:
        return DnsResult(record_type=record_type, ok=False, records=[], error="NO_ANSWER")
    except dns.exception.Timeout:
        return DnsResult(record_type=record_type, ok=False, records=[], error="TIMEOUT")
    except Exception:
        # covers NoNameservers and anything the resolver library throws that
        # isn't one of the above - reported honestly instead of swallowed
        return DnsResult(record_type=record_type, ok=False, records=[], error="DNS_LOOKUP_ERROR")


def has_dnssec(domain: str, timeout: float = 5.0) -> DnsResult:
    """
    DNSSEC presence is checked by looking for a DNSKEY record at the zone
    apex, not by inspecting SPF/DMARC TXT records (those are unrelated).
    """
    return query(domain, "DNSKEY", timeout=timeout)
