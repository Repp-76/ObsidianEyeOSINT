"""
Telegram delivery for ObsidianEye reports.

One place does the upload (sendDocument, multipart) and one place decides what
happened. A delivery only counts as SENT when Telegram answers HTTP 200 with
ok=true and echoes the document back. Every other outcome gets its own status,
and nothing here raises to the caller.

The bot token is part of the request URL, and requests puts URLs into some
exception messages. Exceptions are therefore reduced to a category and the
original text is never logged, stored or shown.

Reference: https://core.telegram.org/bots/api
"""

import json
import re
import socket
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import requests

from config import settings
from utils.logging import get_logger
from utils.timestamps import now_iso

log = get_logger()

API_BASE = "https://api.telegram.org"
TIMEOUT = (8, 30)                      # connect, read
MAX_UPLOAD_BYTES = 50 * 1024 * 1024    # Bot API limit for sendDocument

SENT = "SENT"
NOT_CONFIGURED = "NOT_CONFIGURED"
INVALID_CONFIGURATION = "INVALID_CONFIGURATION"
AUTHENTICATION_FAILED = "AUTHENTICATION_FAILED"
CHAT_NOT_FOUND = "CHAT_NOT_FOUND"
BOT_FORBIDDEN = "BOT_FORBIDDEN"
RATE_LIMITED = "RATE_LIMITED"
NETWORK_ERROR = "NETWORK_ERROR"
FILE_ERROR = "FILE_ERROR"
TELEGRAM_API_ERROR = "TELEGRAM_API_ERROR"
UNKNOWN_ERROR = "UNKNOWN_ERROR"

_TOKEN_RE = re.compile(r"^\d{5,}:[A-Za-z0-9_-]{30,}$")
_CHAT_RE = re.compile(r"^(-?\d{5,}|@[A-Za-z][A-Za-z0-9_]{4,})$")
_BOT_URL_RE = re.compile(r"bot\d{5,}:[A-Za-z0-9_\-]{20,}")


@dataclass
class DeliveryResult:
    status: str
    detail: str = ""
    http_status: Optional[int] = None
    retry_after: Optional[int] = None
    message_id: Optional[int] = None
    attempted_at: str = ""

    @property
    def ok(self) -> bool:
        return self.status == SENT

    def describe(self) -> str:
        """One safe line for the terminal."""
        if self.ok:
            return f"{SENT} ({self.detail})" if self.detail else SENT
        return f"{self.status} - {self.detail}" if self.detail else self.status

    def to_dict(self) -> dict:
        return {"status": self.status, "detail": self.detail, "http_status": self.http_status,
                "retry_after_seconds": self.retry_after, "message_id": self.message_id,
                "attempted_at": self.attempted_at}


def _result(status, detail="", **extra) -> DeliveryResult:
    return DeliveryResult(status=status, detail=detail, attempted_at=now_iso(), **extra)


def _credentials() -> tuple:
    return (getattr(settings, "TELEGRAM_BOT_TOKEN", "") or "").strip(), \
           (getattr(settings, "TELEGRAM_CHAT_ID", "") or "").strip()


def check_configuration() -> Optional[DeliveryResult]:
    """None when the configuration looks usable, otherwise the reason. The
    values themselves are never echoed, only which variable is the problem."""
    token, chat = _credentials()
    missing = [name for name, value in (("TELEGRAM_BOT_TOKEN", token), ("TELEGRAM_CHAT_ID", chat)) if not value]
    if missing:
        return _result(NOT_CONFIGURED, f"{' and '.join(missing)} not set in .env")
    if not _TOKEN_RE.match(token):
        return _result(INVALID_CONFIGURATION,
                       "TELEGRAM_BOT_TOKEN does not look like a bot token (expected 123456:ABC... from @BotFather; "
                       "check for quotes, spaces or a truncated value)")
    if not _CHAT_RE.match(chat):
        return _result(INVALID_CONFIGURATION,
                       "TELEGRAM_CHAT_ID must be a numeric chat id (groups/channels are negative) or @channelusername")
    return None


def _safe(text, limit: int = 160) -> str:
    """Server-supplied text: strip the token, flatten whitespace, and swap the
    square brackets that would be read as terminal markup."""
    token, _ = _credentials()
    out = _BOT_URL_RE.sub("bot<redacted>", str(text))
    if token:
        out = out.replace(token, "<redacted>").replace(token.split(":")[-1], "<redacted>")
    out = " ".join(out.split()).replace("[", "(").replace("]", ")")
    return out[:limit]


def _is_dns_failure(exc: BaseException) -> bool:
    seen, stack = set(), [exc]
    while stack:
        cur = stack.pop()
        if id(cur) in seen:
            continue
        seen.add(id(cur))
        if isinstance(cur, socket.gaierror) or type(cur).__name__ == "NameResolutionError":
            return True
        linked = [getattr(cur, "__cause__", None), getattr(cur, "__context__", None),
                  getattr(cur, "reason", None), *getattr(cur, "args", ())]
        stack.extend(x for x in linked if isinstance(x, BaseException))
    return False


def _transport_failure(exc: Exception) -> DeliveryResult:
    if isinstance(exc, requests.exceptions.SSLError):
        return _result(NETWORK_ERROR, "TLS/certificate error while connecting to Telegram")
    if isinstance(exc, requests.exceptions.Timeout):
        return _result(NETWORK_ERROR, "connection to Telegram timed out")
    if isinstance(exc, requests.exceptions.ConnectionError):
        if _is_dns_failure(exc):
            return _result(NETWORK_ERROR, "DNS lookup for api.telegram.org failed")
        return _result(NETWORK_ERROR, "could not connect to api.telegram.org")
    if isinstance(exc, (requests.exceptions.InvalidURL, requests.exceptions.InvalidHeader)):
        return _result(INVALID_CONFIGURATION, "the bot token or chat id contains characters that cannot be sent")
    return _result(NETWORK_ERROR, f"request failed ({type(exc).__name__})")


def _classify(http_status: int, body) -> DeliveryResult:
    """Map an unsuccessful Telegram answer to a status."""
    body = body if isinstance(body, dict) else {}
    code = body.get("error_code") if isinstance(body.get("error_code"), int) else http_status
    desc = _safe(body.get("description", ""))
    params = body.get("parameters") if isinstance(body.get("parameters"), dict) else {}
    retry = params.get("retry_after") if isinstance(params.get("retry_after"), int) else None
    common = {"http_status": http_status}

    if code == 401:
        return _result(AUTHENTICATION_FAILED, "Telegram rejected the bot token (HTTP 401); regenerate it with @BotFather", **common)
    if code == 404:
        return _result(AUTHENTICATION_FAILED, "Telegram does not recognise this bot token (HTTP 404)", **common)
    if code == 403:
        return _result(BOT_FORBIDDEN, "the bot may not post to this chat: it was blocked, removed, or lacks permission"
                       + (f" ({desc})" if desc else ""), **common)
    if code == 429:
        wait = f", retry after {retry}s" if retry else ""
        return _result(RATE_LIMITED, f"Telegram is rate limiting this bot (HTTP 429{wait})", retry_after=retry, **common)
    if code == 400:
        if "chat not found" in desc.lower():
            return _result(CHAT_NOT_FOUND, "chat not found: check TELEGRAM_CHAT_ID, and for private chats press Start on the bot first", **common)
        return _result(TELEGRAM_API_ERROR, f"Telegram rejected the request (HTTP 400): {desc or 'no description'}", **common)
    if code == 413:
        return _result(TELEGRAM_API_ERROR, "Telegram says the file is too large (HTTP 413)", **common)
    if code >= 500:
        return _result(TELEGRAM_API_ERROR, f"Telegram server error (HTTP {code})", **common)
    return _result(TELEGRAM_API_ERROR, f"unexpected Telegram answer (HTTP {http_status}){': ' + desc if desc else ''}", **common)


def _not_telegram(status: int) -> DeliveryResult:
    return _result(NETWORK_ERROR, f"HTTP {status} did not come from the Telegram Bot API; a proxy, firewall or "
                                  "captive portal may be blocking api.telegram.org", http_status=status)


def _call(method: str, data: dict, files=None, timeout=None):
    """One Bot API request. Returns (failure_or_None, body_or_None, http_status_or_None)."""
    token, _ = _credentials()
    url = f"{API_BASE}/bot{token}/{method}"
    try:
        resp = requests.post(url, data=data, files=files, timeout=timeout or TIMEOUT, allow_redirects=False)
    except requests.exceptions.RequestException as exc:
        log.info(f"Telegram {method}: transport failure {type(exc).__name__}")
        return _transport_failure(exc), None, None

    status = resp.status_code
    try:
        body = resp.json()
    except ValueError:
        body = None
    if status == 200 and isinstance(body, dict) and body.get("ok") is True:
        return None, body, status
    if status == 200 and not isinstance(body, dict):
        return _result(TELEGRAM_API_ERROR, "Telegram answered HTTP 200 with a response that could not be parsed",
                       http_status=status), None, status
    if 400 <= status < 500 and not (isinstance(body, dict) and "ok" in body):
        # the Bot API always answers 4xx with {"ok": false, ...}; anything else is not Telegram
        return _not_telegram(status), None, status
    failure = _classify(status, body)
    log.info(f"Telegram {method}: {failure.status} http={status}")
    return failure, body, status


# ------------------------------------------------------------------ delivery

def send_document(path, caption: Optional[str] = None) -> DeliveryResult:
    bad_config = check_configuration()
    if bad_config:
        return bad_config

    file_problem = _check_file(path)
    if file_problem:
        return file_problem

    _, chat = _credentials()
    data = {"chat_id": chat}
    if caption:
        data["caption"] = caption[:1000]
    try:
        with open(path, "rb") as fh:
            failure, body, status = _call("sendDocument", data, files={"document": (Path(path).name, fh, "application/json")})
    except OSError as exc:
        return _result(FILE_ERROR, f"could not read the report file ({type(exc).__name__})")
    except Exception as exc:  # anything unforeseen must not take the module down
        log.error(f"Telegram sendDocument: unexpected {type(exc).__name__}")
        return _result(UNKNOWN_ERROR, f"unexpected error ({type(exc).__name__})")

    if failure:
        return failure
    result = body.get("result") if isinstance(body.get("result"), dict) else {}
    if not isinstance(result.get("document"), dict):
        return _result(TELEGRAM_API_ERROR, "Telegram said ok but did not confirm the document", http_status=status)
    message_id = result.get("message_id") if isinstance(result.get("message_id"), int) else None
    return _result(SENT, "", http_status=status, message_id=message_id)


def _check_file(path) -> Optional[DeliveryResult]:
    try:
        p = Path(path)
        if not p.is_file():
            return _result(FILE_ERROR, "report file does not exist")
        size = p.stat().st_size
        if size == 0:
            return _result(FILE_ERROR, "report file is empty")
        if size > MAX_UPLOAD_BYTES:
            return _result(FILE_ERROR, "report file exceeds Telegram's 50 MB upload limit")
        with open(p, "r", encoding="utf-8") as fh:
            json.load(fh)
    except PermissionError:
        return _result(FILE_ERROR, "permission denied reading the report file")
    except (UnicodeDecodeError, json.JSONDecodeError):
        return _result(FILE_ERROR, "report file is not valid UTF-8 JSON")
    except OSError as exc:
        return _result(FILE_ERROR, f"could not access the report file ({type(exc).__name__})")
    return None


# ------------------------------------------------------------------ diagnostics

class _Blocked(Exception):
    pass


@dataclass
class DiagStep:
    name: str
    status: str        # OK | WARNING | FAILED | SKIPPED
    detail: str


def diagnose() -> list:
    """Read-only checks. Nothing is sent to the chat."""
    steps = []

    bad = check_configuration()
    if bad:
        steps.append(DiagStep("Configuration", "FAILED", f"{bad.status}: {bad.detail}"))
        return steps
    steps.append(DiagStep("Configuration", "OK", "token and chat id are present and correctly shaped"))

    try:
        resp = requests.get(API_BASE + "/", timeout=TIMEOUT, allow_redirects=False)
        if resp.headers.get("x-deny-reason") or resp.status_code in (403, 407):
            raise _Blocked(resp.status_code)
        steps.append(DiagStep("API reachability", "OK", f"api.telegram.org answered (HTTP {resp.status_code})"))
    except _Blocked as blocked:
        steps.append(DiagStep("API reachability", "FAILED", _not_telegram(blocked.args[0]).detail))
        steps += [DiagStep(n, "SKIPPED", "Telegram is not reachable") for n in ("Bot token (getMe)", "Target chat (getChat)")]
        return steps
    except requests.exceptions.RequestException as exc:
        steps.append(DiagStep("API reachability", "FAILED", _transport_failure(exc).detail))
        steps += [DiagStep(n, "SKIPPED", "Telegram is not reachable") for n in ("Bot token (getMe)", "Target chat (getChat)")]
        return steps

    failure, body, _ = _call("getMe", {})
    if failure:
        steps.append(DiagStep("Bot token (getMe)", "FAILED", failure.describe()))
        steps.append(DiagStep("Target chat (getChat)", "SKIPPED", "the bot token was not accepted"))
        return steps
    me = body.get("result") if isinstance(body.get("result"), dict) else {}
    handle = _safe(me.get("username", "unknown"), 64)
    steps.append(DiagStep("Bot token (getMe)", "OK", f"token accepted, bot is @{handle}"))

    _, chat = _credentials()
    failure, body, _ = _call("getChat", {"chat_id": chat})
    if failure:
        steps.append(DiagStep("Target chat (getChat)", "FAILED", failure.describe()))
        return steps
    info = body.get("result") if isinstance(body.get("result"), dict) else {}
    chat_type = _safe(info.get("type", "unknown"), 32)
    steps.append(DiagStep("Target chat (getChat)", "OK", f"chat found, type: {chat_type}"))

    if chat_type == "private":
        steps.append(DiagStep("Posting permission", "OK",
                              "private chat resolved; this only works while you have not blocked the bot"))
    elif isinstance(me.get("id"), int):
        failure, body, _ = _call("getChatMember", {"chat_id": chat, "user_id": me["id"]})
        if failure:
            steps.append(DiagStep("Posting permission", "FAILED", failure.describe()))
        else:
            steps.append(_membership_step(body.get("result"), chat_type))
    return steps


def _membership_step(member, chat_type: str) -> DiagStep:
    member = member if isinstance(member, dict) else {}
    status = member.get("status")
    if status in ("left", "kicked"):
        return DiagStep("Posting permission", "FAILED", f"the bot is not in this chat (status: {status}); add it again")
    if status == "restricted" and member.get("can_send_documents") is False:
        return DiagStep("Posting permission", "FAILED", "the bot is restricted from sending documents in this chat")
    if chat_type == "channel" and status != "administrator":
        return DiagStep("Posting permission", "FAILED", "in a channel the bot must be an administrator that can post")
    if status in ("creator", "administrator", "member", "restricted"):
        return DiagStep("Posting permission", "OK", f"bot membership status: {status}")
    return DiagStep("Posting permission", "WARNING", f"could not interpret membership status ({_safe(status or 'none', 32)})")
