"""
Thin wrapper over requests. Every call returns an HttpResult instead of
raising, so modules can tell "site says 404" apart from "we never got
a response" without a try/except in every single caller.
"""

from dataclasses import dataclass
from typing import Optional

import requests

from config.settings import REQUEST_TIMEOUT, USER_AGENT
from utils.logging import get_logger

log = get_logger()


@dataclass
class HttpResult:
    ok: bool
    status_code: Optional[int] = None
    headers: Optional[dict] = None
    text: Optional[str] = None
    final_url: Optional[str] = None
    history: Optional[list] = None
    error: Optional[str] = None  # "TIMEOUT" | "CONNECTION_FAILED" | "SSL_ERROR" | "TOO_MANY_REDIRECTS" | "UNKNOWN"


def get(url: str, timeout: int = REQUEST_TIMEOUT, allow_redirects: bool = True,
        headers: Optional[dict] = None) -> HttpResult:
    req_headers = {"User-Agent": USER_AGENT}
    if headers:
        req_headers.update(headers)

    try:
        resp = requests.get(url, timeout=timeout, allow_redirects=allow_redirects, headers=req_headers)
        return HttpResult(
            ok=True,
            status_code=resp.status_code,
            headers=dict(resp.headers),
            text=resp.text,
            final_url=resp.url,
            history=[r.url for r in resp.history],
        )
    except requests.exceptions.SSLError as exc:
        log.info(f"SSL error fetching {url}: {exc}")
        return HttpResult(ok=False, error="SSL_ERROR")
    except requests.exceptions.Timeout:
        return HttpResult(ok=False, error="TIMEOUT")
    except requests.exceptions.TooManyRedirects:
        return HttpResult(ok=False, error="TOO_MANY_REDIRECTS")
    except requests.exceptions.ConnectionError as exc:
        log.info(f"Connection error fetching {url}: {exc}")
        return HttpResult(ok=False, error="CONNECTION_FAILED")
    except requests.exceptions.RequestException as exc:
        log.info(f"Unhandled request error fetching {url}: {exc}")
        return HttpResult(ok=False, error="UNKNOWN")


def head(url: str, timeout: int = REQUEST_TIMEOUT) -> HttpResult:
    req_headers = {"User-Agent": USER_AGENT}
    try:
        resp = requests.head(url, timeout=timeout, allow_redirects=True, headers=req_headers)
        return HttpResult(ok=True, status_code=resp.status_code, headers=dict(resp.headers), final_url=resp.url)
    except requests.exceptions.SSLError:
        return HttpResult(ok=False, error="SSL_ERROR")
    except requests.exceptions.Timeout:
        return HttpResult(ok=False, error="TIMEOUT")
    except requests.exceptions.ConnectionError:
        return HttpResult(ok=False, error="CONNECTION_FAILED")
    except requests.exceptions.RequestException:
        return HttpResult(ok=False, error="UNKNOWN")
