"""
Shared vocabulary for OSINT findings. Every module reports through
Finding objects so the reporter never has to guess what a result means.
"""

from dataclasses import dataclass, field
from typing import Optional
from utils.timestamps import now_iso


# Status values a finding can carry. Kept as plain strings (not an Enum)
# so they serialize straight into JSON without extra conversion.
CONFIRMED_PUBLIC = "CONFIRMED_PUBLIC"
POSSIBLE_MATCH = "POSSIBLE_MATCH"
NOT_FOUND = "NOT_FOUND"
UNKNOWN = "UNKNOWN"
NOT_TESTED = "NOT_TESTED"
SOURCE_UNAVAILABLE = "SOURCE_UNAVAILABLE"
BLOCKED = "BLOCKED"
REQUIRES_API_CONFIGURATION = "REQUIRES_API_CONFIGURATION"
LOOKUP_FAILED = "LOOKUP_FAILED"


@dataclass
class Finding:
    label: str                     # what was checked, e.g. "GitHub" or "MX Record"
    status: str                    # one of the constants above
    source: str                    # where the data came from (URL, RFC, library)
    evidence: str                  # short human-readable explanation of what was observed
    confidence: str = "NONE"       # HIGH / MEDIUM / LOW / NONE, set via core/confidence.py
    methodology: str = ""          # how the check was performed
    url: Optional[str] = None
    timestamp: str = field(default_factory=now_iso)

    def to_dict(self) -> dict:
        return {
            "label": self.label,
            "status": self.status,
            "source": self.source,
            "evidence": self.evidence,
            "confidence": self.confidence,
            "methodology": self.methodology,
            "url": self.url,
            "timestamp": self.timestamp,
        }


def not_tested(label: str, reason: str) -> Finding:
    return Finding(label=label, status=NOT_TESTED, source="n/a", evidence=reason,
                    confidence="NONE", methodology="Skipped")


def source_unavailable(label: str, source: str, reason: str) -> Finding:
    return Finding(label=label, status=SOURCE_UNAVAILABLE, source=source, evidence=reason,
                    confidence="NONE", methodology="Attempted, source did not respond usably")


def requires_api(label: str, service: str, env_var: str) -> Finding:
    return Finding(
        label=label,
        status=REQUIRES_API_CONFIGURATION,
        source=service,
        evidence=f"{service} requires an API key. Set {env_var} in your .env file to enable this check.",
        confidence="NONE",
        methodology="Not attempted, no credentials configured",
    )
