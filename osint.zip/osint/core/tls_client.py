import socket
import ssl
from dataclasses import dataclass
from datetime import datetime
from typing import Optional


@dataclass
class TlsResult:
    ok: bool
    subject: Optional[dict] = None
    issuer: Optional[dict] = None
    not_after: Optional[str] = None
    days_remaining: Optional[int] = None
    error: Optional[str] = None
    # TARGET_CERTIFICATE_PROBLEM | SCANNER_TRUST_STORE_PROBLEM |
    # TLS_CONNECTION_FAILED | HOST_UNREACHABLE | UNKNOWN_TLS_ERROR


def _flatten(name_tuple) -> dict:
    flat = {}
    for entry in name_tuple:
        for key, value in entry:
            flat[key] = value
    return flat


def inspect(hostname: str, port: int = 443, timeout: float = 6.0) -> TlsResult:
    context = ssl.create_default_context()
    try:
        with socket.create_connection((hostname, port), timeout=timeout) as sock:
            with context.wrap_socket(sock, server_hostname=hostname) as tls_sock:
                cert = tls_sock.getpeercert()
    except ssl.SSLCertVerificationError:
        # the connection reached the server but the certificate itself
        # failed verification - that's a target-side problem
        return TlsResult(ok=False, error="TARGET_CERTIFICATE_PROBLEM")
    except ssl.SSLError:
        return TlsResult(ok=False, error="UNKNOWN_TLS_ERROR")
    except socket.timeout:
        return TlsResult(ok=False, error="TLS_CONNECTION_FAILED")
    except (socket.gaierror, ConnectionRefusedError, OSError):
        return TlsResult(ok=False, error="HOST_UNREACHABLE")

    not_after_raw = cert.get("notAfter")
    days_remaining = None
    not_after_iso = None
    if not_after_raw:
        try:
            expiry = datetime.strptime(not_after_raw, "%b %d %H:%M:%S %Y %Z")
            not_after_iso = expiry.isoformat()
            days_remaining = (expiry - datetime.utcnow()).days
        except ValueError:
            pass

    return TlsResult(
        ok=True,
        subject=_flatten(cert.get("subject", ())),
        issuer=_flatten(cert.get("issuer", ())),
        not_after=not_after_iso,
        days_remaining=days_remaining,
    )
