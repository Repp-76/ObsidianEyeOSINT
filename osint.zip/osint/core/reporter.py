import json
from pathlib import Path
from typing import List

import requests

from config.settings import APP_NAME, APP_VERSION, DEVELOPER, REPORTS_DIR, telegram_configured
from config.settings import TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID
from core.evidence import Finding
from utils.logging import get_logger
from utils.timestamps import now_iso, filename_stamp

log = get_logger()


def build_report(module: str, target: dict, findings: List[Finding], errors: List[str] = None,
                  warnings: List[str] = None) -> dict:
    return {
        "tool": {
            "name": APP_NAME,
            "version": APP_VERSION,
            "developer": DEVELOPER,
        },
        "scan": {
            "timestamp": now_iso(),
            "module": module,
            "status": "completed",
        },
        "target": target,
        "findings": [f.to_dict() for f in findings],
        "sources": sorted({f.source for f in findings if f.source and f.source != "n/a"}),
        "errors": errors or [],
        "warnings": warnings or [],
    }


def save_report(report: dict, module: str) -> Path:
    REPORTS_DIR.mkdir(exist_ok=True)
    safe_module = module.lower().replace(" ", "_")
    path = REPORTS_DIR / f"{safe_module}_{filename_stamp()}.json"
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(report, fh, indent=2, ensure_ascii=False)
    return path


def send_to_telegram(json_path: Path) -> tuple[bool, str]:
    """Returns (success, reason). reason is only meaningful on failure -
    it's what actually gets shown in the terminal, not a generic message."""
    if not telegram_configured():
        return False, "NOT_CONFIGURED"
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendDocument"
    try:
        with open(json_path, "rb") as fh:
            resp = requests.post(
                url,
                data={"chat_id": TELEGRAM_CHAT_ID, "caption": f"ObsidianEye report: {json_path.name}"},
                files={"document": (json_path.name, fh, "application/json")},
                timeout=15,
            )
        if resp.status_code == 200:
            return True, ""
        log.info(f"Telegram delivery failed: HTTP {resp.status_code} - {resp.text[:200]}")
        return False, f"HTTP {resp.status_code}"
    except requests.exceptions.RequestException as exc:
        log.info(f"Telegram delivery failed: {exc}")
        return False, type(exc).__name__
