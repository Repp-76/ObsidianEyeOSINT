import json
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional
from urllib.parse import urlparse

from config import settings
from config.settings import APP_NAME, APP_VERSION, DEVELOPER, REPORTS_DIR
from core import telegram_client
from core.evidence import Finding
from utils.logging import get_logger
from utils.timestamps import now_iso, filename_stamp

log = get_logger()

# every report, whichever module wrote it, must carry these
REQUIRED_FIELDS = (
    "module", "module_version", "target_type", "target", "masked_target", "started_at", "completed_at",
    "duration_seconds", "status", "findings", "sources", "limitations", "errors", "telegram_delivery",
    "tool_version",
)


class ReportError(Exception):
    """The report could not be validated or written. The message is safe to show."""


def _iso(value: Optional[datetime]) -> str:
    if value is None:
        return now_iso()
    if value.tzinfo is None:
        value = value.astimezone()   # naive local time from datetime.now()
    return value.astimezone(timezone.utc).isoformat(timespec="seconds")


def mask_target(value: Optional[str], target_type: str = "") -> str:
    """Keep enough to recognise the target without repeating everything a
    report might get forwarded with: emails lose most of the local part, URLs
    lose the query string, file paths keep only the file name."""
    if not value:
        return ""
    if "@" in value and " " not in value:
        local, _, domain = value.partition("@")
        return f"{local[:1]}***@{domain}"
    if value.startswith(("http://", "https://")):
        parsed = urlparse(value)
        return f"{parsed.scheme}://{parsed.netloc}{parsed.path}"
    if "/" in value or "\\" in value:
        return Path(value.replace("\\", "/")).name
    return value


def build_report(module: str, target: dict, findings: List[Finding], errors: List[str] = None,
                  warnings: List[str] = None, started: Optional[datetime] = None,
                  completed: Optional[datetime] = None, target_type: str = "",
                  module_version: str = APP_VERSION) -> dict:
    started_at, completed_at = _iso(started), _iso(completed)
    duration = 0.0
    if started is not None and completed is not None:
        duration = round((completed - started).total_seconds(), 2)
    value = (target or {}).get("value")
    return {
        "tool": {
            "name": APP_NAME,
            "version": APP_VERSION,
            "developer": DEVELOPER,
        },
        "scan": {
            "timestamp": now_iso(),
            "module": module,
            "status": "completed",
        },
        "target": target,
        "findings": [f.to_dict() for f in findings],
        "sources": sorted({f.source for f in findings if f.source and f.source != "n/a"}),
        "errors": errors or [],
        "warnings": warnings or [],
        "module": module,
        "module_version": module_version,
        "target_type": target_type or "none",
        "masked_target": mask_target(value, target_type),
        "started_at": started_at,
        "completed_at": completed_at,
        "duration_seconds": duration,
        "status": "completed",
        "limitations": [],
        "telegram_delivery": {"status": "PENDING"},
        "tool_version": APP_VERSION,
    }


def validate_report(report: dict) -> None:
    if not isinstance(report, dict):
        raise ReportError("report is not a JSON object")
    missing = [k for k in REQUIRED_FIELDS if k not in report]
    if missing:
        raise ReportError(f"report is missing required fields: {', '.join(missing)}")
    for key in ("findings", "sources", "limitations", "errors"):
        if not isinstance(report[key], list):
            raise ReportError(f"report field '{key}' must be a list")
    if not isinstance(report["duration_seconds"], (int, float)) or report["duration_seconds"] < 0:
        raise ReportError("report field 'duration_seconds' must be a non-negative number")


def _write_atomic(path: Path, text: str) -> None:
    """Write next to the target and swap it in, so neither the local file nor
    an upload can ever see a half-written report."""
    tmp_name = None
    try:
        with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=path.parent, prefix=".tmp_", suffix=".json",
                                         delete=False) as tmp:
            tmp_name = tmp.name
            tmp.write(text)
            tmp.flush()
            os.fsync(tmp.fileno())
        os.replace(tmp_name, path)
    except BaseException:
        if tmp_name and os.path.exists(tmp_name):
            os.unlink(tmp_name)
        raise


def _secret_values() -> list:
    names = ("TELEGRAM_BOT_TOKEN", "HIBP_API_KEY", "IPQS_API_KEY", "TWILIO_AUTH_TOKEN")
    values = [(getattr(settings, n, "") or os.getenv(n, "")).strip() for n in names]
    token = values[0]
    if ":" in token:
        values.append(token.split(":", 1)[1])      # the secret half, in case only that leaks
    return [v for v in values if len(v) >= 8]


def _serialize(report: dict) -> str:
    try:
        text = json.dumps(report, indent=2, ensure_ascii=False)
    except (TypeError, ValueError) as exc:
        raise ReportError(f"report could not be serialised to JSON ({type(exc).__name__})") from None
    for secret in _secret_values():
        if secret in text:
            log.error("A configured secret appeared in a report and was removed before writing")
            text = text.replace(secret, "<redacted>")
    return text


def save_report(report: dict, module: str) -> Path:
    validate_report(report)
    text = _serialize(report)
    try:
        REPORTS_DIR.mkdir(exist_ok=True)
        safe_module = module.lower().replace(" ", "_")
        path = REPORTS_DIR / f"{safe_module}_{filename_stamp()}.json"
        n = 1
        while path.exists():
            n += 1
            path = REPORTS_DIR / f"{safe_module}_{filename_stamp()}_{n}.json"
        _write_atomic(path, text)
    except OSError as exc:
        log.error(f"Report write failed: {type(exc).__name__}")
        raise ReportError(f"report file could not be written ({type(exc).__name__}: {exc.strerror or 'I/O error'})") from None
    return path


def record_delivery(path: Path, result: telegram_client.DeliveryResult) -> bool:
    """Store the outcome in the local copy. The copy Telegram received was
    uploaded before the outcome existed, so it still says PENDING."""
    try:
        with open(path, "r", encoding="utf-8") as fh:
            report = json.load(fh)
        report["telegram_delivery"] = result.to_dict()
        _write_atomic(Path(path), _serialize(report))
        return True
    except (OSError, ValueError, ReportError) as exc:
        log.error(f"Could not record Telegram delivery status in the report: {type(exc).__name__}")
        return False


def deliver(path: Optional[Path]) -> telegram_client.DeliveryResult:
    """Send the saved report and record what happened. Never raises."""
    if path is None:
        return telegram_client.DeliveryResult(status=telegram_client.FILE_ERROR,
                                              detail="no report file was written", attempted_at=now_iso())
    result = telegram_client.send_document(path, caption=f"ObsidianEye report: {Path(path).name}")
    if not record_delivery(path, result):
        result.detail = (result.detail + " " if result.detail else "") + "(local JSON metadata not updated)"
    return result


def deliver_and_describe(path: Optional[Path]) -> str:
    return deliver(path).describe()


def send_to_telegram(json_path: Path) -> tuple[bool, str]:
    """Kept for callers of the old interface: (success, reason on failure)."""
    result = deliver(json_path)
    return result.ok, "" if result.ok else result.status
