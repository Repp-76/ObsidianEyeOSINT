"""
Confidence is derived from what was actually observed, never rolled at
random. A caller picks the tier that matches the strength of its evidence.

HIGH   - direct, unambiguous evidence from the authoritative source
         (e.g. DNS record returned by the resolver, HTTP header present)
MEDIUM - evidence exists but could have more than one explanation
         (e.g. a username exists on a platform, but that alone isn't identity)
LOW    - weak signal, heuristic, or partial response
NONE   - no evidence collected (not found, not tested, source unavailable)
"""

HIGH = "HIGH"
MEDIUM = "MEDIUM"
LOW = "LOW"
NONE_ = "NONE"

_VALID = {HIGH, MEDIUM, LOW, NONE_}


def rate(level: str) -> str:
    level = level.upper()
    if level not in _VALID:
        raise ValueError(f"Unknown confidence level: {level}")
    return level
