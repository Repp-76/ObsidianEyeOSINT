import os
from pathlib import Path

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass  # dotenv is optional; env vars set another way still work

APP_NAME = "ObsidianEye OSINT"
APP_VERSION = "1.0.0"
DEVELOPER = "Repp76"
MODULE_COUNT = 16

BASE_DIR = Path(__file__).resolve().parent.parent
REPORTS_DIR = BASE_DIR / "reports"

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "").strip()
HIBP_API_KEY = os.getenv("HIBP_API_KEY", "").strip()

try:
    REQUEST_TIMEOUT = int(os.getenv("OSINT_REQUEST_TIMEOUT", "8"))
except ValueError:
    REQUEST_TIMEOUT = 8
USER_AGENT = "ObsidianEye-OSINT/1.0 (+https://github.com/Repp76)"


def telegram_configured() -> bool:
    return bool(TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID)
