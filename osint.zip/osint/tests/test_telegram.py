"""
Tests for the shared report -> Telegram pipeline.

Three kinds of test live here and none of them is a live Telegram result:

  LOCAL EMULATOR  A small HTTP server on 127.0.0.1 that speaks the Bot API
                  shapes (getMe, getChat, getChatMember, sendDocument, with
                  real multipart parsing). The real requests stack talks to it,
                  so encoding, status handling and timeouts are exercised for
                  real - but it is not Telegram.
  MOCK            unittest.mock stand-ins, used only where an OS condition
                  (permission denied) or a module runner needs to be forced.
  OFFLINE         plain unit tests of the JSON report code.

Run from the project root:   python -m unittest discover -s tests -v
"""

import io
import json
import os
import sys
import tempfile
import threading
import time
import unittest
from email.parser import BytesParser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import requests

import telegram_check
from config import settings
from core import engine, reporter, telegram_client as tg
from core.evidence import Finding
from utils import terminal
from utils.logging import LOG_PATH

TOKEN = "123456789:AAFakeTokenForTestsOnly_abcdefghijk"
CHAT = "987654321"
GOOD = {"ok": True, "result": {"message_id": 41, "document": {"file_id": "abc", "file_name": "r.json"}}}


class FakeBotApi:
    """LOCAL EMULATOR. `mode` selects what sendDocument answers."""

    def __init__(self):
        self.mode = "ok"
        self.chat_type = "private"
        self.member = {"status": "member"}
        self.calls = []          # (method, chat_id)
        self.uploads = []        # dicts describing received documents
        api = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def _send(self, status, body, ctype="application/json"):
                raw = body if isinstance(body, bytes) else json.dumps(body).encode()
                self.send_response(status)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)

            def do_GET(self):
                self.send_response(302)
                self.send_header("Location", "https://core.telegram.org/bots")
                self.send_header("Content-Length", "0")
                self.end_headers()

            def do_POST(self):
                length = int(self.headers.get("Content-Length", 0))
                raw = self.rfile.read(length)
                parts = self.path.strip("/").split("/")
                if len(parts) != 2 or not parts[0].startswith("bot"):
                    return self._send(404, {"ok": False, "error_code": 404, "description": "Not Found"})
                if parts[0][3:] != TOKEN:
                    return self._send(401, {"ok": False, "error_code": 401, "description": "Unauthorized"})
                method, fields = parts[1], {}
                ctype = self.headers.get("Content-Type", "")
                if ctype.startswith("multipart/form-data"):
                    msg = BytesParser().parsebytes(b"Content-Type: " + ctype.encode() + b"\r\n\r\n" + raw)
                    for part in msg.get_payload():
                        name = part.get_param("name", header="content-disposition")
                        if part.get_filename():
                            fields[name] = {"filename": part.get_filename(), "bytes": part.get_payload(decode=True),
                                            "ctype": part.get_content_type()}
                        else:
                            fields[name] = part.get_payload(decode=True).decode()
                else:
                    from urllib.parse import parse_qs
                    fields = {k: v[0] for k, v in parse_qs(raw.decode()).items()}
                api.calls.append((method, fields.get("chat_id")))
                if method == "getMe":
                    return self._send(200, {"ok": True, "result": {"id": 555, "is_bot": True, "username": "test_report_bot"}})
                if fields.get("chat_id") != CHAT:
                    return self._send(400, {"ok": False, "error_code": 400, "description": "Bad Request: chat not found"})
                if method == "getChat":
                    return self._send(200, {"ok": True, "result": {"id": int(CHAT), "type": api.chat_type, "title": "SECRET TITLE"}})
                if method == "getChatMember":
                    return self._send(200, {"ok": True, "result": api.member})
                if method == "sendDocument":
                    return self._send_document(fields)
                return self._send(404, {"ok": False, "error_code": 404, "description": "Not Found"})

            def _send_document(self, fields):
                doc = fields.get("document")
                api.uploads.append({"chat_id": fields.get("chat_id"), "caption": fields.get("caption"),
                                    "filename": doc["filename"] if isinstance(doc, dict) else None,
                                    "bytes": doc["bytes"] if isinstance(doc, dict) else None,
                                    "ctype": doc["ctype"] if isinstance(doc, dict) else None})
                m = api.mode
                if m == "ok":
                    return self._send(200, GOOD)
                if m == "ok_false_200":
                    return self._send(200, {"ok": False, "description": "something odd"})
                if m == "ok_no_document":
                    return self._send(200, {"ok": True, "result": {"message_id": 1}})
                if m == "html_200":
                    return self._send(200, b"<html>captive portal</html>", "text/html")
                if m == "empty_200":
                    return self._send(200, b"", "application/json")
                if m == "forbidden":
                    return self._send(403, {"ok": False, "error_code": 403, "description": "Forbidden: bot was blocked by the user"})
                if m == "chat_not_found":
                    return self._send(400, {"ok": False, "error_code": 400, "description": "Bad Request: chat not found"})
                if m == "bad_request":
                    return self._send(400, {"ok": False, "error_code": 400, "description": f"Bad Request: token {TOKEN} [x]"})
                if m == "rate":
                    return self._send(429, {"ok": False, "error_code": 429, "description": "Too Many Requests: retry after 17",
                                            "parameters": {"retry_after": 17}})
                if m == "proxy_block":
                    return self._send(403, b"<html>Access denied by network policy</html>", "text/html")
                if m == "server_error":
                    return self._send(502, b"Bad Gateway", "text/plain")
                if m == "too_large":
                    return self._send(413, {"ok": False, "error_code": 413, "description": "Request Entity Too Large"})
                if m == "slow":
                    time.sleep(3)
                    return self._send(200, GOOD)
                return self._send(500, {})

        self.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.server.daemon_threads = True
        self.server.handle_error = lambda *a: None   # a client that timed out closes the socket mid-reply
        self.url = f"http://127.0.0.1:{self.server.server_address[1]}"
        threading.Thread(target=self.server.serve_forever, daemon=True).start()

    def stop(self):
        self.server.shutdown()
        self.server.server_close()

    def count(self, method):
        return sum(1 for m, _ in self.calls if m == method)


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.dir = Path(self.tmp.name)
        self.api = FakeBotApi()
        self.addCleanup(self.api.stop)
        for p in (
            mock.patch.object(tg, "API_BASE", self.api.url),
            mock.patch.object(tg, "TIMEOUT", (2, 2)),
            mock.patch.object(settings, "TELEGRAM_BOT_TOKEN", TOKEN),
            mock.patch.object(settings, "TELEGRAM_CHAT_ID", CHAT),
            mock.patch.object(reporter, "REPORTS_DIR", self.dir),
        ):
            p.start()
            self.addCleanup(p.stop)

    def make_report(self, name="sample.json", body=None):
        path = self.dir / name
        path.write_text(json.dumps(body or {"module": "x", "note": "unicode \u2014 ok"}, ensure_ascii=False), encoding="utf-8")
        return path

    def set_config(self, token=TOKEN, chat=CHAT):
        for name, value in (("TELEGRAM_BOT_TOKEN", token), ("TELEGRAM_CHAT_ID", chat)):
            p = mock.patch.object(settings, name, value)
            p.start()
            self.addCleanup(p.stop)


# ------------------------------------------------------------------ sendDocument (LOCAL EMULATOR)

class SendDocumentTests(Base):
    def test_success_uploads_the_real_file_as_multipart(self):
        path = self.make_report()
        result = tg.send_document(path, caption="ObsidianEye report: sample.json")
        self.assertEqual(result.status, tg.SENT)
        self.assertEqual(result.message_id, 41)
        self.assertEqual(result.describe(), "SENT")
        (up,) = self.api.uploads
        self.assertEqual(up["chat_id"], CHAT)
        self.assertEqual(up["filename"], "sample.json")
        self.assertEqual(up["bytes"], path.read_bytes())
        self.assertEqual(up["caption"], "ObsidianEye report: sample.json")

    def test_only_http_200_with_ok_true_and_a_document_counts_as_sent(self):
        path = self.make_report()
        cases = {
            "ok_false_200": tg.TELEGRAM_API_ERROR, "ok_no_document": tg.TELEGRAM_API_ERROR,
            "html_200": tg.TELEGRAM_API_ERROR, "empty_200": tg.TELEGRAM_API_ERROR,
        }
        for mode, expected in cases.items():
            with self.subTest(mode=mode):
                self.api.mode = mode
                result = tg.send_document(path)
                self.assertEqual(result.status, expected)
                self.assertFalse(result.ok)
                self.assertNotIn("SENT", result.describe().split(" - ")[0].replace("SENT_", ""))

    def test_http_error_classification(self):
        path = self.make_report()
        cases = {
            "forbidden": (tg.BOT_FORBIDDEN, 403), "chat_not_found": (tg.CHAT_NOT_FOUND, 400),
            "bad_request": (tg.TELEGRAM_API_ERROR, 400), "rate": (tg.RATE_LIMITED, 429),
            "server_error": (tg.TELEGRAM_API_ERROR, 502), "too_large": (tg.TELEGRAM_API_ERROR, 413),
        }
        for mode, (status, http) in cases.items():
            with self.subTest(mode=mode):
                self.api.mode = mode
                result = tg.send_document(path)
                self.assertEqual((result.status, result.http_status), (status, http))

    def test_rate_limit_reports_retry_after_and_does_not_retry(self):
        self.api.mode = "rate"
        result = tg.send_document(self.make_report())
        self.assertEqual(result.retry_after, 17)
        self.assertIn("17", result.detail)
        self.assertEqual(len(self.api.uploads), 1)

    def test_wrong_token_is_authentication_failed_not_a_chat_problem(self):
        self.set_config(token="123456789:AAWrongTokenWrongTokenWrongToken_x")
        result = tg.send_document(self.make_report())
        self.assertEqual((result.status, result.http_status), (tg.AUTHENTICATION_FAILED, 401))

    def test_wrong_chat_is_chat_not_found(self):
        self.set_config(chat="111111111")
        self.assertEqual(tg.send_document(self.make_report()).status, tg.CHAT_NOT_FOUND)

    def test_timeout_connection_refused_and_dns_are_network_errors(self):
        path = self.make_report()
        self.api.mode = "slow"
        with mock.patch.object(tg, "TIMEOUT", (1, 1)):
            slow = tg.send_document(path)
        self.assertEqual(slow.status, tg.NETWORK_ERROR)
        self.assertIn("timed out", slow.detail)

        with mock.patch.object(tg, "API_BASE", "http://127.0.0.1:9"):
            refused = tg.send_document(path)
        self.assertEqual(refused.status, tg.NETWORK_ERROR)
        self.assertIn("could not connect", refused.detail)

        with mock.patch.object(tg, "API_BASE", "http://no-such-host.invalid"):
            dns = tg.send_document(path)
        self.assertEqual(dns.status, tg.NETWORK_ERROR)
        self.assertIn("DNS", dns.detail)

    def test_a_proxy_403_is_a_network_error_not_bot_forbidden(self):
        self.api.mode = "proxy_block"
        result = tg.send_document(self.make_report())
        self.assertEqual(result.status, tg.NETWORK_ERROR)
        self.assertIn("did not come from the Telegram Bot API", result.detail)
        self.assertNotEqual(result.status, tg.BOT_FORBIDDEN)

    def test_tls_error_is_a_network_error(self):
        with mock.patch("requests.post", side_effect=requests.exceptions.SSLError("bad cert")):
            self.assertIn("TLS", tg.send_document(self.make_report()).detail)

    def test_unexpected_exception_becomes_unknown_error_not_a_crash(self):
        with mock.patch.object(tg, "_call", side_effect=RuntimeError("boom")):
            result = tg.send_document(self.make_report())
        self.assertEqual(result.status, tg.UNKNOWN_ERROR)
        self.assertNotIn("boom", result.detail)

    def test_redirects_are_not_followed(self):
        with mock.patch("requests.post") as post:
            post.return_value = requests.models.Response()
            post.return_value.status_code = 302
            tg.send_document(self.make_report())
        self.assertIs(post.call_args.kwargs["allow_redirects"], False)


class ConfigurationTests(Base):
    def test_missing_values_are_not_configured_and_nothing_is_sent(self):
        path = self.make_report()
        for token, chat, named in (("", CHAT, "TELEGRAM_BOT_TOKEN"), (TOKEN, "", "TELEGRAM_CHAT_ID"),
                                   ("", "", "TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID")):
            with self.subTest(named=named):
                self.set_config(token, chat)
                result = tg.send_document(path)
                self.assertEqual(result.status, tg.NOT_CONFIGURED)
                self.assertIn(named, result.detail)
        self.assertEqual(self.api.calls, [])

    def test_malformed_values_are_invalid_configuration_and_nothing_is_sent(self):
        path = self.make_report()
        bad_tokens = ['"123456789:AAFakeTokenForTestsOnly_abcdefghijk"', "your_token_here", "123456789", "12345:short",
                      "123456789:AAFake TokenWithSpace_abcdefghijklmn"]
        for token in bad_tokens:
            with self.subTest(token=token):
                self.set_config(token=token)
                result = tg.send_document(path)
                self.assertEqual(result.status, tg.INVALID_CONFIGURATION)
                self.assertIn("TELEGRAM_BOT_TOKEN", result.detail)
                self.assertNotIn(token, result.describe())
        for chat in ("abc", "-12", "@ab", "12 34567", "https://t.me/x"):
            with self.subTest(chat=chat):
                self.set_config(chat=chat)
                self.assertEqual(tg.send_document(path).status, tg.INVALID_CONFIGURATION)
        self.assertEqual(self.api.calls, [])

    def test_valid_shapes_are_accepted(self):
        for chat in ("987654321", "-1001234567890", "@my_channel"):
            self.set_config(chat=chat)
            self.assertIsNone(tg.check_configuration())


class FileErrorTests(Base):
    def test_missing_empty_and_non_json_files(self):
        self.assertEqual(tg.send_document(self.dir / "nope.json").status, tg.FILE_ERROR)
        empty = self.dir / "empty.json"
        empty.write_bytes(b"")
        self.assertIn("empty", tg.send_document(empty).detail)
        bad = self.dir / "bad.json"
        bad.write_text("{not json", encoding="utf-8")
        self.assertIn("not valid", tg.send_document(bad).detail)
        binary = self.dir / "bin.json"
        binary.write_bytes(b"\xff\xfe\x00")
        self.assertEqual(tg.send_document(binary).status, tg.FILE_ERROR)
        self.assertEqual(self.api.uploads, [])

    def test_oversized_file_is_refused_locally(self):
        path = self.make_report()
        with mock.patch.object(tg, "MAX_UPLOAD_BYTES", 5):
            self.assertIn("50 MB", tg.send_document(path).detail)
        self.assertEqual(self.api.uploads, [])

    @unittest.skipIf(hasattr(os, "geteuid") and os.geteuid() == 0, "root ignores file permissions")
    def test_real_permission_denied(self):
        path = self.make_report()
        path.chmod(0o000)
        self.addCleanup(path.chmod, 0o600)
        self.assertIn("permission denied", tg.send_document(path).detail)

    def test_permission_denied_mock(self):
        """MOCK: forces PermissionError because root (this sandbox) cannot be denied."""
        path = self.make_report()
        with mock.patch("builtins.open", side_effect=PermissionError(13, "denied")):
            result = tg.send_document(path)
        self.assertEqual(result.status, tg.FILE_ERROR)
        self.assertIn("permission denied", result.detail)

    def test_file_vanishing_between_check_and_upload(self):
        """MOCK: the check passes, then the upload's open() fails."""
        path = self.make_report()
        real_open = open

        def flaky(file, mode="r", *a, **k):
            if "b" in mode:
                raise FileNotFoundError(2, "gone")
            return real_open(file, mode, *a, **k)

        with mock.patch("builtins.open", side_effect=flaky):
            self.assertEqual(tg.send_document(path).status, tg.FILE_ERROR)


class SecretHandlingTests(Base):
    def test_token_never_appears_in_results_or_new_log_lines(self):
        log_start = LOG_PATH.stat().st_size if LOG_PATH.exists() else 0
        outputs = []
        for mode in ("bad_request", "forbidden", "rate", "server_error"):
            self.api.mode = mode
            r = tg.send_document(self.make_report())
            outputs += [r.describe(), json.dumps(r.to_dict())]
        with mock.patch("requests.post", side_effect=requests.exceptions.ConnectionError(f"url /bot{TOKEN}/sendDocument")):
            r = tg.send_document(self.make_report())
            outputs += [r.describe(), json.dumps(r.to_dict())]
        logged = ""
        if LOG_PATH.exists():
            with open(LOG_PATH, "rb") as fh:
                fh.seek(log_start)
                logged = fh.read().decode("utf-8", "replace")
        for text in outputs + [logged]:
            self.assertNotIn(TOKEN, text)
            self.assertNotIn(TOKEN.split(":")[1], text)

    def test_server_text_cannot_inject_terminal_markup(self):
        self.api.mode = "bad_request"
        self.assertNotIn("[", tg.send_document(self.make_report()).describe())


# ------------------------------------------------------------------ diagnostics (LOCAL EMULATOR)

class DiagnosticTests(Base):
    def steps(self):
        return {s.name: s for s in tg.diagnose()}

    def test_healthy_private_chat(self):
        s = self.steps()
        self.assertEqual({k: v.status for k, v in s.items()},
                         {"Configuration": "OK", "API reachability": "OK", "Bot token (getMe)": "OK",
                          "Target chat (getChat)": "OK", "Posting permission": "OK"})
        self.assertIn("@test_report_bot", s["Bot token (getMe)"].detail)
        self.assertIn("private", s["Target chat (getChat)"].detail)

    def test_diagnostics_never_send_anything_to_the_chat(self):
        tg.diagnose()
        self.assertEqual(self.api.count("sendDocument"), 0)
        self.assertEqual(self.api.uploads, [])
        self.assertLessEqual(self.api.count("getMe"), 1)

    def test_chat_title_is_not_echoed(self):
        blob = json.dumps([s.__dict__ for s in tg.diagnose()])
        self.assertNotIn("SECRET TITLE", blob)

    def test_bad_token_stops_before_the_chat_check(self):
        self.set_config(token="123456789:AAWrongTokenWrongTokenWrongToken_x")
        s = self.steps()
        self.assertEqual(s["Bot token (getMe)"].status, "FAILED")
        self.assertIn("AUTHENTICATION_FAILED", s["Bot token (getMe)"].detail)
        self.assertEqual(s["Target chat (getChat)"].status, "SKIPPED")

    def test_wrong_chat(self):
        self.set_config(chat="111111111")
        s = self.steps()
        self.assertEqual(s["Target chat (getChat)"].status, "FAILED")
        self.assertIn("CHAT_NOT_FOUND", s["Target chat (getChat)"].detail)

    def test_group_membership_explanations(self):
        self.api.chat_type = "supergroup"
        for member, status, needle in (
            ({"status": "member"}, "OK", "member"),
            ({"status": "administrator"}, "OK", "administrator"),
            ({"status": "left"}, "FAILED", "not in this chat"),
            ({"status": "kicked"}, "FAILED", "not in this chat"),
            ({"status": "restricted", "can_send_documents": False}, "FAILED", "restricted"),
        ):
            with self.subTest(member=member):
                self.api.member = member
                step = self.steps()["Posting permission"]
                self.assertEqual(step.status, status)
                self.assertIn(needle, step.detail)

    def test_channel_requires_administrator(self):
        self.api.chat_type = "channel"
        self.api.member = {"status": "member"}
        step = self.steps()["Posting permission"]
        self.assertEqual(step.status, "FAILED")
        self.assertIn("administrator", step.detail)

    def test_unreachable_api_skips_the_rest(self):
        with mock.patch.object(tg, "API_BASE", "http://127.0.0.1:9"):
            s = self.steps()
        self.assertEqual(s["API reachability"].status, "FAILED")
        self.assertEqual(s["Bot token (getMe)"].status, "SKIPPED")

    def test_missing_configuration_short_circuits(self):
        self.set_config(token="", chat="")
        (only,) = tg.diagnose()
        self.assertEqual((only.name, only.status), ("Configuration", "FAILED"))
        self.assertEqual(self.api.calls, [])


class CheckScriptTests(Base):
    """telegram_check.py: the one test upload needs an explicit choice and the word SEND."""

    def run_main(self, argv, answers):
        feed = iter(answers)
        with mock.patch.object(terminal, "prompt", side_effect=lambda m: next(feed)), \
                mock.patch.object(telegram_check, "REPORTS_DIR", self.dir), \
                terminal.console.capture() as cap:
            code = telegram_check.main(argv)
        return code, cap.get()

    def test_read_only_mode_uploads_nothing(self):
        self.make_report()
        code, out = self.run_main([], [])
        self.assertEqual(code, 0)
        self.assertEqual(self.api.uploads, [])
        self.assertIn("bot is @test_report_bot", out)

    def test_upload_cancelled_at_each_step_sends_nothing(self):
        self.make_report()
        for answers in ([""], ["1", ""], ["1", "send"], ["1", "yes"], ["9"], ["x"]):
            with self.subTest(answers=answers):
                self.run_main(["--upload"], answers)
        self.assertEqual(self.api.uploads, [])

    def test_confirmed_upload_sends_exactly_one_report_once(self):
        self.make_report("older.json")
        time.sleep(0.02)
        self.make_report("newer.json")
        code, out = self.run_main(["--upload"], ["1", "SEND"])
        self.assertEqual(code, 0)
        self.assertEqual([u["filename"] for u in self.api.uploads], ["newer.json"])
        self.assertIn("Upload result: SENT", out)

    def test_failed_diagnostic_blocks_the_upload_offer(self):
        self.set_config(chat="111111111")
        self.make_report()
        code, _ = self.run_main(["--upload"], ["1", "SEND"])
        self.assertEqual(code, 1)
        self.assertEqual(self.api.uploads, [])

    def test_upload_failure_is_reported_honestly(self):
        self.make_report()
        self.api.mode = "forbidden"
        code, out = self.run_main(["--upload"], ["1", "SEND"])
        self.assertEqual(code, 1)
        self.assertIn("BOT_FORBIDDEN", out)


# ------------------------------------------------------------------ report writing (OFFLINE)

def minimal_report(**over):
    report = reporter.build_report("Unit Test Module", {"value": "someone"}, [], target_type="username")
    report.update(over)
    return report


class ReportFileTests(Base):
    def test_every_common_field_is_present_and_old_fields_are_kept(self):
        f = Finding("L", "CONFIRMED_PUBLIC", "src", "ev", "HIGH", "m")
        started = engine.datetime.now()
        r = reporter.build_report("Email Intelligence", {"value": "alice@example.com"}, [f], started=started,
                                  completed=started, target_type="email_address")
        for key in reporter.REQUIRED_FIELDS:
            self.assertIn(key, r)
        for old in ("tool", "scan", "target", "findings", "sources", "errors", "warnings"):
            self.assertIn(old, r)
        self.assertEqual(r["scan"]["module"], "Email Intelligence")
        self.assertEqual(r["masked_target"], "a***@example.com")
        self.assertEqual(r["telegram_delivery"], {"status": "PENDING"})
        self.assertTrue(r["started_at"].endswith("+00:00"))

    def test_masking(self):
        self.assertEqual(reporter.mask_target("https://example.com/a?token=SECRET#x"), "https://example.com/a")
        self.assertEqual(reporter.mask_target("/home/me/private/photo.jpg"), "photo.jpg")
        self.assertEqual(reporter.mask_target("C:\\Users\\me\\doc.pdf"), "doc.pdf")
        self.assertEqual(reporter.mask_target("alice"), "alice")
        self.assertEqual(reporter.mask_target(None), "")

    def test_validation_rejects_incomplete_reports(self):
        r = minimal_report()
        del r["masked_target"]
        with self.assertRaises(reporter.ReportError):
            reporter.save_report(r, "x")
        with self.assertRaises(reporter.ReportError):
            reporter.save_report(minimal_report(findings="nope"), "x")
        with self.assertRaises(reporter.ReportError):
            reporter.save_report(minimal_report(duration_seconds=-1), "x")
        self.assertEqual(list(self.dir.iterdir()), [])

    def test_unserialisable_report_writes_nothing(self):
        with self.assertRaises(reporter.ReportError):
            reporter.save_report(minimal_report(errors=[{1, 2}]), "x")
        self.assertEqual(list(self.dir.iterdir()), [])

    def test_utf8_json_round_trip(self):
        path = reporter.save_report(minimal_report(limitations=["caf\u00e9 \u2014 \u65e5\u672c"]), "utf")
        self.assertEqual(json.loads(path.read_text(encoding="utf-8"))["limitations"], ["caf\u00e9 \u2014 \u65e5\u672c"])

    def test_configured_secrets_are_scrubbed_before_a_report_is_written(self):
        report = reporter.build_report("Email Intelligence", {"value": "a@example.com"},
                                       [Finding("Leaky", "UNKNOWN", "src", f"oops {TOKEN} and {TOKEN.split(':')[1]}", "NONE", "m")])
        text = reporter.save_report(report, "Email Intelligence").read_text(encoding="utf-8")
        self.assertNotIn(TOKEN, text)
        self.assertNotIn(TOKEN.split(":")[1], text)
        self.assertIn("<redacted>", text)
        json.loads(text)

    def test_write_is_atomic_when_it_fails_midway(self):
        with mock.patch("os.replace", side_effect=PermissionError(13, "denied")):
            with self.assertRaises(reporter.ReportError) as ctx:
                reporter.save_report(minimal_report(), "x")
        self.assertIn("PermissionError", str(ctx.exception))
        self.assertEqual(list(self.dir.iterdir()), [], "no partial file or temp file may be left behind")

    def test_existing_report_is_never_overwritten(self):
        a = reporter.save_report(minimal_report(), "same")
        b = reporter.save_report(minimal_report(), "same")
        self.assertNotEqual(a, b)
        self.assertTrue(a.exists() and b.exists())

    def test_delivery_status_is_recorded_and_the_file_stays_valid(self):
        path = reporter.save_report(minimal_report(), "rec")
        self.assertEqual(reporter.deliver_and_describe(path), "SENT")
        data = json.loads(path.read_text(encoding="utf-8"))
        self.assertEqual(data["telegram_delivery"]["status"], "SENT")
        self.assertEqual(data["module"], "Unit Test Module")
        # what Telegram received was written before the outcome existed
        self.assertEqual(json.loads(self.api.uploads[0]["bytes"])["telegram_delivery"], {"status": "PENDING"})
        self.assertEqual([p.name for p in self.dir.iterdir() if p.name.startswith(".tmp_")], [])

    def test_failed_delivery_is_recorded_too(self):
        self.api.mode = "forbidden"
        path = reporter.save_report(minimal_report(), "rec")
        self.assertTrue(reporter.deliver_and_describe(path).startswith("BOT_FORBIDDEN"))
        self.assertEqual(json.loads(path.read_text(encoding="utf-8"))["telegram_delivery"]["status"], "BOT_FORBIDDEN")

    def test_delivery_is_reported_even_if_the_metadata_cannot_be_updated(self):
        path = reporter.save_report(minimal_report(), "rec")
        with mock.patch.object(reporter, "_write_atomic", side_effect=PermissionError(13, "denied")):
            text = reporter.deliver_and_describe(path)
        self.assertIn("metadata not updated", text)

    def test_compat_wrapper(self):
        path = reporter.save_report(minimal_report(), "compat")
        self.assertEqual(reporter.send_to_telegram(path), (True, ""))
        self.api.mode = "rate"
        self.assertEqual(reporter.send_to_telegram(path), (False, tg.RATE_LIMITED))


# ------------------------------------------------------------------ every module through the same pipeline

class AllModulesPipelineTests(Base):
    """
    Runs the real engine for each of Modules 01-15. Module runners 01-10 and
    12-14 are MOCKED to return one fixed finding (so no network is needed);
    everything after the runner - JSON, terminal report, upload - is real,
    with the upload going to the LOCAL EMULATOR.
    """

    INPUTS = {"01": "someone", "02": "example.com", "03": "a@example.com", "04": "8.8.8.8", "05": "example.com",
              "06": "example.com", "07": "example.com", "08": "photo.jpg", "09": "https://example.com/x",
              "10": "someone", "12": "doc.pdf", "13": "someone", "14": "a@example.com"}

    def drive(self, answers):
        feed = iter(answers)
        self.prompts = []

        def prompt(message):
            self.prompts.append(message)   # prompt text is not console output when prompt() is mocked
            return next(feed)

        import main
        with mock.patch.object(terminal, "prompt", side_effect=prompt), \
                mock.patch.object(terminal, "clear_screen"), terminal.console.capture() as cap:
            code = main.main()
        return code, cap.get()

    def fake_runner(self, _value):
        return [Finding("Mock check", "CONFIRMED_PUBLIC", "mock-source", "fixed evidence", "HIGH", "mocked runner")]

    def test_each_module_writes_validated_json_and_delivers_it(self):
        for key in [f"{i:02d}" for i in range(1, 16)]:
            with self.subTest(module=key):
                self.api.uploads.clear()
                before = set(self.dir.glob("*.json"))
                title, label, validator, runner, needs = engine.MODULE_TABLE[key]
                table = dict(engine.MODULE_TABLE)
                answers = [key, "X"]
                if key in self.INPUTS:
                    table[key] = (title, label, validator, self.fake_runner, needs)
                    answers = [key, self.INPUTS[key], "X"]
                with mock.patch.dict(engine.MODULE_TABLE, table):
                    code, out = self.drive(answers)
                self.assertEqual(code, 0)
                (new,) = set(self.dir.glob("*.json")) - before
                data = json.loads(new.read_text(encoding="utf-8"))
                for field in reporter.REQUIRED_FIELDS:
                    self.assertIn(field, data)
                self.assertEqual(data["module"], title)
                self.assertEqual(data["telegram_delivery"]["status"], "SENT")
                self.assertIn("  Telegram  : SENT", out)
                (up,) = self.api.uploads
                self.assertEqual(up["filename"], new.name)
                self.assertEqual(json.loads(up["bytes"])["module"], title)
                self.assertNotIn(TOKEN, new.read_text(encoding="utf-8"))

    def test_terminal_report_is_fully_shown_before_the_upload_starts(self):
        printed, at_upload = [], []
        real_print = terminal.console.print

        def spy(*a, **k):
            printed.append(" ".join(str(x) for x in a))
            return real_print(*a, **k)

        real_send = tg.send_document

        def send_spy(*a, **k):
            at_upload.append("\n".join(printed))
            return real_send(*a, **k)

        title, label, validator, runner, needs = engine.MODULE_TABLE["03"]
        with mock.patch.dict(engine.MODULE_TABLE, {"03": (title, label, validator, self.fake_runner, needs)}), \
                mock.patch.object(terminal.console, "print", side_effect=spy), \
                mock.patch.object(tg, "send_document", side_effect=send_spy):
            self.drive(["03", "a@example.com", "X"])
        (seen,) = at_upload
        for expected in ("RESULTS", "SUMMARY", "REPORT SAVED", "JSON File"):
            self.assertIn(expected, seen)
        self.assertNotIn("Telegram  :", seen)

    def test_failures_keep_the_report_on_screen_and_the_workflow_going(self):
        title, label, validator, runner, needs = engine.MODULE_TABLE["03"]
        for mode, expected in (("forbidden", "BOT_FORBIDDEN"), ("rate", "RATE_LIMITED"), ("server_error", "TELEGRAM_API_ERROR")):
            with self.subTest(mode=mode):
                self.api.mode = mode
                with mock.patch.dict(engine.MODULE_TABLE, {"03": (title, label, validator, self.fake_runner, needs)}):
                    code, out = self.drive(["03", "a@example.com", "Y", "X"])
                self.assertEqual(code, 0)
                self.assertIn("RESULTS", out)
                self.assertIn(f"  Telegram  : {expected}", out)
                self.assertIn("Continue? [Y] Run from beginning   [X] Exit: ", self.prompts)   # unchanged wording
                self.assertIn("Exiting ObsidianEye OSINT.", out)

    def test_not_configured_and_invalid_configuration_do_not_crash(self):
        title, label, validator, runner, needs = engine.MODULE_TABLE["03"]
        with mock.patch.dict(engine.MODULE_TABLE, {"03": (title, label, validator, self.fake_runner, needs)}):
            self.set_config("", "")
            _, out = self.drive(["03", "a@example.com", "X"])
            self.assertIn("  Telegram  : NOT_CONFIGURED", out)
            self.set_config("bad token", CHAT)
            _, out = self.drive(["03", "a@example.com", "X"])
            self.assertIn("  Telegram  : INVALID_CONFIGURATION", out)
        self.assertEqual(self.api.calls, [])

    def test_unwritable_reports_folder_does_not_crash_a_module(self):
        title, label, validator, runner, needs = engine.MODULE_TABLE["03"]
        with mock.patch.dict(engine.MODULE_TABLE, {"03": (title, label, validator, self.fake_runner, needs)}), \
                mock.patch("os.replace", side_effect=PermissionError(13, "denied")):
            code, out = self.drive(["03", "a@example.com", "X"])
        self.assertEqual(code, 0)
        self.assertIn("JSON report not written", out)
        self.assertIn("  Telegram  : FILE_ERROR", out)
        self.assertEqual(self.api.uploads, [])

    def test_ctrl_c_while_uploading_exits_cleanly(self):
        title, label, validator, runner, needs = engine.MODULE_TABLE["03"]
        with mock.patch.dict(engine.MODULE_TABLE, {"03": (title, label, validator, self.fake_runner, needs)}), \
                mock.patch.object(tg, "send_document", side_effect=KeyboardInterrupt):
            code, out = self.drive(["03", "a@example.com"])
        self.assertEqual(code, 0)
        self.assertIn("Scan interrupted by user.", out)


if __name__ == "__main__":
    unittest.main()
