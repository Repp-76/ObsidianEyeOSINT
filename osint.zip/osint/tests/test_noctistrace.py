"""
Tests for Module 16 (NoctisTrace). Run from the project root:

    python -m unittest discover -s tests -v

No test talks to the network: requests.get / requests.post are replaced with
mocks that fail loudly if a test forgets to set them up, and the Telegram
credentials and reports folder are swapped for dummies, so your real .env is
never used.
"""

import json
import os
import socket
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import requests
from urllib3.exceptions import MaxRetryError

from config import settings
from core import engine, reporter
from modules import noctistrace as nt
from modules import noctistrace_sources as src
from utils import terminal
from utils.logging import LOG_PATH

IPQS_KEY = "ipqs-test-key-0123456789"
TWILIO_SID = "ACtestsid000000000000000000000000"
TWILIO_TOKEN = "twilio-test-token-987654321"
BOT_TOKEN = "123456789:AAFakeTokenForTestsOnly_abcdefghijk"


def response(status=200, body=None, headers=None, text=None):
    resp = requests.models.Response()
    resp.status_code = status
    resp._content = (text if text is not None else json.dumps(body if body is not None else {})).encode()
    resp.headers.update(headers or {})
    return resp


def ipqs_body(**over):
    body = {"success": True, "message": "Phone is valid.", "valid": True, "fraud_score": 12,
            "recent_abuse": False, "VOIP": False, "prepaid": False, "risky": False, "active": None,
            "name": "N/A", "carrier": "Example Mobile", "line_type": "Wireless", "country": "MY",
            "spammer": False, "leaked": False, "request_id": "abc"}
    body.update(over)
    return body


def sample_number(region="MY"):
    """A number the installed phonenumbers library itself considers valid."""
    import phonenumbers
    return phonenumbers.format_number(phonenumbers.example_number(region), phonenumbers.PhoneNumberFormat.E164)


class Base(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        env = {"IPQS_API_KEY": IPQS_KEY, "TWILIO_ACCOUNT_SID": TWILIO_SID, "TWILIO_AUTH_TOKEN": TWILIO_TOKEN}
        patches = [
            mock.patch.dict(os.environ, env),
            mock.patch("requests.get", side_effect=AssertionError("unexpected network GET")),
            mock.patch("requests.post", side_effect=AssertionError("unexpected network POST")),
            mock.patch.object(reporter, "REPORTS_DIR", Path(self._tmp.name)),
            mock.patch.object(settings, "TELEGRAM_BOT_TOKEN", ""),
            mock.patch.object(settings, "TELEGRAM_CHAT_ID", ""),
            mock.patch.object(reporter, "TELEGRAM_BOT_TOKEN", ""),
            mock.patch.object(reporter, "TELEGRAM_CHAT_ID", ""),
        ]
        for p in patches:
            p.start()
            self.addCleanup(p.stop)
        self.get = requests.get
        self.post = requests.post

    def enable_telegram(self):
        for mod in (settings, reporter):
            for name, value in (("TELEGRAM_BOT_TOKEN", BOT_TOKEN), ("TELEGRAM_CHAT_ID", "42")):
                p = mock.patch.object(mod, name, value)
                p.start()
                self.addCleanup(p.stop)

    def run_scan(self, raw):
        with terminal.console.capture() as cap:
            nt.scan_and_report(raw)
        return cap.get()

    def saved_reports(self):
        return sorted(Path(self._tmp.name).glob("noctistrace_*.json"))


# ------------------------------------------------------------------ parsing

class ParsingTests(Base):
    def test_valid_numbers_from_several_countries(self):
        for region in ("MY", "ID", "PH", "GB", "US"):
            with self.subTest(region=region):
                parsed = nt.parse_number(sample_number(region))
                self.assertTrue(parsed.ok, parsed.message)
                self.assertEqual(parsed.region, region)
                self.assertTrue(parsed.e164.startswith("+"))

    def test_formatting_variants_normalise_to_the_same_number(self):
        base = sample_number("GB")
        digits = base[1:]
        variants = [base, "+" + " ".join([digits[:2], digits[2:6], digits[6:]]), "00" + digits,
                    "+" + "-".join([digits[:2], digits[2:6], digits[6:]]), f"  {base}  "]
        results = {nt.parse_number(v).e164 for v in variants}
        self.assertEqual(results, {base})

    def test_masking_hides_the_middle_and_never_equals_the_number(self):
        parsed = nt.parse_number(sample_number("MY"))
        masked = nt.mask_number(parsed.number)
        self.assertNotEqual(masked.replace(" ", ""), parsed.e164)
        self.assertIn("*", masked)
        self.assertTrue(masked.endswith(str(parsed.number.national_number)[-3:]))

    def test_rejects_bad_input_without_raising(self):
        bad = ["", "   ", None, "abc", "0112345678", "+", "+60 11 abc", "+999999999999",
               "+6012", "+" + "1" * 40, "12345", "+60(11", "\u0e51\u0e52\u0e53"]
        for raw in bad:
            with self.subTest(raw=raw):
                parsed = nt.parse_number(raw)
                self.assertFalse(parsed.ok)
                self.assertTrue(parsed.code)
                self.assertTrue(parsed.message)

    def test_missing_dependency_is_reported_not_raised(self):
        with mock.patch.object(nt, "phonenumbers", None):
            parsed = nt.parse_number("+60112345678")
        self.assertFalse(parsed.ok)
        self.assertEqual(parsed.code, "DEPENDENCY_MISSING")

    def test_invalid_input_makes_no_requests_and_writes_no_report(self):
        out = self.run_scan("0112345678")
        self.assertIn("international format", out)
        self.get.assert_not_called()
        self.assertEqual(self.saved_reports(), [])


# ------------------------------------------------------------------ source failures

class SourceFailureTests(Base):
    """Whatever goes wrong, the result must be a failure status - never NOT_FOUND."""

    def failure_cases(self):
        gai = MaxRetryError(None, "/x", reason=socket.gaierror(-2, "Name or service not known"))
        return {
            "timeout": (requests.exceptions.Timeout(f"timed out {IPQS_KEY}"), src.SOURCE_UNAVAILABLE),
            "connection": (requests.exceptions.ConnectionError(f"refused /phone/{IPQS_KEY}/x"), src.SOURCE_UNAVAILABLE),
            "dns": (requests.exceptions.ConnectionError(gai), src.SOURCE_UNAVAILABLE),
            "tls": (requests.exceptions.SSLError("bad cert"), src.SOURCE_UNAVAILABLE),
            "other": (requests.exceptions.InvalidURL(IPQS_KEY), src.SOURCE_UNAVAILABLE),
            "http500": (response(500), src.SOURCE_UNAVAILABLE),
            "http404": (response(404), src.SOURCE_UNAVAILABLE),
            "ratelimit": (response(429, headers={"Retry-After": "30"}), src.SOURCE_UNAVAILABLE),
            "unauthorized": (response(401), src.ACCESS_RESTRICTED),
            "forbidden": (response(403), src.ACCESS_RESTRICTED),
            "redirect": (response(302, headers={"Location": "https://elsewhere.example/"}), src.SOURCE_UNAVAILABLE),
            "bad_json": (response(200, text="<html>not json</html>"), src.SOURCE_UNAVAILABLE),
            "json_list": (response(200, body=[1, 2]), src.SOURCE_UNAVAILABLE),
            "proxy_block": (response(403, headers={"x-deny-reason": "host_not_allowed"}), src.SOURCE_UNAVAILABLE),
            "api_says_no": (response(200, body={"success": False, "message": "You have insufficient credits."}),
                            src.SOURCE_UNAVAILABLE),
        }

    def check(self, result, expected_status):
        self.assertEqual(result.status, expected_status)
        for f in result.findings:
            self.assertEqual(f.verification_status, expected_status)
            self.assertNotEqual(f.verification_status, src.NOT_FOUND)
            self.assertNotIn(f.result, ("NO_REPORT_FOUND", "NOT_FOUND"))
            self.assertEqual(f.result, "NOT_QUERIED")
            self.assertEqual(f.tags, [])

    def test_ipqs_failures(self):
        for name, (outcome, expected) in self.failure_cases().items():
            with self.subTest(case=name):
                self.get.side_effect = [outcome]
                self.check(src.check_ipqs("+60112345678"), expected)

    def test_twilio_failures(self):
        for name, (outcome, expected) in self.failure_cases().items():
            if name == "api_says_no":
                continue  # IPQS-specific envelope
            with self.subTest(case=name):
                self.get.side_effect = [outcome]
                self.check(src.check_twilio_caller_name("+14155550123", "US"), expected)

    def test_at_most_one_request_and_no_redirect_following(self):
        self.get.side_effect = [response(500)]
        src.check_ipqs("+60112345678")
        self.assertEqual(self.get.call_count, 1)
        self.assertIs(self.get.call_args.kwargs["allow_redirects"], False)

    def test_dns_failure_is_named_as_such(self):
        gai = MaxRetryError(None, "/x", reason=socket.gaierror(-2, "Name or service not known"))
        self.get.side_effect = [requests.exceptions.ConnectionError(gai)]
        self.assertIn("DNS", src.check_ipqs("+60112345678").note)


# ------------------------------------------------------------------ IPQS mapping

class IpqsMappingTests(Base):
    def query(self, **over):
        self.get.side_effect = [response(200, ipqs_body(**over))]
        return src.check_ipqs("+60112345678")

    def find(self, result, ftype):
        return [f for f in result.findings if f.finding_type == ftype]

    def test_spam_flag_is_source_attributed_and_unverified(self):
        result = self.query(spammer=True)
        (spam,) = self.find(result, "spam_report_signal")
        self.assertEqual(spam.result, "FLAGGED")
        self.assertEqual(spam.verification_status, src.NOT_VERIFIED)
        self.assertEqual([t for t, _ in spam.tags], ["#spam_reported"])
        self.assertEqual(spam.source, "IPQualityScore Phone Validation")

    def test_clean_answer_is_not_found_but_never_called_safe(self):
        result = self.query()
        (spam,) = self.find(result, "spam_report_signal")
        self.assertEqual(spam.verification_status, src.NOT_FOUND)
        self.assertIn("not mean the number is safe", spam.evidence_summary)
        (flags,) = self.find(result, "fraud_risk_flag")
        self.assertEqual(flags.result, "NO_REPORT_FOUND")

    def test_null_fields_are_unknown_not_not_found(self):
        result = self.query(spammer=None, recent_abuse=None, risky=None)
        for ftype in ("spam_report_signal", "fraud_risk_flag"):
            (f,) = self.find(result, ftype)
            self.assertEqual(f.verification_status, src.UNKNOWN)
            self.assertEqual(f.result, "UNKNOWN")

    def test_missing_and_wrongly_typed_fields_are_unknown(self):
        body = ipqs_body(spammer="yes", fraud_score="high", active="maybe")
        del body["risky"]
        self.get.side_effect = [response(200, body)]
        result = src.check_ipqs("+60112345678")
        (spam,) = self.find(result, "spam_report_signal")
        self.assertEqual(spam.verification_status, src.UNKNOWN)
        (score,) = self.find(result, "fraud_score")
        self.assertEqual(score.verification_status, src.UNKNOWN)
        self.assertEqual(score.tags, [])
        (reach,) = self.find(result, "reachability")
        self.assertEqual(reach.verification_status, src.UNKNOWN)

    def test_fraud_flags_and_score_threshold(self):
        result = self.query(recent_abuse=True, fraud_score=88)
        (flags,) = self.find(result, "fraud_risk_flag")
        self.assertEqual(flags.result, "FLAGGED")
        (score,) = self.find(result, "fraud_score")
        self.assertEqual(score.result, "FLAGGED")
        low = self.find(self.query(fraud_score=74), "fraud_score")[0]
        self.assertEqual(low.result, "INFO")
        self.assertEqual(low.tags, [])

    def test_no_definitive_criminal_labels_are_ever_produced(self):
        result = self.query(spammer=True, recent_abuse=True, risky=True, fraud_score=99)
        blob = json.dumps([f.to_dict() for f in result.findings]).lower()
        for word in ("#scammer", "#criminal", "#fraudster"):
            self.assertNotIn(word, blob)

    def test_reachability_only_reported_when_the_source_says_so(self):
        self.assertEqual(self.find(self.query(active=None), "reachability")[0].normalized_label, "reachability_unknown")
        self.assertEqual(self.find(self.query(active=True), "reachability")[0].normalized_label, "reachability_active")
        self.assertEqual(self.find(self.query(active=False), "reachability")[0].normalized_label, "reachability_inactive")

    def test_identity_fields_are_never_carried_into_findings(self):
        result = self.query(name="Jane Q Example", leaked=True,
                            associated_email_addresses={"status": "ok", "emails": ["jane@example.com"]},
                            identity_data={"names": [{"first_name": "Jane"}]}, zip_code="50000", city="Kuala Lumpur")
        blob = json.dumps([f.to_dict() for f in result.findings])
        for private in ("Jane", "jane@example.com", "50000", "leaked"):
            self.assertNotIn(private, blob)

    def test_unconfigured_key_makes_no_request(self):
        with mock.patch.dict(os.environ, {"IPQS_API_KEY": ""}):
            result = src.check_ipqs("+60112345678")
        self.assertEqual(result.status, src.NOT_CONFIGURED)
        self.get.assert_not_called()

    def test_request_goes_to_ipqs_only_and_key_stays_out_of_output(self):
        result = self.query(spammer=True)
        url = self.get.call_args.args[0]
        self.assertTrue(url.startswith("https://www.ipqualityscore.com/api/json/phone/"))
        self.assertTrue(url.endswith("/60112345678"))
        self.assertNotIn(IPQS_KEY, json.dumps([f.to_dict() for f in result.findings]))
        self.assertNotIn(IPQS_KEY, json.dumps(result.to_dict()))


# ------------------------------------------------------------------ Twilio mapping

class TwilioMappingTests(Base):
    def query(self, caller, region="US"):
        self.get.side_effect = [response(200, {"country_code": "US", "valid": True, "caller_name": caller})]
        return src.check_twilio_caller_name("+14155550123", region)

    def test_business_label_is_shown_as_public_label_with_owner_unverified(self):
        result = self.query({"caller_name": "Acme Widgets LLC", "caller_type": "BUSINESS", "error_code": None})
        (f,) = result.findings
        self.assertEqual(f.original_label, "Acme Widgets LLC")
        self.assertEqual(f.normalized_label, "Public Business Name")
        self.assertIn("OWNER NOT VERIFIED", f.evidence_summary)
        self.assertEqual(f.verification_status, src.NOT_VERIFIED)
        self.assertEqual({t for t, _ in f.tags}, {"#business", "#caller_id_label"})

    def test_consumer_names_are_withheld_everywhere(self):
        result = self.query({"caller_name": "Sergio Suarez", "caller_type": "CONSUMER", "error_code": None})
        blob = json.dumps([f.to_dict() for f in result.findings]) + json.dumps(result.to_dict())
        self.assertNotIn("Sergio", blob)
        self.assertNotIn("Suarez", blob)
        (f,) = result.findings
        self.assertEqual(f.result, "PUBLIC_LABEL_FOUND")
        self.assertNotIn("#business", [t for t, _ in f.tags])

    def test_missing_label_is_not_found_but_missing_package_is_unknown(self):
        (nf,) = self.query({"caller_name": None, "caller_type": None, "error_code": None}).findings
        self.assertEqual(nf.verification_status, src.NOT_FOUND)
        (unk,) = self.query(None).findings
        self.assertEqual(unk.verification_status, src.UNKNOWN)

    def test_provider_error_code_is_source_unavailable(self):
        result = self.query({"caller_name": None, "caller_type": None, "error_code": 60600})
        self.assertEqual(result.status, src.SOURCE_UNAVAILABLE)
        self.assertEqual(result.findings[0].result, "NOT_QUERIED")

    def test_non_us_numbers_are_never_sent(self):
        result = src.check_twilio_caller_name("+60112345678", "MY")
        self.assertEqual(result.status, src.NOT_APPLICABLE)
        self.get.assert_not_called()

    def test_missing_credentials_make_no_request(self):
        with mock.patch.dict(os.environ, {"TWILIO_AUTH_TOKEN": ""}):
            result = src.check_twilio_caller_name("+14155550123", "US")
        self.assertEqual(result.status, src.NOT_CONFIGURED)
        self.get.assert_not_called()

    def test_credentials_travel_as_basic_auth_not_in_the_url(self):
        self.query({"caller_name": None, "caller_type": None, "error_code": None})
        self.assertEqual(self.get.call_args.kwargs["auth"], (TWILIO_SID, TWILIO_TOKEN))
        self.assertNotIn(TWILIO_TOKEN, self.get.call_args.args[0])
        self.assertNotIn(TWILIO_SID, self.get.call_args.args[0])


# ------------------------------------------------------------------ payload / report

class PayloadTests(Base):
    SPEC_KEYS = {"module", "target_type", "masked_number", "normalized_number", "validation", "public_identity",
                 "scam_reports", "spam_reports", "tags", "sources", "limitations", "verification_notes",
                 "timestamp", "status"}
    EVIDENCE_KEYS = {"source", "source_url", "timestamp", "finding_type", "original_label", "normalized_label",
                     "verification_status", "confidence_reason", "evidence_summary"}

    def payload_for(self, region="MY", ipqs=None, twilio=None):
        number = sample_number(region)
        answers = []
        answers.append(ipqs if ipqs is not None else response(200, ipqs_body()))
        if region == "US":
            answers.append(twilio if twilio is not None else response(200, {"caller_name": None}))
        self.get.side_effect = answers
        parsed = nt.parse_number(number)
        return nt.build_payload(parsed, nt.collect_sources(parsed)), number

    def all_findings(self, payload):
        for key in ("public_identity", "scam_reports", "spam_reports"):
            yield from payload[key]["findings"]
        yield from payload["validation"]["vendor_findings"]
        yield payload["validation"]["evidence"]

    def test_json_has_the_required_keys_and_every_finding_has_the_evidence_fields(self):
        payload, number = self.payload_for()
        self.assertTrue(self.SPEC_KEYS <= set(payload))
        self.assertEqual(payload["normalized_number"], number)
        self.assertNotEqual(payload["masked_number"].replace(" ", ""), number)
        for f in self.all_findings(payload):
            self.assertTrue(self.EVIDENCE_KEYS <= set(f), f)
        json.dumps(payload)

    def test_flagged_results_get_evidence_tags_and_unverified(self):
        payload, _ = self.payload_for(ipqs=response(200, ipqs_body(spammer=True, recent_abuse=True)))
        tags = {(t["tag"], t["source"]) for t in payload["tags"]}
        name = "IPQualityScore Phone Validation"
        self.assertIn(("#spam_reported", name), tags)
        self.assertIn(("#fraud_risk_signal", name), tags)
        self.assertIn(("#unverified", name), tags)
        self.assertNotIn(("#not_found", name), tags)
        self.assertEqual(payload["spam_reports"]["status"], "REPORTED_UNVERIFIED")
        self.assertEqual(payload["scam_reports"]["status"], "REPORTED_UNVERIFIED")
        self.assertIn("OWNER NOT VERIFIED", " ".join(payload["verification_notes"]))

    def test_clean_answer_reads_not_found_without_claiming_safety(self):
        payload, _ = self.payload_for()
        self.assertEqual(payload["spam_reports"]["status"], "NOT_FOUND")
        # MY scam status: IPQS is clean but the official Semak Mule check was not run
        self.assertEqual(payload["scam_reports"]["status"], "NOT_FOUND_PARTIAL_COVERAGE")
        self.assertNotIn("is safe", payload["summary"].replace("not evidence that it is safe", ""))
        self.assertIn("not evidence", payload["summary"])

    def test_failed_source_never_becomes_not_found(self):
        payload, _ = self.payload_for(ipqs=requests.exceptions.Timeout())
        self.assertEqual(payload["spam_reports"]["status"], "SOURCE_UNAVAILABLE")
        self.assertEqual(payload["status"], "completed_with_gaps")
        self.assertIn("#source_unavailable", {t["tag"] for t in payload["tags"]})
        self.assertNotIn("#not_found", {t["tag"] for t in payload["tags"]})

    def test_rejected_credentials_read_access_restricted(self):
        payload, _ = self.payload_for(ipqs=response(401))
        self.assertEqual(payload["spam_reports"]["status"], "ACCESS_RESTRICTED")

    def test_unconfigured_everything_is_unknown(self):
        with mock.patch.dict(os.environ, {"IPQS_API_KEY": "", "TWILIO_ACCOUNT_SID": ""}):
            parsed = nt.parse_number(sample_number("MY"))
            payload = nt.build_payload(parsed, nt.collect_sources(parsed))
        self.assertEqual(payload["spam_reports"]["status"], "UNKNOWN")
        self.assertEqual(payload["public_identity"]["status"], "UNKNOWN")
        self.assertEqual(payload["status"], "completed_no_online_sources")
        self.assertIn("unknown", payload["summary"])

    def test_malaysian_numbers_get_the_manual_semak_mule_pointer_and_others_do_not(self):
        my, _ = self.payload_for("MY")
        pointers = [f for f in my["scam_reports"]["findings"] if f["finding_type"] == "manual_check_pointer"]
        self.assertEqual(len(pointers), 1)
        self.assertEqual(pointers[0]["verification_status"], src.ACCESS_RESTRICTED)
        self.assertEqual(pointers[0]["result"], "NOT_QUERIED")
        gb, _ = self.payload_for("GB")
        self.assertFalse([f for f in gb["scam_reports"]["findings"] if f["finding_type"] == "manual_check_pointer"])

    def test_active_status_comes_only_from_a_source_that_reports_it(self):
        payload, _ = self.payload_for()
        self.assertEqual(payload["validation"]["reachability"]["status"], "UNKNOWN")
        payload, _ = self.payload_for(ipqs=response(200, ipqs_body(active=True)))
        self.assertEqual(payload["validation"]["reachability"]["status"], "ACTIVE")

    def test_us_number_business_label_reaches_public_identity(self):
        twilio = response(200, {"caller_name": {"caller_name": "Acme Widgets LLC", "caller_type": "BUSINESS", "error_code": None}})
        payload, _ = self.payload_for("US", twilio=twilio)
        self.assertEqual(payload["public_identity"]["status"], "PUBLIC_LABEL_FOUND")
        self.assertEqual(payload["public_identity"]["owner_verification"], "OWNER NOT VERIFIED")

    def test_terminal_report_masks_the_number_and_json_file_is_written(self):
        number = sample_number("MY")
        typed = f"{number[:3]} {number[3:5]}-{number[5:]}"   # differs from plain E.164
        self.get.side_effect = [response(200, ipqs_body(spammer=True))]
        out = self.run_scan(typed)
        self.assertIn(typed, out)             # the Input line echoes what was typed
        self.assertNotIn(number, out)         # the normalized number only appears masked
        self.assertIn("SPAM REPORT SUMMARY", out)
        self.assertIn("#spam_reported", out)
        (path,) = self.saved_reports()
        data = json.loads(path.read_text(encoding="utf-8"))
        self.assertEqual(data["normalized_number"], number)

    def test_untrusted_text_cannot_break_terminal_markup(self):
        hostile = "[/bold][red]oops[/red] [link=http://x]"
        twilio = response(200, {"caller_name": {"caller_name": hostile, "caller_type": "BUSINESS", "error_code": None}})
        payload, _ = self.payload_for("US", twilio=twilio)
        with terminal.console.capture() as cap:
            nt.render_body(payload, sample_number("US"), nt.datetime.now(), nt.datetime.now())
        self.assertIn("[/bold]", cap.get())


# ------------------------------------------------------------------ Telegram / secrets

class DeliveryTests(Base):
    def report(self):
        parsed = nt.parse_number(sample_number("GB"))
        self.get.side_effect = [response(200, ipqs_body())]
        payload = nt.build_payload(parsed, nt.collect_sources(parsed))
        path, err = nt._save(payload)
        self.assertEqual(err, "")
        return path

    def test_not_configured(self):
        self.assertEqual(nt._deliver(self.report()), "NOT CONFIGURED")
        self.post.assert_not_called()

    def test_success(self):
        self.enable_telegram()
        self.post.side_effect = [response(200)]
        self.assertEqual(nt._deliver(self.report()), "Delivered")
        self.assertEqual(self.post.call_args.kwargs["data"]["chat_id"], "42")

    def test_rate_limit_and_api_errors_are_reported(self):
        self.enable_telegram()
        self.post.side_effect = [response(429), response(400)]
        self.assertEqual(nt._deliver(self.report()), "FAILED (HTTP 429)")
        self.assertEqual(nt._deliver(self.report()), "FAILED (HTTP 400)")

    def test_network_errors_are_reported_by_type_only(self):
        self.enable_telegram()
        for exc in (requests.exceptions.ConnectionError("x"), requests.exceptions.Timeout("x"),
                    requests.exceptions.SSLError("x")):
            with self.subTest(exc=type(exc).__name__):
                self.post.side_effect = [exc]
                self.assertEqual(nt._deliver(self.report()), f"FAILED ({type(exc).__name__})")

    def test_missing_report_file_is_handled(self):
        self.enable_telegram()
        self.assertTrue(nt._deliver(Path(self._tmp.name) / "gone.json").startswith("FAILED"))
        self.assertEqual(nt._deliver(None), "SKIPPED (no report file)")

    def test_unwritable_reports_dir_is_handled_and_telegram_is_skipped(self):
        self.enable_telegram()
        self.get.side_effect = [response(200, ipqs_body())]
        with mock.patch.object(reporter, "save_report", side_effect=PermissionError("denied")):
            out = self.run_scan(sample_number("GB"))
        self.assertIn("NOT WRITTEN (PermissionError)", out)
        self.assertIn("SKIPPED", out)
        self.post.assert_not_called()

    def test_delivery_happens_after_the_terminal_report(self):
        self.enable_telegram()
        order = []
        self.get.side_effect = [response(200, ipqs_body())]
        self.post.side_effect = lambda *a, **k: order.append("telegram") or response(200)
        with mock.patch.object(nt, "render_body", side_effect=lambda *a, **k: order.append("report")):
            with terminal.console.capture():
                nt.scan_and_report(sample_number("GB"))
        self.assertEqual(order, ["report", "telegram"])

    def test_secrets_never_reach_terminal_json_or_log(self):
        self.enable_telegram()
        leaky = f"HTTPSConnectionPool: url: /api/json/phone/{IPQS_KEY}/447400123456 token {BOT_TOKEN}"
        self.get.side_effect = [requests.exceptions.ConnectionError(leaky)]
        self.post.side_effect = [requests.exceptions.ConnectionError(
            f"Max retries exceeded with url: /bot{BOT_TOKEN}/sendDocument")]
        log_start = LOG_PATH.stat().st_size if LOG_PATH.exists() else 0   # only judge lines written by this test
        out = self.run_scan(sample_number("GB"))
        (path,) = self.saved_reports()
        log_text = ""
        if LOG_PATH.exists():
            with open(LOG_PATH, "rb") as fh:
                fh.seek(log_start)
                log_text = fh.read().decode("utf-8", "replace")
        for secret in (IPQS_KEY, BOT_TOKEN, TWILIO_TOKEN, BOT_TOKEN.split(":")[1]):
            self.assertNotIn(secret, out)
            self.assertNotIn(secret, path.read_text(encoding="utf-8"))
            self.assertNotIn(secret, log_text)
        self.assertIn("FAILED (ConnectionError)", out)


# ------------------------------------------------------------------ engine integration

ORIGINAL_MODULES = {
    "01": ("Username Intelligence", "Username", True), "02": ("Domain Intelligence", "Domain", True),
    "03": ("Email Intelligence", "Email address", True), "04": ("IP Intelligence", "IP address", True),
    "05": ("DNS Intelligence", "Domain", True), "06": ("Website Technology Intelligence", "Website URL or domain", True),
    "07": ("HTTP Security Header Analysis", "Website URL or domain", True),
    "08": ("Image Metadata Intelligence", "Path to local image file", True),
    "09": ("URL Intelligence", "Full URL (include http:// or https://)", True),
    "10": ("Social Profile Discovery", "Username or profile URL", True),
    "11": ("Digital Footprint Analyzer", None, False),
    "12": ("Public Document Metadata", "Path to local document (.pdf/.docx/.xlsx/.pptx)", True),
    "13": ("Username Availability Monitor", "Username", True), "14": ("Public Breach Exposure Check", "Email address", True),
    "15": ("OSINT Report Generator", None, False),
}


class EngineTests(Base):
    def drive(self, answers):
        feed = iter(answers)

        def prompt(msg):
            value = next(feed)
            if value == "<CTRL+C>":
                raise KeyboardInterrupt
            return value

        import main
        with mock.patch.object(terminal, "prompt", side_effect=prompt), \
                mock.patch.object(terminal, "clear_screen"), \
                terminal.console.capture() as cap:
            code = main.main()
        return code, cap.get()

    def test_modules_01_to_15_are_unchanged_in_the_table(self):
        for key, (title, label, needs_target) in ORIGINAL_MODULES.items():
            with self.subTest(module=key):
                got = engine.MODULE_TABLE[key]
                self.assertEqual((got[0], got[1], got[4]), (title, label, needs_target))
        self.assertEqual(engine.MENU_ORDER, [f"{i:02d}" for i in range(1, 17)])
        self.assertEqual(settings.MODULE_COUNT, 16)

    def test_menu_lists_module_16_last(self):
        code, out = self.drive(["X"])
        self.assertEqual(code, 0)
        self.assertIn("[15] OSINT Report Generator", out)
        self.assertIn("[16] NoctisTrace", out)

    def test_run_restart_with_y_then_exit_with_x(self):
        self.get.side_effect = [response(200, ipqs_body())] * 2
        code, out = self.drive(["16", sample_number("MY"), "Y", "16", sample_number("GB"), "X"])
        self.assertEqual(code, 0)
        self.assertEqual(out.count("NOCTISTRACE"), 2)
        self.assertEqual(out.count("MAIN MENU"), 2)  # start, and again after Y; X exits without a third
        self.assertIn("Exiting ObsidianEye OSINT.", out)

    def test_empty_and_invalid_input_return_to_menu(self):
        code, out = self.drive(["16", "", "Y", "16", "0112345678", "X"])
        self.assertEqual(code, 0)
        self.assertIn("No input provided, returning to menu.", out)
        self.assertIn("international format", out)
        self.get.assert_not_called()

    def test_ctrl_c_at_the_prompt_exits_cleanly(self):
        code, out = self.drive(["16", "<CTRL+C>"])
        self.assertEqual(code, 0)
        self.assertIn("Scan interrupted by user.", out)

    def test_ctrl_c_during_a_scan_exits_cleanly_and_writes_nothing(self):
        self.get.side_effect = KeyboardInterrupt
        code, out = self.drive(["16", sample_number("MY")])
        self.assertEqual(code, 0)
        self.assertIn("Scan interrupted by user.", out)
        self.assertEqual(self.saved_reports(), [])

    def test_unexpected_crash_is_contained(self):
        with mock.patch.object(nt, "collect_sources", side_effect=RuntimeError("boom")):
            code, out = self.drive(["16", sample_number("MY"), "X"])
        self.assertEqual(code, 0)
        self.assertIn("Module crashed unexpectedly: RuntimeError", out)
        self.assertIn("No fake results were produced.", out)


if __name__ == "__main__":
    unittest.main()
