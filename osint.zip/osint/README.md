# ObsidianEye OSINT

Public Intelligence & Digital Footprint Explorer
Developer: Repp76

A terminal OSINT tool that collects and analyzes information that is
publicly available from legitimate sources - real DNS queries, real HTTP
requests, real local file/metadata parsing. Nothing is hardcoded or
fabricated. When a source can't be reached or requires credentials the
tool doesn't have, it says so explicitly instead of making something up.

## Installation

### Linux / macOS

```
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python main.py
```

### Termux

```
pkg update
pkg install python
pip install -r requirements.txt
cp .env.example .env
python main.py
```

No root access is required.

### Windows

```
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
python main.py
```

## Configuration

Everything sensitive lives in `.env` (see `.env.example`), never in source:

- `TELEGRAM_BOT_TOKEN` / `TELEGRAM_CHAT_ID` - if set, every completed scan's
  JSON report is also forwarded to that chat as a document.
- `HIBP_API_KEY` - required for Module 14 (breach exposure). Without it,
  the module honestly reports `REQUIRES_API_CONFIGURATION` instead of
  faking a result.

## Modules

| # | Module | What it actually does |
|---|--------|------------------------|
| 01 | Username Intelligence | Checks the username against 17 real platform URLs (status codes, JSON endpoints, or marker text). Platforms that can't be checked reliably without JS/login (Instagram, TikTok, X, Threads, Facebook, LinkedIn) are reported as `BLOCKED` with the reason. |
| 02 | Domain Intelligence | Resolves IPs, follows HTTPS redirects, queries NS/MX/TXT/CAA/SOA, checks DNSSEC via a real DNSKEY lookup. |
| 03 | Email Intelligence | Syntax validation, MX lookup, known-provider match, known-disposable-domain match. No login or password-reset attempts. |
| 04 | IP Intelligence | Reverse DNS (PTR) plus RDAP network ownership (ASN, org, registered country) via `ipwhois`. Clearly labeled as network-level, not a physical address. |
| 05 | DNS Intelligence | Full record dump: A, AAAA, CNAME, MX, NS, TXT, SOA, CAA, SRV, plus a correct DNSSEC/DNSKEY check. |
| 06 | Website Technology Intelligence | Header and HTML-pattern based fingerprinting (CMS, JS framework, CDN, session cookies), each with the exact evidence that triggered it. |
| 07 | HTTP Security Header Analysis | Checks 9 standard security headers, reports PRESENT/MISSING with a plain-English explanation - never auto-escalated to "vulnerability". |
| 08 | Image Metadata Intelligence | Local EXIF parsing via Pillow. GPS coordinates are decoded only if present, with an explicit privacy warning. Nothing is uploaded. |
| 09 | URL Intelligence | Structural breakdown, redirect trace, and a real TLS handshake/certificate inspection. Observation only, no exploitation. |
| 10 | Social Profile Discovery | Same platform checks as Module 01, read as profile discovery (`VERIFIED_PUBLIC_PROFILE` / `POSSIBLE_MATCH` / `UNCONFIRMED` / `NOT_FOUND`). |
| 11 | Digital Footprint Analyzer | Aggregates counts from modules already run earlier in the same session. Does not perform new lookups or claim identity. |
| 12 | Public Document Metadata | Local metadata extraction for PDF, DOCX, XLSX, PPTX via `pypdf`, `python-docx`, `openpyxl`, `python-pptx`. |
| 13 | Username Availability Monitor | Reuses Module 01's checks, read as AVAILABLE / REGISTERED / UNKNOWN / BLOCKED. |
| 14 | Public Breach Exposure Check | Have I Been Pwned API (breach names/dates only, never credentials). Requires `HIBP_API_KEY`. |
| 15 | OSINT Report Generator | Every module already writes its own JSON report right after running; this browses what's accumulated in `reports/`. |

## Evidence model

Every finding carries `status`, `confidence`, `source`, `evidence`,
`methodology`, and a `timestamp`. Statuses are never blurred together:
`NOT_FOUND` (checked, nothing there) is always distinct from `NOT_TESTED`
(never checked) and `SOURCE_UNAVAILABLE` (checked, source didn't answer
usably). Confidence is assigned by what kind of evidence was collected,
never generated randomly.

## Reports

Every completed module writes a timestamped JSON file to `reports/`,
structured as:

```json
{
  "tool": {"name": "ObsidianEye OSINT", "version": "1.0.0", "developer": "Repp76"},
  "scan": {"timestamp": "...", "module": "...", "status": "completed"},
  "target": {},
  "findings": [],
  "sources": [],
  "errors": [],
  "warnings": []
}
```

That file is the authoritative record of a scan, whether or not Telegram
delivery is configured or succeeds.

## Ethical boundary

This is a public-information tool. It does not attempt login bypass,
CAPTCHA bypass, private account access, credential theft, or any form of
exploitation. Requests use timeouts and a real user agent, and platforms
that require authentication or active anti-bot defeat are reported as
`BLOCKED` rather than worked around.

## Test status

The modules were built and code-reviewed together, but this build
environment has outbound network access disabled, so live network calls
(HTTP requests, DNS resolution, TLS handshakes, RDAP/HIBP lookups) could
not be executed here. What was verified in this environment:

- [x] Project imports cleanly, no syntax/import errors across all 15 modules
- [x] Input validation (username/domain/email/IP/URL regex and format checks)
- [x] Error-path logic for DNS/HTTP/TLS failures (code inspection - each
      distinct error is mapped to its own status, none silently swallowed)
- [x] JSON report structure and serialization
- [x] Local-file modules (Image Metadata, Document Metadata) logic against
      the installed libraries' documented APIs
- [ ] Live checks against GitHub/Reddit/Twitch/etc. - requires outbound
      network access, run `python main.py` in your own environment to
      confirm live behavior against current site markup (sites do change
      their HTML/anti-bot behavior over time; the `text_marker` checks in
      particular may need their marker strings updated if a platform
      redesigns its pages)
- [ ] Telegram delivery - requires a real bot token/chat ID to confirm
- [ ] Live HIBP lookup - requires a paid API key to confirm

If a live platform check ever seems wrong, that's a real possibility
worth checking by hand - the design goal here was to fail honestly
(`UNKNOWN`/`BLOCKED`/`SOURCE_UNAVAILABLE`) rather than fail silently into
a false positive.
