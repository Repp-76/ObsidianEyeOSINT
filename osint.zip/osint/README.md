# ObsidianEye OSINT

Public Intelligence & Digital Footprint Explorer
Developer: Repp76

A terminal OSINT tool that collects and analyzes information that is
publicly available from legitimate sources - real DNS queries, real HTTP
requests, real local file/metadata parsing. Nothing is hardcoded or
fabricated. When a source can't be reached or requires credentials the
tool doesn't have, it says so explicitly instead of making something up.

## Installation

### Linux / macOS

```
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python main.py
```

### Termux

```
pkg update
pkg install python
pip install -r requirements.txt
cp .env.example .env
python main.py
```

No root access is required.

### Windows

```
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
python main.py
```

## Configuration

Everything sensitive lives in `.env` (see `.env.example`), never in source:

- `TELEGRAM_BOT_TOKEN` / `TELEGRAM_CHAT_ID` - if set, every completed scan's
  JSON report is also forwarded to that chat as a document.
- `HIBP_API_KEY` - required for Module 14 (breach exposure). Without it,
  the module honestly reports `REQUIRES_API_CONFIGURATION` instead of
  faking a result.

- `IPQS_API_KEY` - optional, Module 16. Enables the IPQualityScore spam /
  fraud-risk lookup for numbers worldwide.
- `TWILIO_ACCOUNT_SID` / `TWILIO_AUTH_TOKEN` - optional, Module 16. Enables
  the caller-name (CNAM) label lookup for US numbers.

## Modules

| # | Module | What it actually does |
|---|--------|------------------------|
| 01 | Username Intelligence | Checks the username against 17 real platform URLs (status codes, JSON endpoints, or marker text). Platforms that can't be checked reliably without JS/login (Instagram, TikTok, X, Threads, Facebook, LinkedIn) are reported as `BLOCKED` with the reason. |
| 02 | Domain Intelligence | Resolves IPs, follows HTTPS redirects, queries NS/MX/TXT/CAA/SOA, checks DNSSEC via a real DNSKEY lookup. |
| 03 | Email Intelligence | Syntax validation, MX lookup, known-provider match, known-disposable-domain match. No login or password-reset attempts. |
| 04 | IP Intelligence | Reverse DNS (PTR) plus RDAP network ownership (ASN, org, registered country) via `ipwhois`. Clearly labeled as network-level, not a physical address. |
| 05 | DNS Intelligence | Full record dump: A, AAAA, CNAME, MX, NS, TXT, SOA, CAA, SRV, plus a correct DNSSEC/DNSKEY check. |
| 06 | Website Technology Intelligence | Header and HTML-pattern based fingerprinting (CMS, JS framework, CDN, session cookies), each with the exact evidence that triggered it. |
| 07 | HTTP Security Header Analysis | Checks 9 standard security headers, reports PRESENT/MISSING with a plain-English explanation - never auto-escalated to "vulnerability". |
| 08 | Image Metadata Intelligence | Local EXIF parsing via Pillow. GPS coordinates are decoded only if present, with an explicit privacy warning. Nothing is uploaded. |
| 09 | URL Intelligence | Structural breakdown, redirect trace, and a real TLS handshake/certificate inspection. Observation only, no exploitation. |
| 10 | Social Profile Discovery | Same platform checks as Module 01, read as profile discovery (`VERIFIED_PUBLIC_PROFILE` / `POSSIBLE_MATCH` / `UNCONFIRMED` / `NOT_FOUND`). |
| 11 | Digital Footprint Analyzer | Aggregates counts from modules already run earlier in the same session. Does not perform new lookups or claim identity. |
| 12 | Public Document Metadata | Local metadata extraction for PDF, DOCX, XLSX, PPTX via `pypdf`, `python-docx`, `openpyxl`, `python-pptx`. |
| 13 | Username Availability Monitor | Reuses Module 01's checks, read as AVAILABLE / REGISTERED / UNKNOWN / BLOCKED. |
| 14 | Public Breach Exposure Check | Have I Been Pwned API (breach names/dates only, never credentials). Requires `HIBP_API_KEY`. |
| 15 | OSINT Report Generator | Every module already writes its own JSON report right after running; this browses what's accumulated in `reports/`. |
| 16 | NoctisTrace - Global Phone Reputation Intelligence | Offline number validation/normalisation (`phonenumbers`), then optional source lookups: IPQualityScore (spam / fraud-risk flags), Twilio caller-name label (US only), plus a pointer to PDRM's Semak Mule for `+60` numbers. Everything is attributed to its source and marked unverified; see below. |

## Module 16 - NoctisTrace

Enter a number in international form (`+6011...`, `+62...`, `+63...`,
`+44...`, `+1...`, or `00` instead of `+`). Formatting variants normalise to
E.164. The terminal shows the number masked; the JSON report keeps the
normalised number.

What it does and does not claim:

- **Validation is local.** "Valid" means the number fits an assigned range in
  that country's numbering plan. It does not mean assigned, active or
  reachable. Reachability stays `UNKNOWN` unless a source says otherwise.
- **Reputation is attributed.** IPQualityScore flags are shown as
  `NOT_VERIFIED` vendor assessments with the field they came from. No
  `#scammer`/`#criminal` style tag is ever produced.
- **Owner is never asserted.** Caller-ID labels are shown as a public label
  with `OWNER NOT VERIFIED`. Consumer-type labels are withheld so private
  names are not stored. IPQS owner/identity fields are deliberately ignored.
- **Statuses stay separate.** `NOT_FOUND` (source answered, nothing there),
  `UNKNOWN` (source answered, field empty), `SOURCE_UNAVAILABLE` (network,
  timeout, rate limit, bad response), `ACCESS_RESTRICTED` (credentials
  rejected, or a CAPTCHA-protected source), `NOT_CONFIGURED`,
  `NOT_APPLICABLE`. A failed source is never turned into `NOT_FOUND`, and
  `NOT_FOUND` is never worded as "safe".
- **No access-control bypass.** Semak Mule (PDRM CCID, `+60` numbers) is
  CAPTCHA-protected, so it is listed as a manual check and never queried.

Sources looked at and not used: the FTC Do Not Call complaints API (official,
but it cannot be filtered by phone number - only by date, state, area code
and robocall flag), tellows (paid partner key, response format not
verifiable), and Google Places (its terms restrict storing place content in
saved reports).

## Telegram delivery

Every module (01-16) goes through one pipeline: validate the report, write the
JSON atomically, draw the terminal report, upload the file with `sendDocument`,
then show the real result on the `Telegram` line and record it in the local
JSON (`telegram_delivery`). The copy Telegram receives was uploaded before the
outcome existed, so it says `PENDING`.

`SENT` is only shown when Telegram answers HTTP 200 with `ok=true` and echoes
the document back. Otherwise the line shows one of `NOT_CONFIGURED`,
`INVALID_CONFIGURATION`, `AUTHENTICATION_FAILED` (401/404),
`CHAT_NOT_FOUND` (400), `BOT_FORBIDDEN` (403), `RATE_LIMITED` (429, no
automatic retry), `NETWORK_ERROR` (DNS/TLS/timeout/connection, or a proxy or
firewall answering instead of Telegram), `FILE_ERROR`, `TELEGRAM_API_ERROR`
(other 4xx, 5xx, ok=false) or `UNKNOWN_ERROR`. A failure never stops the
module or the Y / X prompt.

To find out why delivery fails on your machine:

    python telegram_check.py            # read-only: config, reachability, getMe, getChat, permissions
    python telegram_check.py --upload   # then upload ONE report you pick, after typing SEND

## Evidence model

Every finding carries `status`, `confidence`, `source`, `evidence`,
`methodology`, and a `timestamp`. Statuses are never blurred together:
`NOT_FOUND` (checked, nothing there) is always distinct from `NOT_TESTED`
(never checked) and `SOURCE_UNAVAILABLE` (checked, source didn't answer
usably). Confidence is assigned by what kind of evidence was collected,
never generated randomly.

## Reports

Every completed module writes a timestamped JSON file to `reports/`,
structured as:

```json
{
  "tool": {"name": "ObsidianEye OSINT", "version": "1.0.0", "developer": "Repp76"},
  "scan": {"timestamp": "...", "module": "...", "status": "completed"},
  "target": {},
  "findings": [],
  "sources": [],
  "errors": [],
  "warnings": []
}
```

That file is the authoritative record of a scan, whether or not Telegram
delivery is configured or succeeds.

## Ethical boundary

This is a public-information tool. It does not attempt login bypass,
CAPTCHA bypass, private account access, credential theft, or any form of
exploitation. Requests use timeouts and a real user agent, and platforms
that require authentication or active anti-bot defeat are reported as
`BLOCKED` rather than worked around.

## Test status

The modules were built and code-reviewed together, but this build
environment has outbound network access disabled, so live network calls
(HTTP requests, DNS resolution, TLS handshakes, RDAP/HIBP lookups) could
not be executed here. What was verified in this environment:

- [x] Project imports cleanly, no syntax/import errors across all 15 modules
- [x] Input validation (username/domain/email/IP/URL regex and format checks)
- [x] Error-path logic for DNS/HTTP/TLS failures (code inspection - each
      distinct error is mapped to its own status, none silently swallowed)
- [x] JSON report structure and serialization
- [x] Local-file modules (Image Metadata, Document Metadata) logic against
      the installed libraries' documented APIs
- [ ] Live checks against GitHub/Reddit/Twitch/etc. - requires outbound
      network access, run `python main.py` in your own environment to
      confirm live behavior against current site markup (sites do change
      their HTML/anti-bot behavior over time; the `text_marker` checks in
      particular may need their marker strings updated if a platform
      redesigns its pages)
- [ ] Live Telegram delivery (all modules) - requires a real bot token/chat ID and network access to confirm; the
      tests use a local emulator of the Bot API, not Telegram itself
- [ ] Live HIBP lookup - requires a paid API key to confirm

### Module 16 test status

- [x] Automated tests in `tests/` (`python -m unittest discover -s tests -v`)
      cover parsing, every failure path (timeout, DNS, TLS, rate limit,
      rejected key, redirect, malformed JSON), field mapping, secret
      redaction, JSON shape, Telegram outcomes, Y / X / CTRL+C. They use
      mocked HTTP and never touch the network or your real `.env`.
- [ ] Live IPQualityScore and Twilio responses - need your own keys. The
      field names and endpoints were taken from the providers' published
      docs but have not been exercised against the live services.
- [ ] Live Telegram delivery for Module 16 - needs your bot credentials.

If a live platform check ever seems wrong, that's a real possibility
worth checking by hand - the design goal here was to fail honestly
(`UNKNOWN`/`BLOCKED`/`SOURCE_UNAVAILABLE`) rather than fail silently into
a false positive.
