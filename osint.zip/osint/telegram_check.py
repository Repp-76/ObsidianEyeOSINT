"""
Telegram delivery check for ObsidianEye reports.

    python telegram_check.py            read-only: configuration, API reachability,
                                        bot token (getMe), target chat (getChat)
    python telegram_check.py --upload   the same, then offers to upload ONE report

Nothing is sent to the chat unless you choose a report and type SEND. It
sends once and never repeats.
"""

import sys

from config.settings import REPORTS_DIR
from core import telegram_client
from utils import terminal


def _print_steps(steps) -> bool:
    ok = True
    for step in steps:
        line = f"{step.name}: {step.detail}"
        if step.status == "OK":
            terminal.success(line)
        elif step.status == "WARNING":
            terminal.warn(line)
        elif step.status == "SKIPPED":
            terminal.info(f"{step.name}: skipped - {step.detail}")
        else:
            terminal.error(line)
            ok = False
    return ok


def _choose_report():
    reports = sorted(REPORTS_DIR.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)[:10]
    if not reports:
        terminal.warn("No reports found in the reports folder. Run a module first.")
        return None
    terminal.heading("Choose one report to upload")
    for i, path in enumerate(reports, start=1):
        terminal.console.print(f"  [{i}] {path.name}  ({path.stat().st_size} bytes)")
    choice = terminal.prompt("Report number (ENTER to cancel): ")
    if not choice.isdigit() or not 1 <= int(choice) <= len(reports):
        terminal.info("Cancelled, nothing was sent.")
        return None
    return reports[int(choice) - 1]


def main(argv) -> int:
    terminal.heading("Telegram delivery check")
    passed = _print_steps(telegram_client.diagnose())

    if "--upload" not in argv:
        terminal.info("Read-only check finished. Add --upload to test sending one report.")
        return 0 if passed else 1
    if not passed:
        terminal.warn("Fix the failed step(s) above before testing an upload.")
        return 1

    path = _choose_report()
    if path is None:
        return 0
    answer = terminal.prompt(f"Type SEND to upload {path.name} to the configured chat once: ")
    if answer != "SEND":
        terminal.info("Cancelled, nothing was sent.")
        return 0

    result = telegram_client.send_document(path, caption="ObsidianEye Telegram check (manual test upload)")
    (terminal.success if result.ok else terminal.error)(f"Upload result: {result.describe()}")
    return 0 if result.ok else 1


if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv[1:]))
    except KeyboardInterrupt:
        terminal.console.print()
        terminal.info("Cancelled.")
        sys.exit(0)
